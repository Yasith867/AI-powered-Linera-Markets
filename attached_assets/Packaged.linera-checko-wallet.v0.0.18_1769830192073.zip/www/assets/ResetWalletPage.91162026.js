import { d as defineComponent, r as ref, H as openBlock, I as createElementBlock, K as createBaseVNode, k as createVNode, Q as QIcon, L as toDisplayString, J as withCtx, O as withDirectives, P as createBlock, aw as QBtn, W as useRouter, R as createTextVNode } from "./index.facf9114.js";
import { Q as QSpace, l as localStore } from "./QSpace.27146b0a.js";
import { Q as QCheckbox } from "./QCheckbox.4dbcc5ed.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { Q as QSpinnerGears, T as TouchRepeat } from "./TouchRepeat.093c17cd.js";
import { a as dbWallet, d as dbBase } from "./db.46ddc67f.js";
import "./use-checkbox.7dc62ae3.js";
import "./use-dark.ea7d71c2.js";
import "./private.use-form.4c048d1b.js";
import "./selection.ef9ae985.js";
const _hoisted_1 = { class: "text-center onboarding-container shadow-1" };
const _hoisted_2 = { class: "onboarding-content full-width full-height page-x-padding extra-margin-bottom" };
const _hoisted_3 = { class: "row vertical-menus-margin" };
const _hoisted_4 = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_5 = { class: "full-width text-left vertical-items-margin" };
const _sfc_main$1 = defineComponent({
  __name: "ResetWallet",
  setup(__props) {
    const passwordConfirmed = ref(false);
    const walletConfirmed = ref(false);
    const mnemonicConfirmed = ref(false);
    const router = useRouter();
    const onBackClick = () => {
      void router.back();
    };
    const confirmSeconds = ref(10);
    const confirmedSeconds = ref(0);
    const onConfirmClick = async () => {
      confirmedSeconds.value++;
      if (confirmSeconds.value === confirmedSeconds.value) {
        await dbWallet.delete();
        await dbBase.delete();
        window.location.pathname = localStore.setting.formalizePath("/");
        if (window.location.pathname.includes("extension")) {
          return;
        }
        if (document.URL.startsWith("chrome-extension://")) {
          window.location.pathname = "/www/index.html";
          window.location.hash = "#/extension/onboarding";
        }
      }
    };
    const onConfirmCanceled = () => {
      confirmedSeconds.value = 0;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            createVNode(QIcon, {
              name: "bi-arrow-left-short",
              size: "24px",
              class: "cursor-pointer",
              onClick: onBackClick
            }),
            createVNode(QSpace),
            createBaseVNode("p", _hoisted_4, toDisplayString(_ctx.$t("MSG_RESET_WALLET")), 1),
            createVNode(QSpace),
            _cache[3] || (_cache[3] = createBaseVNode("div", { style: { width: "24px" } }, null, -1))
          ]),
          createBaseVNode("div", _hoisted_5, [
            createVNode(QCard, { class: "bg-grey-2 page-x-padding selector-y-padding" }, {
              default: withCtx(() => [
                createVNode(QCheckbox, {
                  modelValue: passwordConfirmed.value,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => passwordConfirmed.value = $event)
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("MSG_RESET_WALLET_TIP_1")), 1)
                  ]),
                  _: 1
                }, 8, ["modelValue"])
              ]),
              _: 1
            }),
            createVNode(QCard, { class: "bg-grey-2 page-x-padding selector-y-padding vertical-menus-margin" }, {
              default: withCtx(() => [
                createVNode(QCheckbox, {
                  modelValue: walletConfirmed.value,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => walletConfirmed.value = $event)
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("MSG_RESET_WALLET_TIP_2")), 1)
                  ]),
                  _: 1
                }, 8, ["modelValue"])
              ]),
              _: 1
            }),
            createVNode(QCard, { class: "bg-grey-2 page-x-padding selector-y-padding vertical-menus-margin" }, {
              default: withCtx(() => [
                createVNode(QCheckbox, {
                  modelValue: mnemonicConfirmed.value,
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => mnemonicConfirmed.value = $event)
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("MSG_RESET_WALLET_TIP_3")), 1)
                  ]),
                  _: 1
                }, 8, ["modelValue"])
              ]),
              _: 1
            })
          ]),
          withDirectives((openBlock(), createBlock(QBtn, {
            loading: confirmedSeconds.value > 0 && confirmedSeconds.value < confirmSeconds.value,
            percentage: confirmedSeconds.value * 100 / confirmSeconds.value,
            flat: "",
            class: "btn btn-alt vertical-sections-margin full-width",
            label: _ctx.$t("MSG_LONG_PRESS_RESET_WALLET"),
            "no-caps": "",
            onMouseup: onConfirmCanceled,
            disable: !passwordConfirmed.value || !walletConfirmed.value || !mnemonicConfirmed.value
          }, {
            loading: withCtx(() => [
              createVNode(QSpinnerGears, { class: "on-left" }),
              createTextVNode(" " + toDisplayString(_ctx.$t("MSG_CONFIRMING")), 1)
            ]),
            _: 1
          }, 8, ["loading", "percentage", "label", "disable"])), [
            [
              TouchRepeat,
              onConfirmClick,
              void 0,
              { mouse: true }
            ]
          ])
        ])
      ]);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "ResetWalletPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1);
    };
  }
});
export { _sfc_main as default };

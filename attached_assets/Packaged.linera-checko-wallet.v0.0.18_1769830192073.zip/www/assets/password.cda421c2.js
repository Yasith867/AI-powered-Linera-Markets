var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { d as dbBase } from "./db.46ddc67f.js";
import { d as decryptPassword, V as buildPassword } from "./application.ca271889.js";
const _Password = class {
};
let Password = _Password;
__publicField(Password, "resetActive", async () => {
  for (const passwd of (await dbBase.passwords.toArray()).filter(
    (el) => el.active
  )) {
    await dbBase.passwords.update(passwd.id, { active: false });
  }
});
__publicField(Password, "password", async () => {
  const passwd = (await dbBase.passwords.toArray()).find((el) => el.active);
  if (!passwd)
    return void 0;
  const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
  if (!fingerPrint)
    return void 0;
  return decryptPassword(passwd, fingerPrint.fingerPrint);
});
__publicField(Password, "save", async (passwd) => {
  const password = await _Password.password();
  if (!passwd?.length && !password?.length) {
    throw Error("Invalid password");
  }
  await _Password.resetActive();
  const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
  if (!fingerPrint)
    return Promise.reject("Invalid finterprint");
  const _passwd = buildPassword(
    passwd || password || "",
    fingerPrint.fingerPrint
  );
  if (_passwd) {
    await dbBase.passwords.add(_passwd);
  }
});
__publicField(Password, "verify", async (passwd) => {
  const pwd = (await dbBase.passwords.toArray()).find((el) => el.active);
  if (!pwd)
    return false;
  const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
  if (!fingerPrint)
    return Promise.reject("Invalid finterprint");
  return decryptPassword(pwd, fingerPrint.fingerPrint) === passwd;
});
export { Password as P };

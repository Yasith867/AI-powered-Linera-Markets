import { a as QSpinnerFacebook, b as QInnerLoading } from "./QInnerLoading.401a74c0.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { d as defineComponent, as as toRef, H as openBlock, P as createBlock, J as withCtx, k as createVNode, i as inject, aB as quasarKey } from "./index.facf9114.js";
const _sfc_main = defineComponent({
  __name: "ProcessingView",
  props: {
    processing: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const processing = toRef(props, "processing");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, {
        style: { height: "160px", width: "100%" },
        flat: ""
      }, {
        default: withCtx(() => [
          createVNode(QInnerLoading, {
            showing: processing.value,
            class: "text-red-4"
          }, {
            default: withCtx(() => [
              createVNode(QSpinnerFacebook, { size: "80px" })
            ]),
            _: 1
          }, 8, ["showing"])
        ]),
        _: 1
      });
    };
  }
});
function useQuasar() {
  return inject(quasarKey);
}
export { _sfc_main as _, useQuasar as u };

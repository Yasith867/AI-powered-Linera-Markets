import { Q as QSpace, l as localStore } from "./QSpace.27146b0a.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { d as defineComponent, r as ref, H as openBlock, I as createElementBlock, K as createBaseVNode, L as toDisplayString, a0 as normalizeStyle, u as unref, k as createVNode, aw as QBtn, S as normalizeClass, X as useRoute, W as useRouter, P as createBlock } from "./index.facf9114.js";
import "./use-timeout.0aac84f1.js";
var onboardingImproveBanner = "assets/OnboardingImproveBanner.0eec15f1.png";
const _hoisted_1 = { class: "onboarding-page-title text-center" };
const _hoisted_2 = ["innerHTML"];
const _hoisted_3 = { class: "row full-width vertical-sections-margin" };
const _hoisted_4 = { class: "text-left full-width vertical-sections-margin" };
const _hoisted_5 = { href: "https://github.com/respeer-ai/linera-wallet/README.md" };
const _hoisted_6 = { class: "vertical-sections-margin" };
const _hoisted_7 = { class: "row vertical-menus-margin" };
const _hoisted_8 = { class: "onboarding-btns row" };
const _sfc_main$1 = defineComponent({
  __name: "ImproveAnnouncement",
  setup(__props) {
    const route = useRoute();
    const target = ref(route.query.target);
    const router = useRouter();
    const onAnyBtnClick = () => {
      void router.push({ path: localStore.setting.formalizePath(target.value) });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(["onboarding-container", unref(localStore).setting.extensionMode ? "page-x-padding" : "onboarding-padding"])
        }, [
          createBaseVNode("h5", _hoisted_1, toDisplayString(_ctx.$t("MSG_HELP_US_IMPROVE_CHECKO")), 1),
          createBaseVNode("div", {
            style: normalizeStyle({ maxHeight: unref(localStore).setting.extensionMode ? "456px" : "100%", overflow: "scroll" })
          }, [
            createBaseVNode("div", {
              class: "text-left",
              innerHTML: _ctx.$t("MSG_HELP_IMPROVING_CHECKO_BY_CREATE_GITHUB_ISSUE")
            }, null, 8, _hoisted_2),
            createBaseVNode("div", _hoisted_3, [
              createVNode(QSpace),
              createVNode(QImg, {
                src: unref(onboardingImproveBanner),
                width: "100%"
              }, null, 8, ["src"]),
              createVNode(QSpace)
            ]),
            createBaseVNode("div", _hoisted_4, [
              createBaseVNode("a", _hoisted_5, toDisplayString(_ctx.$t("MSG_LEARN_HOW_TO_CREATE_ISSUE_WHEN_USING_CHECKO")), 1)
            ]),
            createBaseVNode("div", _hoisted_6, toDisplayString(_ctx.$t("MSG_UNDERSTAND_OBEY_CHECKO_COMMUNITY_RULES_CREATING_ISSUE")), 1)
          ], 4),
          createBaseVNode("div", _hoisted_7, [
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_8, [
              createVNode(QBtn, {
                flat: "",
                label: _ctx.$t("MSG_I_UNDERSTAND"),
                class: "btn vertical-items-margin full-width",
                onClick: onAnyBtnClick,
                "no-caps": ""
              }, null, 8, ["label"])
            ]),
            createVNode(QSpace)
          ])
        ], 2)
      ]);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "ImprovementPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1);
    };
  }
});
export { _sfc_main as default };

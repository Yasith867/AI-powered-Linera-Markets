import { d as defineComponent, ar as mergeModels, as as toRef, r as ref, aq as useModel, w as watch, H as openBlock, P as createBlock, I as createElementBlock, k as createVNode, F as Fragment, a as computed, K as createBaseVNode, J as withCtx, V as createCommentVNode, Q as QIcon, M as renderList, S as normalizeClass, aF as QAvatar, u as unref, L as toDisplayString, t as createComponent, h, D as hMergeSlot, o as onMounted, a0 as normalizeStyle, aH as withModifiers, R as createTextVNode, _ as _export_sfc } from "./index.facf9114.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { l as localStore, Q as QSpace } from "./QSpace.27146b0a.js";
import { c as addFocusout, r as removeFocusout, d as _sfc_main$7, _ as _sfc_main$9, T as Token, Q as QList, a as QItem, b as _sfc_main$a } from "./TokenBridge.0a26909e.js";
import { q as dbModel } from "./application.ca271889.js";
import { l as liveQuery, a as dbWallet } from "./db.46ddc67f.js";
import { O as Owner, a as MicrochainFungibleTokenBalance } from "./owner.bc60a389.js";
import "./index.d2b21240.js";
import { u as useObservable } from "./index.f58c37d0.js";
import { _ as _sfc_main$8 } from "./PasswordBridge.41db8c1b.js";
const shortId = (id, headTailNumber) => {
  if (!id?.length)
    return "";
  return id.slice(0, headTailNumber) + "..." + id.slice(-headTailNumber);
};
var shortid = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  shortId
}, Symbol.toStringTag, { value: "Module" }));
function fallback(text) {
  const area = document.createElement("textarea");
  area.value = text;
  area.contentEditable = "true";
  area.style.position = "fixed";
  const fn = () => {
  };
  addFocusout(fn);
  document.body.appendChild(area);
  area.focus();
  area.select();
  const res = document.execCommand("copy");
  area.remove();
  removeFocusout(fn);
  return res;
}
function copyToClipboard(text) {
  return navigator.clipboard !== void 0 ? navigator.clipboard.writeText(text) : new Promise((resolve, reject) => {
    const res = fallback(text);
    if (res) {
      resolve(true);
    } else {
      reject(res);
    }
  });
}
const _copyToClipboard = (content, evt) => {
  evt.preventDefault();
  copyToClipboard(content).then(() => {
    localStore.notification.pushNotification({
      Title: "Copy content",
      Message: `Success copy ${content.substring(0, 20)}... to clipboard.`,
      Popup: true,
      Type: localStore.notify.NotifyType.Info
    });
  }).catch((e) => {
    localStore.notification.pushNotification({
      Title: "Copy content",
      Message: `Failed copy ${content.substring(0, 20)}...: ${e}`,
      Popup: true,
      Type: localStore.notify.NotifyType.Error
    });
  });
};
const _sfc_main$6 = defineComponent({
  __name: "MicrochainOwnerBridge",
  props: /* @__PURE__ */ mergeModels({
    microchain: {},
    owner: {}
  }, {
    "microchainOwners": {},
    "microchainOwnersModifiers": {}
  }),
  emits: ["update:microchainOwners"],
  setup(__props) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const owner = toRef(props, "owner");
    const selectedNetwork = ref(void 0);
    const microchainOwners = useModel(__props, "microchainOwners");
    const _microchainOwners = useObservable(
      liveQuery(async () => {
        return microchain.value?.length ? await dbWallet.microchainOwners.where("microchain").equals(microchain.value).toArray() : owner.value?.length ? await dbWallet.microchainOwners.where("owner").equals(owner.value).toArray() : await dbWallet.microchainOwners.toArray();
      })
    );
    watch(_microchainOwners, () => {
      microchainOwners.value = _microchainOwners.value;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$7, {
        "selected-network": selectedNetwork.value,
        "onUpdate:selectedNetwork": _cache[0] || (_cache[0] = ($event) => selectedNetwork.value = $event)
      }, null, 8, ["selected-network"]);
    };
  }
});
const _sfc_main$5 = defineComponent({
  __name: "OwnerBridge",
  props: {
    "owners": {},
    "ownersModifiers": {},
    "selectedOwner": {},
    "selectedOwnerModifiers": {},
    "nativeTokenBalance": {},
    "nativeTokenBalanceModifiers": {},
    "nativeUsdBalance": {},
    "nativeUsdBalanceModifiers": {}
  },
  emits: ["update:owners", "update:selectedOwner", "update:nativeTokenBalance", "update:nativeUsdBalance"],
  setup(__props) {
    const selectedNetwork = ref(void 0);
    const password = ref(void 0);
    const microchains = ref([]);
    const microchainOwners = ref([]);
    const owners = useModel(__props, "owners");
    const selectedOwner = useModel(__props, "selectedOwner");
    const nativeTokenBalance = useModel(__props, "nativeTokenBalance");
    const nativeUsdBalance = useModel(__props, "nativeUsdBalance");
    const microchainBridge = ref();
    const _owners = useObservable(
      liveQuery(async () => {
        return [...await dbWallet.owners.toArray()];
      })
    );
    const _nativeTokenBalance = useObservable(
      liveQuery(async () => {
        const selectedOwner2 = await Owner.selected();
        if (!selectedOwner2)
          return 0;
        const nativeTokenId = (await Token.native())?.id || 0;
        const balance = await Owner.ownerBalance(selectedOwner2, nativeTokenId);
        return balance.tokenBalance;
      })
    );
    const _nativeUsdBalance = useObservable(
      liveQuery(async () => {
        const selectedOwner2 = await Owner.selected();
        if (!selectedOwner2)
          return 0;
        const nativeTokenId = (await Token.native())?.id || 0;
        const balance = await Owner.ownerBalance(selectedOwner2, nativeTokenId);
        return balance.usdBalance;
      })
    );
    watch(_owners, async () => {
      owners.value = _owners.value;
      selectedOwner.value = await Owner.selected();
    });
    watch(_nativeTokenBalance, () => {
      nativeTokenBalance.value = _nativeTokenBalance.value;
    });
    watch(_nativeUsdBalance, () => {
      nativeUsdBalance.value = _nativeUsdBalance.value;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$7, {
          "selected-network": selectedNetwork.value,
          "onUpdate:selectedNetwork": _cache[0] || (_cache[0] = ($event) => selectedNetwork.value = $event)
        }, null, 8, ["selected-network"]),
        createVNode(_sfc_main$8, {
          password: password.value,
          "onUpdate:password": _cache[1] || (_cache[1] = ($event) => password.value = $event)
        }, null, 8, ["password"]),
        createVNode(_sfc_main$9, {
          ref_key: "microchainBridge",
          ref: microchainBridge,
          microchains: microchains.value,
          "onUpdate:microchains": _cache[2] || (_cache[2] = ($event) => microchains.value = $event)
        }, null, 8, ["microchains"]),
        createVNode(_sfc_main$6, {
          "microchain-owners": microchainOwners.value,
          "onUpdate:microchainOwners": _cache[3] || (_cache[3] = ($event) => microchainOwners.value = $event)
        }, null, 8, ["microchain-owners"])
      ], 64);
    };
  }
});
var lineraLogo = "assets/LineraLogo.d17e4b3f.png";
const _hoisted_1$2 = { class: "full-height overflow-scroll" };
const _hoisted_2$2 = {
  key: 0,
  class: "selector-search"
};
const _hoisted_3$2 = { class: "selector-margin-x-left text-left" };
const _hoisted_4$1 = { class: "text-bold text-grey-9" };
const _hoisted_5$1 = { class: "selector-item-endpoint" };
const _hoisted_6$1 = { class: "row" };
const _hoisted_7$1 = { class: "text-grey-9" };
const _hoisted_8$1 = { class: "row" };
const _hoisted_9$1 = { class: "text-grey-9 selector-item-currency-sub header-items-margin-x-left" };
const _hoisted_10$1 = {
  key: 0,
  class: "selector-margin-x-left"
};
const _sfc_main$4 = defineComponent({
  __name: "AccountsInnerView",
  props: /* @__PURE__ */ mergeModels({
    persistent: { type: Boolean, default: true },
    searchable: { type: Boolean, default: true },
    showAction: { type: Boolean, default: true }
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const persistent = toRef(props, "persistent");
    const searchable = toRef(props, "searchable");
    const showAction = toRef(props, "showAction");
    const owners = ref([]);
    const searchText = ref("");
    const owner = useModel(__props, "modelValue");
    const emit = __emit;
    const displayOwners = computed(() => owners.value.filter((el) => {
      return el.name.includes(searchText.value) || el.address.includes(searchText.value);
    }));
    const ownerBalances = ref(/* @__PURE__ */ new Map());
    const ownerUsdBalances = ref(/* @__PURE__ */ new Map());
    const onActionClick = (owner2) => {
      console.log(owner2);
    };
    const onOwnerSelected = async (_owner) => {
      owner.value = _owner;
      if (persistent.value) {
        _owner.selected = true;
        await Owner.update(_owner);
      }
      emit("selected", _owner);
    };
    watch(owners, async () => {
      for (const _owner of owners.value) {
        const token = await Token.native();
        const balance = await Owner.ownerBalance(_owner, token?.id || 0);
        ownerBalances.value.set(_owner.address, balance?.tokenBalance || 0);
        ownerUsdBalances.value.set(_owner.address, balance?.usdBalance || 0);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$2, [
          searchable.value ? (openBlock(), createElementBlock("div", _hoisted_2$2, [
            createVNode(QInput, {
              dense: "",
              outlined: "",
              rounded: "",
              modelValue: searchText.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchText.value = $event)
            }, {
              prepend: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-search",
                  size: "16px"
                })
              ]),
              _: 1
            }, 8, ["modelValue"])
          ])) : createCommentVNode("", true),
          createVNode(QList, { class: "selector-list" }, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(displayOwners.value, (_owner) => {
                return openBlock(), createBlock(QItem, {
                  key: _owner.id,
                  clickable: "",
                  class: normalizeClass(["tab-panel-item selector-item-padding-right", (owner.value ? _owner.id === owner.value?.id : _owner.selected) ? "selector-item-selected" : ""]),
                  onClick: ($event) => onOwnerSelected(_owner)
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", {
                      class: normalizeClass(["selector-indicator", (owner.value ? _owner.id === owner.value?.id : _owner.selected) ? "selector-indicator-selected" : ""])
                    }, null, 2),
                    createVNode(QAvatar, { color: "red-1 selector-margin-x-left" }, {
                      default: withCtx(() => [
                        createVNode(QImg, {
                          src: unref(dbModel).ownerAvatar(_owner),
                          width: "48px",
                          height: "48px"
                        }, null, 8, ["src"])
                      ]),
                      _: 2
                    }, 1024),
                    createBaseVNode("div", _hoisted_3$2, [
                      createBaseVNode("div", _hoisted_4$1, toDisplayString(_owner.name), 1),
                      createBaseVNode("div", _hoisted_5$1, " 0x" + toDisplayString(unref(shortid).shortId(_owner.address, 5)), 1)
                    ]),
                    createVNode(QSpace),
                    createBaseVNode("div", null, [
                      createBaseVNode("div", _hoisted_6$1, [
                        createVNode(QSpace),
                        _cache[2] || (_cache[2] = createBaseVNode("span", null, "$", -1)),
                        createBaseVNode("strong", _hoisted_7$1, toDisplayString(ownerUsdBalances.value.get(_owner.address)?.toFixed(4)), 1),
                        _cache[3] || (_cache[3] = createBaseVNode("span", { class: "text-grey-6 header-items-margin-x-left" }, "USD", -1))
                      ]),
                      createBaseVNode("div", _hoisted_8$1, [
                        createVNode(QImg, {
                          src: unref(lineraLogo),
                          width: "18px",
                          height: "18px"
                        }, null, 8, ["src"]),
                        createBaseVNode("span", _hoisted_9$1, toDisplayString(ownerBalances.value.get(_owner.address)?.toFixed(4)), 1),
                        _cache[4] || (_cache[4] = createBaseVNode("span", { class: "text-grey-6 selector-item-currency-sub header-items-margin-x-left" }, "TLINERA", -1))
                      ])
                    ]),
                    showAction.value ? (openBlock(), createElementBlock("div", _hoisted_10$1, [
                      createVNode(QIcon, {
                        name: "bi-three-dots-vertical",
                        size: "16px",
                        onClick: ($event) => onActionClick(_owner)
                      }, null, 8, ["onClick"])
                    ])) : createCommentVNode("", true)
                  ]),
                  _: 2
                }, 1032, ["class", "onClick"]);
              }), 128))
            ]),
            _: 1
          })
        ]),
        createVNode(_sfc_main$5, {
          ref: "ownerBridge",
          owners: owners.value,
          "onUpdate:owners": _cache[1] || (_cache[1] = ($event) => owners.value = $event)
        }, null, 8, ["owners"])
      ], 64);
    };
  }
});
const alignValues = ["top", "middle", "bottom"];
var QBadge = createComponent({
  name: "QBadge",
  props: {
    color: String,
    textColor: String,
    floating: Boolean,
    transparent: Boolean,
    multiLine: Boolean,
    outline: Boolean,
    rounded: Boolean,
    label: [Number, String],
    align: {
      type: String,
      validator: (v) => alignValues.includes(v)
    }
  },
  setup(props, { slots }) {
    const style = computed(() => {
      return props.align !== void 0 ? { verticalAlign: props.align } : null;
    });
    const classes = computed(() => {
      const text = props.outline === true ? props.color || props.textColor : props.textColor;
      return `q-badge flex inline items-center no-wrap q-badge--${props.multiLine === true ? "multi" : "single"}-line` + (props.outline === true ? " q-badge--outline" : props.color !== void 0 ? ` bg-${props.color}` : "") + (text !== void 0 ? ` text-${text}` : "") + (props.floating === true ? " q-badge--floating" : "") + (props.rounded === true ? " q-badge--rounded" : "") + (props.transparent === true ? " q-badge--transparent" : "");
    });
    return () => h("div", {
      class: classes.value,
      style: style.value,
      role: "status",
      "aria-label": props.label
    }, hMergeSlot(slots.default, props.label !== void 0 ? [props.label] : []));
  }
});
const _sfc_main$3 = defineComponent({
  __name: "MicrochainBalanceBridge",
  props: /* @__PURE__ */ mergeModels({
    tokenId: {},
    microchainId: {}
  }, {
    "tokenBalance": {},
    "tokenBalanceModifiers": {},
    "usdBalance": {},
    "usdBalanceModifiers": {}
  }),
  emits: ["update:tokenBalance", "update:usdBalance"],
  setup(__props) {
    const props = __props;
    const tokenId = toRef(props, "tokenId");
    const microchainId = toRef(props, "microchainId");
    const tokens = ref([]);
    const tokenBalance = useModel(__props, "tokenBalance");
    const usdBalance = useModel(__props, "usdBalance");
    const _balances = useObservable(
      liveQuery(async () => {
        if (!microchainId.value)
          return [];
        return tokenId.value !== void 0 ? (await dbWallet.microchainFungibleTokenBalances.toArray()).filter((el) => el.tokenId === tokenId.value && el.microchain === microchainId.value) : await dbWallet.microchainFungibleTokenBalances.where("microchain").equals(microchainId.value).toArray();
      })
    );
    const _tokenBalance = computed(() => {
      if (tokenId.value === void 0)
        return 0;
      return _balances.value?.reduce((sum, a) => sum + a.balance, 0);
    });
    watch(_tokenBalance, () => {
      tokenBalance.value = _tokenBalance.value;
    });
    const _usdBalance = computed(() => {
      return _balances.value?.reduce((sum, a) => sum + a.balance * (tokens.value.find((el) => el.id === a.tokenId)?.usdCurrency || 0), 0);
    });
    watch(_usdBalance, () => {
      usdBalance.value = _usdBalance.value;
    });
    watch(microchainId, async () => {
      if (!microchainId.value || !tokenId.value)
        return;
      tokenBalance.value = (await MicrochainFungibleTokenBalance.balance(microchainId.value, tokenId.value))?.balance || 0;
      usdBalance.value = tokenBalance.value * ((await Token.tokenWithId(tokenId.value))?.usdCurrency || 0);
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$a, {
        tokens: tokens.value,
        "onUpdate:tokens": _cache[0] || (_cache[0] = ($event) => tokens.value = $event)
      }, null, 8, ["tokens"]);
    };
  }
});
const _sfc_main$2 = defineComponent({
  __name: "MicrochainOwnerBalanceBridge",
  props: /* @__PURE__ */ mergeModels({
    tokenId: {},
    microchainId: {},
    owner: {}
  }, {
    "tokenBalance": {},
    "tokenBalanceModifiers": {},
    "usdBalance": {},
    "usdBalanceModifiers": {}
  }),
  emits: ["update:tokenBalance", "update:usdBalance"],
  setup(__props) {
    const props = __props;
    const tokenId = toRef(props, "tokenId");
    const microchainId = toRef(props, "microchainId");
    const owner = toRef(props, "owner");
    const tokens = ref([]);
    const tokenBalance = useModel(__props, "tokenBalance");
    const usdBalance = useModel(__props, "usdBalance");
    const _balances = useObservable(
      liveQuery(async () => {
        return tokenId.value !== void 0 ? (await dbWallet.microchainOwnerFungibleTokenBalances.toArray()).filter((el) => el.tokenId === tokenId.value && el.microchain === microchainId.value && (!owner.value || el.owner.includes(owner.value) || owner.value?.includes(el.owner))) : (await dbWallet.microchainOwnerFungibleTokenBalances.toArray()).filter((el) => el.microchain === microchainId.value && (!owner.value || el.owner.includes(owner.value) || owner.value?.includes(el.owner)));
      })
    );
    const _tokenBalance = computed(() => {
      if (tokenId.value === void 0)
        return 0;
      return _balances.value?.reduce((sum, a) => sum + a.balance, 0);
    });
    watch(_tokenBalance, () => {
      tokenBalance.value = _tokenBalance.value;
    });
    const _usdBalance = computed(() => {
      return _balances.value?.reduce((sum, a) => sum + a.balance * (tokens.value.find((el) => el.id === a.tokenId)?.usdCurrency || 0), 0);
    });
    watch(_usdBalance, () => {
      usdBalance.value = _usdBalance.value;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$a, {
        tokens: tokens.value,
        "onUpdate:tokens": _cache[0] || (_cache[0] = ($event) => tokens.value = $event)
      }, null, 8, ["tokens"]);
    };
  }
});
const _hoisted_1$1 = { class: "selector-margin-x-left" };
const _hoisted_2$1 = { class: "text-bold text-grey-9 row" };
const _hoisted_3$1 = { class: "page-item-x-margin-left cursor-pointer" };
const _hoisted_4 = {
  key: 0,
  class: "text-left"
};
const _hoisted_5 = { class: "text-grey-6 selector-item-currency-sub" };
const _hoisted_6 = {
  key: 1,
  class: "text-left"
};
const _hoisted_7 = { class: "text-grey-6 selector-item-currency-sub" };
const _hoisted_8 = { key: 1 };
const _hoisted_9 = { class: "text-bold text-grey-9 text-right" };
const _hoisted_10 = { class: "selector-item-currency-sub" };
const _hoisted_11 = { class: "text-right" };
const _hoisted_12 = { class: "text-grey-6 selector-item-currency-sub" };
const _hoisted_13 = { key: 2 };
const _hoisted_14 = { class: "text-right text-bold" };
const _hoisted_15 = { class: "selector-item-currency-sub" };
const _hoisted_16 = { class: "text-grey-9 text-right" };
const _hoisted_17 = { class: "text-grey-6 selector-item-currency-sub" };
const _hoisted_18 = { key: 3 };
const _hoisted_19 = { class: "text-right text-bold" };
const _hoisted_20 = { class: "selector-item-currency-sub" };
const _hoisted_21 = { class: "text-grey-9 text-right" };
const _hoisted_22 = { class: "text-grey-6 selector-item-currency-sub" };
const _hoisted_23 = {
  key: 4,
  class: /* @__PURE__ */ normalizeClass(["selector-indicator selector-margin-x-left"])
};
const _sfc_main$1 = defineComponent({
  __name: "MicrochainCardView",
  props: {
    microchain: { default: void 0 },
    showAccountBalance: { type: Boolean, default: false },
    integratedMode: { type: Boolean, default: true },
    showIndicator: { type: Boolean, default: true },
    clickable: { type: Boolean, default: true },
    xPadding: { default: "0" },
    showSelected: { type: Boolean, default: false },
    selected: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const showAccountBalance = toRef(props, "showAccountBalance");
    const integratedMode = toRef(props, "integratedMode");
    const showIndicator = toRef(props, "showIndicator");
    const clickable = toRef(props, "clickable");
    const xPadding = toRef(props, "xPadding");
    const showSelected = toRef(props, "showSelected");
    const selected = toRef(props, "selected");
    const chainTokenBalance = ref(0);
    const chainUsdBalance = ref(0);
    const ownerTokenBalance = ref(0);
    const ownerUsdBalance = ref(0);
    const owner = ref(void 0);
    const nativeTokenId = ref(void 0);
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QItem, {
          class: "row full-width tab-panel-item",
          clickable: clickable.value,
          style: normalizeStyle({ paddingLeft: xPadding.value, paddingRight: xPadding.value })
        }, {
          default: withCtx(() => [
            showIndicator.value ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(["selector-indicator", (showSelected.value ? selected.value : microchain.value.default) ? "selector-indicator-selected" : ""])
            }, null, 2)) : createCommentVNode("", true),
            createVNode(QAvatar, {
              class: normalizeClass([showIndicator.value ? "selector-margin-x-left" : ""])
            }, {
              default: withCtx(() => [
                createVNode(QImg, {
                  src: unref(dbModel).microchainAvatar(microchain.value)
                }, null, 8, ["src"]),
                createVNode(QBadge, {
                  color: "transparent",
                  rounded: "",
                  transparent: "",
                  floating: ""
                }, {
                  default: withCtx(() => [
                    createVNode(QImg, {
                      src: unref(lineraLogo),
                      width: "14px",
                      height: "14px"
                    }, null, 8, ["src"])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 8, ["class"]),
            createBaseVNode("div", _hoisted_1$1, [
              createBaseVNode("div", _hoisted_2$1, [
                createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(microchain.value.microchain, 5)), 1),
                createBaseVNode("div", _hoisted_3$1, [
                  createVNode(QIcon, {
                    name: "bi-copy",
                    size: "12px",
                    onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(microchain.value.microchain, evt), ["stop"]))
                  })
                ])
              ]),
              integratedMode.value ? (openBlock(), createElementBlock("div", _hoisted_4, [
                createTextVNode(toDisplayString(chainTokenBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_5, toDisplayString(_ctx.$t("MSG_TEST_LINERA_TOKEN_SYMBOL")), 1)
              ])) : (openBlock(), createElementBlock("div", _hoisted_6, [
                createBaseVNode("span", _hoisted_7, toDisplayString(_ctx.$t("MSG_TEST_LINERA_TOKEN_SYMBOL")), 1)
              ]))
            ]),
            createVNode(QSpace),
            integratedMode.value ? (openBlock(), createElementBlock("div", _hoisted_8, [
              createBaseVNode("div", _hoisted_9, [
                createTextVNode(toDisplayString(ownerTokenBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_10, toDisplayString(_ctx.$t("MSG_TEST_LINERA_TOKEN_SYMBOL")), 1)
              ]),
              createBaseVNode("div", _hoisted_11, [
                createTextVNode(" $ " + toDisplayString(chainUsdBalance.value + ownerUsdBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_12, toDisplayString(_ctx.$t("MSG_USD")), 1)
              ])
            ])) : showAccountBalance.value ? (openBlock(), createElementBlock("div", _hoisted_13, [
              createBaseVNode("div", _hoisted_14, [
                createTextVNode(" $ " + toDisplayString(ownerUsdBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_15, toDisplayString(_ctx.$t("MSG_USD")), 1)
              ]),
              createBaseVNode("div", _hoisted_16, [
                createTextVNode(toDisplayString(ownerTokenBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_17, toDisplayString(_ctx.$t("MSG_TEST_LINERA_TOKEN_SYMBOL")), 1)
              ])
            ])) : (openBlock(), createElementBlock("div", _hoisted_18, [
              createBaseVNode("div", _hoisted_19, [
                createTextVNode(" $ " + toDisplayString(chainUsdBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_20, toDisplayString(_ctx.$t("MSG_USD")), 1)
              ]),
              createBaseVNode("div", _hoisted_21, [
                createTextVNode(toDisplayString(chainTokenBalance.value) + " ", 1),
                createBaseVNode("span", _hoisted_22, toDisplayString(_ctx.$t("MSG_TEST_LINERA_TOKEN_SYMBOL")), 1)
              ])
            ])),
            showIndicator.value ? (openBlock(), createElementBlock("div", _hoisted_23)) : createCommentVNode("", true)
          ]),
          _: 1
        }, 8, ["clickable", "style"]),
        nativeTokenId.value !== void 0 ? (openBlock(), createBlock(_sfc_main$3, {
          key: 0,
          "token-balance": chainTokenBalance.value,
          "onUpdate:tokenBalance": _cache[1] || (_cache[1] = ($event) => chainTokenBalance.value = $event),
          "usd-balance": chainUsdBalance.value,
          "onUpdate:usdBalance": _cache[2] || (_cache[2] = ($event) => chainUsdBalance.value = $event),
          "token-id": nativeTokenId.value,
          "microchain-id": microchain.value.microchain
        }, null, 8, ["token-balance", "usd-balance", "token-id", "microchain-id"])) : createCommentVNode("", true),
        createVNode(_sfc_main$5, {
          "selected-owner": owner.value,
          "onUpdate:selectedOwner": _cache[3] || (_cache[3] = ($event) => owner.value = $event)
        }, null, 8, ["selected-owner"]),
        nativeTokenId.value !== void 0 && owner.value ? (openBlock(), createBlock(_sfc_main$2, {
          key: 1,
          "token-balance": ownerTokenBalance.value,
          "onUpdate:tokenBalance": _cache[4] || (_cache[4] = ($event) => ownerTokenBalance.value = $event),
          "usd-balance": ownerUsdBalance.value,
          "onUpdate:usdBalance": _cache[5] || (_cache[5] = ($event) => ownerUsdBalance.value = $event),
          "token-id": nativeTokenId.value,
          "microchain-id": microchain.value.microchain,
          owner: owner.value?.owner
        }, null, 8, ["token-balance", "usd-balance", "token-id", "microchain-id", "owner"])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
var MicrochainsInnerView_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1 = { class: "full-height overflow-scroll" };
const _hoisted_2 = {
  key: 0,
  class: "selector-search"
};
const _hoisted_3 = ["onClick"];
const _sfc_main = defineComponent({
  __name: "MicrochainsInnerView",
  props: /* @__PURE__ */ mergeModels({
    searchable: { type: Boolean, default: true },
    showIndicator: { type: Boolean, default: true },
    xPadding: { default: "0" },
    showSelected: { type: Boolean, default: false },
    owner: { default: void 0 }
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const searchable = toRef(props, "searchable");
    const showIndicator = toRef(props, "showIndicator");
    const xPadding = toRef(props, "xPadding");
    const showSelected = toRef(props, "showSelected");
    const owner = toRef(props, "owner");
    const microchains = ref([]);
    const searchText = ref("");
    const displayMicrochains = computed(() => microchains.value.filter((el) => !searchText.value.length || el.name.includes(searchText.value) || el.microchain.includes(searchText.value)));
    const microchain = useModel(__props, "modelValue");
    const emit = __emit;
    const onMicrochainSelected = (_microchain) => {
      microchain.value = _microchain;
      emit("selected", _microchain);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1, [
          searchable.value ? (openBlock(), createElementBlock("div", _hoisted_2, [
            createVNode(QInput, {
              dense: "",
              outlined: "",
              rounded: "",
              modelValue: searchText.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchText.value = $event)
            }, {
              prepend: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-search",
                  size: "16px"
                })
              ]),
              _: 1
            }, 8, ["modelValue"])
          ])) : createCommentVNode("", true),
          (openBlock(true), createElementBlock(Fragment, null, renderList(displayMicrochains.value, (_microchain) => {
            return openBlock(), createElementBlock("div", {
              key: _microchain.microchain
            }, [
              createBaseVNode("div", {
                class: normalizeClass([showSelected.value && microchain.value?.microchain === _microchain.microchain ? "selector-item-selected" : ""]),
                onClick: ($event) => onMicrochainSelected(_microchain)
              }, [
                createVNode(_sfc_main$1, {
                  microchain: _microchain,
                  "show-indicator": showIndicator.value,
                  "x-padding": xPadding.value,
                  "show-selected": showSelected.value,
                  selected: microchain.value?.microchain === _microchain.microchain
                }, null, 8, ["microchain", "show-indicator", "x-padding", "show-selected", "selected"])
              ], 10, _hoisted_3)
            ]);
          }), 128))
        ]),
        createVNode(_sfc_main$9, {
          owner: owner.value,
          microchains: microchains.value,
          "onUpdate:microchains": _cache[1] || (_cache[1] = ($event) => microchains.value = $event)
        }, null, 8, ["owner", "microchains"])
      ], 64);
    };
  }
});
var MicrochainsInnerView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-64c28f6a"]]);
export { MicrochainsInnerView as M, QBadge as Q, _sfc_main$5 as _, _copyToClipboard as a, _sfc_main$6 as b, copyToClipboard as c, _sfc_main$1 as d, _sfc_main$3 as e, _sfc_main$2 as f, _sfc_main$4 as g, lineraLogo as l, shortid as s };

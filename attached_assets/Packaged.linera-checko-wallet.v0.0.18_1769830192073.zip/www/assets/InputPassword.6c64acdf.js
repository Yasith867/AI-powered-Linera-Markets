import { Q as QSpace } from "./QSpace.27146b0a.js";
import { d as defineComponent, aq as useModel, r as ref, w as watch, H as openBlock, I as createElementBlock, K as createBaseVNode, L as toDisplayString, k as createVNode, aw as QBtn } from "./index.facf9114.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import { v as validatePassword } from "./verify.2de89a24.js";
const _hoisted_1 = { class: "text-left full-width" };
const _hoisted_2 = { class: "row" };
const _sfc_main = defineComponent({
  __name: "InputPassword",
  props: {
    "password": { default: "" },
    "passwordModifiers": {},
    "error": { type: Boolean, ...{ default: false } },
    "errorModifiers": {}
  },
  emits: ["update:password", "update:error"],
  setup(__props) {
    const password = useModel(__props, "password");
    const display = ref(false);
    const displayHideText = ref("Display");
    const error = useModel(__props, "error");
    watch(display, () => {
      displayHideText.value = display.value ? "Hide" : "Display";
    });
    const onPasswordBlur = () => {
      error.value = password.value === void 0 || !validatePassword(password.value);
    };
    const resetError = () => {
      error.value = false;
    };
    const onPasswordFocus = () => {
      resetError();
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_PASSWORD")), 1),
          createVNode(QSpace),
          createVNode(QBtn, {
            flat: "",
            dense: "",
            size: "0.8rem",
            label: displayHideText.value,
            onClick: _cache[0] || (_cache[0] = ($event) => display.value = !display.value),
            color: "blue-6",
            "no-caps": ""
          }, null, 8, ["label"])
        ]),
        createVNode(QInput, {
          outlined: "",
          dense: "",
          modelValue: password.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => password.value = $event),
          onBlur: onPasswordBlur,
          onFocus: onPasswordFocus,
          error: error.value,
          "hide-bottom-space": "",
          type: display.value ? "text" : "password"
        }, null, 8, ["modelValue", "error", "type"])
      ]);
    };
  }
});
export { _sfc_main as _ };

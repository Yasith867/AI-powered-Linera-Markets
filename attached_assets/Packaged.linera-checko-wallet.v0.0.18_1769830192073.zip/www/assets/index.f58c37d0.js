import { aC as getCurrentScope, aD as onScopeDispose, r as ref } from "./index.facf9114.js";
function tryOnScopeDispose(fn) {
  if (getCurrentScope()) {
    onScopeDispose(fn);
    return true;
  }
  return false;
}
typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope;
function useObservable(observable, options) {
  const value = ref(options == null ? void 0 : options.initialValue);
  const subscription = observable.subscribe({
    next: (val) => value.value = val,
    error: options == null ? void 0 : options.onError
  });
  tryOnScopeDispose(() => {
    subscription.unsubscribe();
  });
  return value;
}
export { useObservable as u };

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { R as RpcMethod, l as localStore, b as lineraGraphqlQueryPublicKey, c as lineraGraphqlQueryApplicationId, d as lineraGraphqlMutationOperation, e as lineraGraphqlQuery, P as PopupRequestType } from "./QSpace.27146b0a.js";
import { _ as _sfc_main$c, u as useQuasar } from "./use-quasar.f24b094b.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { d as defineComponent, a as computed, H as openBlock, I as createElementBlock, k as createVNode, K as createBaseVNode, L as toDisplayString, aq as useModel, ar as mergeModels, as as toRef, J as withCtx, V as createCommentVNode, r as ref, o as onMounted, w as watch, u as unref, a0 as normalizeStyle, aw as QBtn, P as createBlock, R as createTextVNode, Q as QIcon, F as Fragment, S as normalizeClass, f as onUnmounted } from "./index.facf9114.js";
import { Q as QResizeObserver } from "./QInnerLoading.401a74c0.js";
import { g as _sfc_main$b, M as MicrochainsInnerView, s as shortid } from "./MicrochainsInnerView.9e5fbcce.js";
import { d as dbBase } from "./db.46ddc67f.js";
import { O as OperationState, q as dbModel, t as Web3, p as privateKey, j as _Web3, E as Ed25519 } from "./application.ca271889.js";
import { M as Microchain } from "./microchain.44c150a3.js";
import "./index.d2b21240.js";
import { Q as QCheckbox } from "./QCheckbox.4dbcc5ed.js";
import { C as ChainOperation } from "./TokenBridge.0a26909e.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { _ as _sfc_main$e } from "./InputPassword.6c64acdf.js";
import { _ as _sfc_main$d } from "./PasswordBridge.41db8c1b.js";
import { L as LoginTimestamp } from "./login_timestamp.410697ca.js";
import { P as Password } from "./password.cda421c2.js";
import { u as useI18n } from "./vue-i18n.runtime.8c1649dd.js";
import { O as Owner } from "./owner.bc60a389.js";
import "./use-timeout.0aac84f1.js";
import "./use-dark.ea7d71c2.js";
import "./QInput.c11607b6.js";
import "./private.use-form.4c048d1b.js";
import "./index.f58c37d0.js";
import "./_commonjsHelpers.294d03c4.js";
import "./use-checkbox.7dc62ae3.js";
import "./verify.2de89a24.js";
const _OriginRpcMicrochain = class {
};
let OriginRpcMicrochain = _OriginRpcMicrochain;
__publicField(OriginRpcMicrochain, "formalize", async (origin) => {
  const microchains = await dbBase.rpcMicrochains.where("origin").equals(origin).toArray();
  if (microchains.length > 1) {
    for (const microchain of microchains) {
      await dbBase.rpcMicrochains.delete(microchain.id);
    }
  }
});
__publicField(OriginRpcMicrochain, "create", async (origin, publicKey, microchain) => {
  await _OriginRpcMicrochain.formalize(origin);
  const _microchain = await dbBase.rpcMicrochains.where("origin").equals(origin).first() || {
    origin,
    publicKey,
    microchain
  };
  _microchain.microchain = microchain;
  _microchain.id === void 0 ? await dbBase.rpcMicrochains.add(_microchain) : await dbBase.rpcMicrochains.update(_microchain.id, _microchain);
});
__publicField(OriginRpcMicrochain, "delete", async (id) => {
  await dbBase.rpcMicrochains.delete(id);
});
__publicField(OriginRpcMicrochain, "getOriginRpcMicrochain", async (origin) => {
  return await dbBase.rpcMicrochains.where("origin").equals(origin).first();
});
class RpcAuth {
}
__publicField(RpcAuth, "create", async (origin, publicKey, method, applicationId, operation, persistAuth) => {
  const microchain = (await dbBase.rpcMicrochains.toArray()).find(
    (el) => el.origin === origin
  )?.microchain;
  if (!microchain)
    return;
  await dbBase.rpcAuths.add({
    origin,
    publicKey,
    chainId: microchain,
    method,
    applicationId,
    operation,
    expiredAt: persistAuth ? Date.now() + 24 * 3600 * 1e3 : 0
  });
});
__publicField(RpcAuth, "delete", async (id) => {
  await dbBase.rpcAuths.delete(id);
});
__publicField(RpcAuth, "rpcMicrochain", async (origin, publicKey) => {
  return (await dbBase.rpcMicrochains.toArray()).find(
    (el) => el.origin === origin && el.publicKey === publicKey
  )?.microchain;
});
__publicField(RpcAuth, "originPublicKeys", async (origin) => {
  return (await dbBase.rpcMicrochains.toArray()).filter((el) => el.origin === origin).map((el) => el.publicKey).reduce((ids, el) => {
    if (!ids.includes(el))
      ids.push(el);
    return ids;
  }, []);
});
__publicField(RpcAuth, "authenticated", async (origin, method, applicationId, operation) => {
  if (method === RpcMethod.LINERA_GRAPHQL_MUTATION && !operation)
    return Promise.reject("Invalid operation");
  return (await dbBase.rpcAuths.toArray()).findIndex(
    (el) => el.origin === origin && el.method === method && (applicationId === void 0 || el.applicationId === applicationId) && (operation === void 0 || el.operation === operation) && el.expiredAt > Date.now()
  ) >= 0;
});
__publicField(RpcAuth, "originMicrochains", async (origin) => {
  return (await dbBase.rpcMicrochains.toArray()).filter((el) => el.origin === origin).map((el) => el.microchain);
});
const _hoisted_1$a = { class: "row full-width" };
const _hoisted_2$7 = { style: { marginLeft: "16px", width: "calc(100% - 52px)" } };
const _hoisted_3$7 = { class: "text-bold word-break-all" };
const _hoisted_4$7 = { class: "text-blue-6 word-break-all" };
const _sfc_main$a = defineComponent({
  __name: "PopupHeader",
  setup(__props) {
    const connection = computed(() => localStore.popup.currentConnection);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$a, [
        createVNode(QImg, {
          src: connection.value?.favicon,
          width: "36px",
          height: "36px"
        }, null, 8, ["src"]),
        createBaseVNode("div", _hoisted_2$7, [
          createBaseVNode("div", _hoisted_3$7, toDisplayString(connection.value?.name), 1),
          createBaseVNode("div", _hoisted_4$7, toDisplayString(connection.value?.origin), 1)
        ])
      ]);
    };
  }
});
const _hoisted_1$9 = { class: "text-center full-width page-y-padding" };
const _sfc_main$9 = defineComponent({
  __name: "OwnerSelector",
  props: {
    "modelValue": {},
    "modelModifiers": {}
  },
  emits: ["update:modelValue"],
  setup(__props) {
    const owner = useModel(__props, "modelValue");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$9, [
        createVNode(_sfc_main$b, {
          searchable: false,
          "show-action": false,
          persistent: false,
          modelValue: owner.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => owner.value = $event)
        }, null, 8, ["modelValue"])
      ]);
    };
  }
});
const _hoisted_1$8 = { class: "text-center full-width page-y-padding full-height" };
const _sfc_main$8 = defineComponent({
  __name: "MicrochainSelector",
  props: /* @__PURE__ */ mergeModels({
    owner: {}
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const props = __props;
    const owner = toRef(props, "owner");
    const microchain = useModel(__props, "modelValue");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$8, [
        createVNode(MicrochainsInnerView, {
          owner: owner.value,
          searchable: false,
          modelValue: microchain.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => microchain.value = $event),
          "show-selected": true
        }, null, 8, ["owner", "modelValue"])
      ]);
    };
  }
});
const _hoisted_1$7 = { class: "full-width text-left selector-y-padding" };
const _hoisted_2$6 = { class: "text-left" };
const _hoisted_3$6 = { class: "text-bold label-text-middle" };
const _hoisted_4$6 = { key: 0 };
const _sfc_main$7 = defineComponent({
  __name: "CheckboxView",
  props: /* @__PURE__ */ mergeModels({
    text: {},
    caption: {}
  }, {
    "modelValue": { type: Boolean },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const checked = useModel(__props, "modelValue");
    const props = __props;
    const text = toRef(props, "text");
    const caption = toRef(props, "caption");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$7, [
        createVNode(QCheckbox, {
          modelValue: checked.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => checked.value = $event),
          class: "cursor-pointer",
          "checked-icon": "task_alt",
          "unchecked-icon": "highlight_off"
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_2$6, [
              createBaseVNode("div", _hoisted_3$6, toDisplayString(text.value), 1),
              caption.value ? (openBlock(), createElementBlock("div", _hoisted_4$6, toDisplayString(caption.value), 1)) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
});
const _hoisted_1$6 = { class: "text-center full-height" };
const _hoisted_2$5 = {
  key: 0,
  class: "full-height"
};
const _hoisted_3$5 = {
  key: 1,
  class: "full-height"
};
const _hoisted_4$5 = {
  key: 2,
  class: "full-height page-x-padding"
};
const _hoisted_5$5 = { class: "selector-y-padding" };
const _hoisted_6$4 = {
  key: 3,
  class: "full-height"
};
const _hoisted_7$3 = {
  key: 0,
  class: "extra-bottom-margin page-x-padding"
};
const _sfc_main$6 = defineComponent({
  __name: "EthRequestAccountsConfirmation",
  props: {
    "title": {},
    "titleModifiers": {}
  },
  emits: ["update:title"],
  setup(__props) {
    const step = ref(1);
    const allowCheckAccount = ref(false);
    const origin = computed(() => localStore.popup.popupOrigin);
    const method = computed(() => localStore.popup._popupRequest);
    const respond = computed(() => localStore.popup._popupRespond);
    const processing = ref(false);
    const title = useModel(__props, "title");
    const owner = ref(void 0);
    const microchain = ref(void 0);
    const onNextStepClick = async () => {
      step.value += 1;
      if (step.value === 3) {
        await OriginRpcMicrochain.create(
          localStore.popup.popupOrigin,
          owner.value?.address,
          microchain.value?.microchain
        );
      }
      if (step.value === 4) {
        processing.value = true;
        setTimeout(() => {
          processing.value = false;
          void respond.value?.({
            code: 0
          });
          void RpcAuth.create(origin.value, owner.value?.address, method.value, void 0, void 0, true);
          localStore.popup.removeRequest(localStore.popup.popupRequestId);
        }, 100);
      }
    };
    const onCancelClick = () => {
      void respond.value?.({
        code: -1,
        message: "Canceled by user"
      });
      localStore.popup.removeRequest(localStore.popup.popupRequestId);
    };
    const forwardable = () => {
      if (step.value === 1) {
        return owner.value !== void 0;
      }
      if (step.value === 2) {
        return microchain.value !== void 0;
      }
      if (step.value === 3) {
        return allowCheckAccount.value;
      }
      return false;
    };
    const actionHeight = ref(0);
    const onActionResize = (size) => {
      actionHeight.value = size.height;
    };
    onMounted(async () => {
      title.value = "Select Linera account";
      const rpcMicrochain = await OriginRpcMicrochain.getOriginRpcMicrochain(origin.value);
      if (!rpcMicrochain)
        return;
      microchain.value = await Microchain.microchain(rpcMicrochain.microchain);
    });
    watch(step, () => {
      switch (step.value) {
        case 1:
          title.value = "Select account";
          return;
        case 2:
          title.value = "Select microchain";
          return;
        case 3:
          title.value = "Permissions";
          return;
        case 4:
          title.value = "Authenticating";
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$6, [
        createBaseVNode("div", {
          style: normalizeStyle({ height: "calc(100% - " + actionHeight.value + "px)" })
        }, [
          step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_2$5, [
            createVNode(_sfc_main$9, {
              modelValue: owner.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => owner.value = $event)
            }, null, 8, ["modelValue"])
          ])) : createCommentVNode("", true),
          step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_3$5, [
            createVNode(_sfc_main$8, {
              owner: owner.value?.owner,
              modelValue: microchain.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => microchain.value = $event)
            }, null, 8, ["owner", "modelValue"])
          ])) : createCommentVNode("", true),
          step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_4$5, [
            createBaseVNode("div", _hoisted_5$5, [
              createVNode(_sfc_main$7, {
                text: _ctx.$t("MSG_ACCESS_ALLOWED_ACCOUNT_INFORMATION"),
                caption: `Requested now for ${unref(shortid).shortId(owner.value?.address, 4)}`,
                modelValue: allowCheckAccount.value,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => allowCheckAccount.value = $event)
              }, null, 8, ["text", "caption", "modelValue"])
            ])
          ])) : createCommentVNode("", true),
          step.value === 4 ? (openBlock(), createElementBlock("div", _hoisted_6$4, [
            createVNode(_sfc_main$c, { processing: processing.value }, null, 8, ["processing"])
          ])) : createCommentVNode("", true)
        ], 4),
        step.value < 4 ? (openBlock(), createElementBlock("div", _hoisted_7$3, [
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            label: _ctx.$t("MSG_CONTINUE"),
            class: "btn full-width vertical-items-margin",
            onClick: onNextStepClick,
            disable: !forwardable(),
            "no-caps": ""
          }, null, 8, ["label", "disable"]),
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            outlined: "",
            label: _ctx.$t("MSG_CANCEL"),
            class: "btn btn-alt full-width vertical-items-margin",
            onClick: onCancelClick,
            "no-caps": ""
          }, null, 8, ["label"]),
          createVNode(QResizeObserver, { onResize: onActionResize })
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$5 = { class: "text-black text-bold label-text-middle" };
const _hoisted_2$4 = { class: "vertical-items-margin" };
const _hoisted_3$4 = { class: "text-black text-bold label-text-middle vertical-menus-margin" };
const _hoisted_4$4 = { class: "vertical-items-margin" };
const _hoisted_5$4 = { class: "text-black text-bold label-text-middle vertical-menus-margin" };
const _hoisted_6$3 = { class: "vertical-items-margin" };
const _hoisted_7$2 = { class: "text-black text-bold label-text-middle vertical-menus-margin" };
const _hoisted_8$1 = { class: "vertical-items-margin word-break-all" };
const _hoisted_9 = ["innerHTML"];
const _hoisted_10 = { class: "text-black text-bold label-text-middle vertical-menus-margin" };
const _hoisted_11 = { class: "vertical-items-margin word-break-all" };
const _hoisted_12 = ["innerHTML"];
const _sfc_main$5 = defineComponent({
  __name: "MutationInfoView",
  props: {
    publicKey: {},
    applicationId: {},
    microchainId: {},
    graphqlQuery: {},
    graphqlVariables: {}
  },
  setup(__props) {
    const props = __props;
    const publicKey = toRef(props, "publicKey");
    const applicationId = toRef(props, "applicationId");
    const microchainId = toRef(props, "microchainId");
    const graphqlQuery = toRef(props, "graphqlQuery");
    const graphqlVariables = toRef(props, "graphqlVariables");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, {
        flat: "",
        class: "full-width text-left full-hight page-x-padding page-y-padding word-break-all overflow-scroll"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$5, toDisplayString(_ctx.$t("MSG_ACCOUNT")), 1),
          createBaseVNode("div", _hoisted_2$4, toDisplayString(publicKey.value), 1),
          createBaseVNode("div", _hoisted_3$4, toDisplayString(_ctx.$t("MSG_APPLICATION_ID")), 1),
          createBaseVNode("div", _hoisted_4$4, toDisplayString(applicationId.value), 1),
          createBaseVNode("div", _hoisted_5$4, toDisplayString(_ctx.$t("MSG_MICROCHAIN_ID")), 1),
          createBaseVNode("div", _hoisted_6$3, toDisplayString(microchainId.value), 1),
          createBaseVNode("div", _hoisted_7$2, toDisplayString(_ctx.$t("MSG_QUERY")), 1),
          createBaseVNode("div", _hoisted_8$1, [
            createBaseVNode("pre", { innerHTML: graphqlQuery.value }, null, 8, _hoisted_9)
          ]),
          createBaseVNode("div", _hoisted_10, toDisplayString(_ctx.$t("MSG_VARIABLES")), 1),
          createBaseVNode("div", _hoisted_11, [
            createBaseVNode("pre", {
              innerHTML: JSON.stringify(graphqlVariables.value, null, 2)
            }, null, 8, _hoisted_12),
            _cache[0] || (_cache[0] = createTextVNode("' "))
          ])
        ]),
        _: 1
      });
    };
  }
});
const _hoisted_1$4 = { class: "text-center full-height" };
const _hoisted_2$3 = {
  key: 0,
  class: "full-height page-x-padding overflow-scroll"
};
const _hoisted_3$3 = { class: "selector-y-padding" };
const _hoisted_4$3 = {
  key: 1,
  class: "full-height"
};
const _hoisted_5$3 = {
  key: 2,
  class: "full-height overflow-scroll"
};
const _hoisted_6$2 = { key: 1 };
const _hoisted_7$1 = { class: "page-actions-padding" };
const _hoisted_8 = {
  key: 0,
  class: "page-x-padding"
};
const _sfc_main$4 = defineComponent({
  __name: "LineraGraphqlMutationConfirmation",
  props: {
    "title": {},
    "titleModifiers": {}
  },
  emits: ["update:title"],
  setup(__props) {
    const step = ref(1);
    const allowMutateWallet = ref(false);
    const persistAuthentication = ref(false);
    const respond = computed(() => localStore.popup._popupRespond);
    const origin = computed(() => localStore.popup.popupOrigin);
    const method = computed(() => localStore.popup._popupRequest);
    const request = computed(() => localStore.popup._popupPayload?.data);
    const applicationId = computed(() => lineraGraphqlQueryApplicationId(request.value?.request));
    const operation = computed(() => lineraGraphqlMutationOperation(request.value?.request));
    const graphqlQuery = computed(() => {
      return lineraGraphqlQuery(request.value?.request)?.query;
    });
    const graphqlVariables = computed(() => lineraGraphqlQuery(request.value?.request)?.variables);
    const publicKey = ref(lineraGraphqlQueryPublicKey(request.value?.request));
    const popupOperation = computed(() => localStore.popup._popupPrivData);
    const popupUpdated = computed(() => localStore.popup._popupUpdated);
    const operationState = ref(OperationState.FAILED);
    const microchain = ref(void 0);
    const processing = ref(false);
    const shouldPersist = computed(() => !["Approve", "Transfer", "Swap"].includes(operation.value));
    const title = useModel(__props, "title");
    const createRpcAuth = async () => {
      const _respond = respond.value;
      try {
        await RpcAuth.create(
          origin.value,
          publicKey.value,
          method.value,
          applicationId.value,
          operation.value,
          persistAuthentication.value
        );
        void _respond?.({
          code: 0
        });
      } catch (e) {
        void _respond?.({
          code: -1,
          message: e.message
        });
      }
    };
    const checkOperationState = async () => {
      return new Promise((resolve, reject) => {
        if (!popupOperation.value)
          return reject("Invalid operation");
        ChainOperation.get(popupOperation.value.operationId).then((operation2) => {
          if (!operation2) {
            return resolve({ operation: operation2, executed: false });
          }
          if (operation2?.state > OperationState.EXECUTED) {
            operationState.value = operation2?.state;
            return resolve({ operation: operation2, executed: true });
          }
          resolve({ operation: operation2, executed: false });
        }).catch((e) => {
          reject(e);
        });
      });
    };
    const checkOperation = () => {
      if (!popupUpdated.value) {
        return window.setTimeout(checkOperation, 100);
      }
      checkOperationState().then(({ operation: operation2, executed }) => {
        if (!operation2 || executed) {
          processing.value = false;
          return;
        }
        window.setTimeout(checkOperation, 100);
      }).catch((e) => {
        processing.value = false;
        console.log("Failed check operation", e);
      });
    };
    const respondOperation = () => {
      const _respond = respond.value;
      checkOperationState().then(({ operation: operation2 }) => {
        localStore.popup.removeRequest(localStore.popup.popupRequestId);
        if (operation2?.state === OperationState.FAILED) {
          void _respond?.({
            code: -1,
            message: operation2.failReason
          });
          return;
        }
        void _respond?.({
          code: 0
        });
      }).catch((e) => {
        localStore.popup.removeRequest(localStore.popup.popupRequestId);
        void _respond?.({
          code: -1,
          message: e.message
        });
      });
    };
    const onNextStepClick = async () => {
      if (step.value === 1) {
        step.value += 1;
      }
      if (step.value === 2) {
        processing.value = true;
        await createRpcAuth();
        window.setTimeout(() => {
          processing.value = false;
          step.value += 1;
          processing.value = true;
          checkOperation();
        }, 100);
      }
      if (step.value === 3) {
        respondOperation();
      }
    };
    const onCancelClick = () => {
      void respond.value?.({
        code: -1,
        message: "Canceled by user"
      });
      localStore.popup.removeRequest(localStore.popup.popupRequestId);
    };
    const forwardable = () => {
      if (step.value === 1) {
        return publicKey.value?.length && allowMutateWallet.value;
      }
      if (step.value === 3) {
        return !processing.value;
      }
      return false;
    };
    const actionHeight = ref(0);
    const onActionResize = (size) => {
      actionHeight.value = size.height;
    };
    onMounted(async () => {
      title.value = "Permissions";
      publicKey.value = lineraGraphqlQueryPublicKey(request.value.request);
      const rpcMicrochain = await OriginRpcMicrochain.getOriginRpcMicrochain(origin.value);
      microchain.value = rpcMicrochain?.microchain;
      if (!publicKey.value?.length) {
        publicKey.value = rpcMicrochain?.publicKey;
      }
      if (publicKey.value !== rpcMicrochain?.publicKey) {
        console.log("Different public key may cause error when submit block");
      }
    });
    watch(step, () => {
      switch (step.value) {
        case 1:
          title.value = "Permissions";
          return;
        case 2:
          title.value = "Authenticating";
          return;
        case 3:
          title.value = "Executing";
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createBaseVNode("div", {
          style: normalizeStyle({ height: "calc(100% - " + (step.value !== 2 ? actionHeight.value : 0) + "px)" })
        }, [
          step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_2$3, [
            createBaseVNode("div", _hoisted_3$3, [
              createVNode(_sfc_main$7, {
                text: operation.value,
                caption: `Requested now for ${unref(shortid).shortId(publicKey.value || "", 4)}`,
                modelValue: allowMutateWallet.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => allowMutateWallet.value = $event)
              }, null, 8, ["text", "caption", "modelValue"]),
              shouldPersist.value ? (openBlock(), createBlock(_sfc_main$7, {
                key: 0,
                text: "Use the same selection for future requests",
                modelValue: persistAuthentication.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => persistAuthentication.value = $event)
              }, null, 8, ["modelValue"])) : createCommentVNode("", true),
              createVNode(_sfc_main$5, {
                "public-key": publicKey.value,
                "application-id": applicationId.value,
                "microchain-id": microchain.value,
                "graphql-query": graphqlQuery.value,
                "graphql-variables": graphqlVariables.value
              }, null, 8, ["public-key", "application-id", "microchain-id", "graphql-query", "graphql-variables"])
            ])
          ])) : createCommentVNode("", true),
          step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_4$3, [
            createVNode(_sfc_main$c, { processing: processing.value }, null, 8, ["processing"])
          ])) : createCommentVNode("", true),
          step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_5$3, [
            processing.value ? (openBlock(), createBlock(_sfc_main$c, {
              key: 0,
              processing: processing.value
            }, null, 8, ["processing"])) : (openBlock(), createElementBlock("div", _hoisted_6$2, [
              createBaseVNode("div", _hoisted_7$1, [
                createVNode(QIcon, {
                  name: operationState.value === unref(dbModel).OperationState.FAILED ? "bi-x-circle-fill" : "bi-check-circle-fill",
                  size: "36px",
                  color: operationState.value === unref(dbModel).OperationState.FAILED ? "red" : "green"
                }, null, 8, ["name", "color"])
              ]),
              createVNode(_sfc_main$5, {
                "public-key": publicKey.value,
                "application-id": applicationId.value,
                "microchain-id": microchain.value,
                "graphql-query": graphqlQuery.value,
                "graphql-variables": graphqlVariables.value
              }, null, 8, ["public-key", "application-id", "microchain-id", "graphql-query", "graphql-variables"])
            ]))
          ])) : createCommentVNode("", true)
        ], 4),
        step.value < 4 && step.value !== 2 ? (openBlock(), createElementBlock("div", _hoisted_8, [
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            label: _ctx.$t("MSG_CONTINUE"),
            class: "btn full-width vertical-items-margin",
            onClick: onNextStepClick,
            disable: !forwardable(),
            "no-caps": ""
          }, null, 8, ["label", "disable"]),
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            outlined: "",
            label: _ctx.$t("MSG_CANCEL"),
            class: "btn btn-alt full-width vertical-items-margin extra-bottom-margin",
            onClick: onCancelClick,
            "no-caps": ""
          }, null, 8, ["label"]),
          createVNode(QResizeObserver, { onResize: onActionResize })
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$3 = {
  key: 0,
  class: "vertical-items-margin text-bold"
};
const _sfc_main$3 = defineComponent({
  __name: "VerifyPassword",
  props: /* @__PURE__ */ mergeModels({
    title: { default: "" },
    showTitle: { type: Boolean, default: true },
    checkLoginTimeout: { type: Boolean, default: false }
  }, {
    "password": { default: "" },
    "passwordModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["verified", "error", "cancel"], ["update:password"]),
  setup(__props, { emit: __emit }) {
    const { t } = useI18n({ useScope: "global" });
    const props = __props;
    const title = toRef(props, "title");
    const showTitle = toRef(props, "showTitle");
    const checkLoginTimeout = toRef(props, "checkLoginTimeout");
    const password = useModel(__props, "password");
    const shadowPassword = ref("");
    const emit = __emit;
    const passwordError = ref(false);
    const passwordBridge = ref();
    watch(shadowPassword, () => {
      password.value = shadowPassword.value;
    });
    const onVerifyClick = async () => {
      if (await Password.verify(password.value)) {
        await LoginTimestamp.save();
        emit("verified");
      } else {
        emit("error");
        localStore.notification.pushNotification({
          Title: t("MSG_VERIFY_PASSWORD"),
          Message: t("MSG_FAILED_VERIFY_PASSWORD"),
          Popup: true,
          Type: localStore.notify.NotifyType.Error
        });
      }
    };
    const onCancelClick = () => {
      emit("cancel");
    };
    const actionHeight = ref(0);
    const onActionResize = (size) => {
      actionHeight.value = size.height;
    };
    onMounted(async () => {
      if (checkLoginTimeout.value) {
        if (!await LoginTimestamp.loginTimeout()) {
          password.value = await Password.password();
          emit("verified");
        }
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, {
          flat: "",
          class: "text-center fill-parent"
        }, {
          default: withCtx(() => [
            showTitle.value ? (openBlock(), createElementBlock("h5", _hoisted_1$3, toDisplayString(title.value), 1)) : createCommentVNode("", true),
            createBaseVNode("div", {
              class: normalizeClass([showTitle.value ? "vertical-sections-margin" : "flex items-center justify-center"]),
              style: normalizeStyle({ height: "calc(100% - " + (showTitle.value ? "80px - " : "") + actionHeight.value + "px)" })
            }, [
              createVNode(_sfc_main$e, {
                password: shadowPassword.value,
                "onUpdate:password": _cache[0] || (_cache[0] = ($event) => shadowPassword.value = $event),
                error: passwordError.value,
                "onUpdate:error": _cache[1] || (_cache[1] = ($event) => passwordError.value = $event)
              }, null, 8, ["password", "error"])
            ], 6),
            createBaseVNode("div", null, [
              createVNode(QBtn, {
                flat: "",
                class: "btn full-width vertical-sections-margin",
                label: _ctx.$t("MSG_VERIFY"),
                onClick: onVerifyClick,
                disable: passwordError.value,
                "no-caps": ""
              }, null, 8, ["label", "disable"]),
              createVNode(QBtn, {
                flat: "",
                class: "btn btn-alt full-width vertical-items-margin",
                label: _ctx.$t("MSG_CANCEL"),
                onClick: onCancelClick,
                "no-caps": ""
              }, null, 8, ["label"]),
              createVNode(QResizeObserver, { onResize: onActionResize })
            ])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$d, {
          ref_key: "passwordBridge",
          ref: passwordBridge
        }, null, 512)
      ], 64);
    };
  }
});
const _hoisted_1$2 = { class: "text-black text-bold label-text-middle" };
const _hoisted_2$2 = { class: "vertical-items-margin" };
const _hoisted_3$2 = { class: "text-black text-bold label-text-middle vertical-menus-margin" };
const _hoisted_4$2 = { class: "vertical-items-margin" };
const _hoisted_5$2 = { class: "text-black text-bold label-text-middle vertical-menus-margin" };
const _hoisted_6$1 = { class: "vertical-items-margin" };
const _sfc_main$2 = defineComponent({
  __name: "SignInfoView",
  props: {
    publicKey: {},
    utf8Content: {},
    hexContent: {}
  },
  setup(__props) {
    const props = __props;
    const publicKey = toRef(props, "publicKey");
    const utf8Content = toRef(props, "utf8Content");
    const hexContent = toRef(props, "hexContent");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, {
        flat: "",
        class: "full-width text-left full-hight page-x-padding page-y-padding word-break-all overflow-scroll"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$2, toDisplayString(_ctx.$t("MSG_ACCOUNT")), 1),
          createBaseVNode("div", _hoisted_2$2, toDisplayString(publicKey.value), 1),
          createBaseVNode("div", _hoisted_3$2, toDisplayString(_ctx.$t("MSG_CONTENT")), 1),
          createBaseVNode("div", _hoisted_4$2, toDisplayString(utf8Content.value), 1),
          createBaseVNode("div", _hoisted_5$2, toDisplayString(_ctx.$t("MSG_ENCODED")), 1),
          createBaseVNode("div", _hoisted_6$1, toDisplayString(hexContent.value), 1)
        ]),
        _: 1
      });
    };
  }
});
const _hoisted_1$1 = {
  class: "text-center",
  style: { height: "100%" }
};
const _hoisted_2$1 = {
  key: 0,
  class: "full-height overflow-scroll"
};
const _hoisted_3$1 = {
  key: 1,
  class: "full-height page-x-padding"
};
const _hoisted_4$1 = {
  key: 2,
  class: "full-height"
};
const _hoisted_5$1 = {
  key: 0,
  class: "page-x-padding"
};
const _sfc_main$1 = defineComponent({
  __name: "EthSignConfirmation",
  props: {
    "title": {},
    "titleModifiers": {}
  },
  emits: ["update:title"],
  setup(__props) {
    const step = ref(1);
    const origin = computed(() => localStore.popup.popupOrigin);
    const method = computed(() => localStore.popup._popupRequest);
    const respond = computed(() => localStore.popup._popupRespond);
    const request = computed(() => localStore.popup._popupPayload?.data?.request?.request);
    const account = computed(() => request.value?.params?.[0]?.toString());
    const publicKey = ref(account.value || "");
    const hexContent = computed(() => request.value?.params?.[1]?.toString());
    const utf8Content = computed(() => Web3.utils.hexToUtf8(hexContent.value?.toString() || ""));
    const password = ref("");
    const passwordVerified = ref(false);
    const processing = ref(false);
    const title = useModel(__props, "title");
    const onVerifyPasswordError = () => {
      onCancelClick();
    };
    const signResponse = async () => {
      const _account = await Owner.ownerWithPublicKeyPrefix(publicKey.value);
      if (!_account) {
        return onCancelClick();
      }
      const privateKeyHex = privateKey(_account, password.value);
      const bytes = _Web3.hexToBytes(hexContent.value);
      const signature = await Ed25519.signWithKeccac256Hash(privateKeyHex, bytes);
      setTimeout(() => {
        processing.value = false;
        void respond.value?.({
          code: 0,
          message: signature
        });
        void RpcAuth.create(origin.value, publicKey.value, method.value);
        localStore.popup.removeRequest(localStore.popup.popupRequestId);
      }, 100);
    };
    const onPasswordVerified = async () => {
      passwordVerified.value = true;
      step.value += 1;
      processing.value = true;
      await signResponse();
    };
    const onNextStepClick = () => {
      step.value += 1;
    };
    const onCancelClick = () => {
      void respond.value?.({
        code: -1,
        message: "Canceled by user"
      });
      localStore.popup.removeRequest(localStore.popup.popupRequestId);
    };
    const forwardable = () => {
      if (step.value === 1) {
        return publicKey.value?.length > 0;
      }
      if (step.value === 2) {
        return passwordVerified.value;
      }
      return false;
    };
    const actionHeight = ref(0);
    const onActionResize = (size) => {
      actionHeight.value = size.height;
    };
    onMounted(() => {
      title.value = "Sign message";
    });
    watch(step, () => {
      switch (step.value) {
        case 1:
          title.value = "Sign message";
          return;
        case 2:
          title.value = "Confirm password";
          return;
        case 3:
          title.value = "Signing";
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", {
          style: normalizeStyle({ height: "calc(100% - " + (step.value !== 2 ? actionHeight.value : 0) + "px)" })
        }, [
          step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_2$1, [
            createVNode(_sfc_main$2, {
              "public-key": publicKey.value,
              "utf8-content": utf8Content.value,
              "hex-content": hexContent.value
            }, null, 8, ["public-key", "utf8-content", "hex-content"])
          ])) : createCommentVNode("", true),
          step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_3$1, [
            createVNode(_sfc_main$3, {
              "show-title": false,
              onVerified: onPasswordVerified,
              onError: onVerifyPasswordError,
              password: password.value,
              "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
              "check-login-timeout": true
            }, null, 8, ["password"])
          ])) : createCommentVNode("", true),
          step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_4$1, [
            createVNode(_sfc_main$c, { processing: processing.value }, null, 8, ["processing"])
          ])) : createCommentVNode("", true)
        ], 4),
        step.value < 3 && step.value !== 2 ? (openBlock(), createElementBlock("div", _hoisted_5$1, [
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            label: _ctx.$t("MSG_CONTINUE"),
            class: "btn full-width vertical-items-margin",
            onClick: onNextStepClick,
            disable: !forwardable(),
            "no-caps": ""
          }, null, 8, ["label", "disable"]),
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            outlined: "",
            label: _ctx.$t("MSG_CANCEL"),
            class: "btn btn-alt full-width vertical-items-margin extra-bottom-margin",
            onClick: onCancelClick,
            "no-caps": ""
          }, null, 8, ["label"]),
          createVNode(QResizeObserver, { onResize: onActionResize })
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1 = { class: "bg-grey-2 full-height" };
const _hoisted_2 = { class: "bg-white full-width page-x-padding popup-header" };
const _hoisted_3 = { class: "text-bold label-text-large popup-title text-center" };
const _hoisted_4 = {
  key: 0,
  class: "popup-body full-width"
};
const _hoisted_5 = {
  key: 1,
  class: "popup-body full-width"
};
const _hoisted_6 = {
  key: 2,
  class: "popup-body full-width"
};
const _hoisted_7 = { class: "label-text-small text-center like-link bg-white popup-tip" };
const _sfc_main = defineComponent({
  __name: "PopupPage",
  setup(__props) {
    const title = ref("");
    const popupCount = computed(() => localStore.popup.popups.size);
    const popupType = computed(() => localStore.popup._popupType);
    const popupRequest = computed(() => localStore.popup._popupRequest);
    const closeTimeout = ref(-1);
    const quasar = useQuasar();
    watch(popupCount, () => {
      if (popupCount.value > 0) {
        if (closeTimeout.value >= 0) {
          window.clearTimeout(closeTimeout.value);
        }
        return;
      }
      closeTimeout.value = window.setTimeout(() => {
        window.close();
      }, 100);
    });
    const handleUpdateRequest = (payload) => {
      switch (payload.data.type) {
        case PopupRequestType.EXECUTION:
          if (!localStore.popup.updateRequest(payload)) {
            return void payload.respond({
              code: -1,
              message: "Invalid request"
            });
          }
          break;
        default:
          return void payload.respond({
            code: -1,
            message: "Invalid request"
          });
      }
    };
    onMounted(() => {
      quasar.bex?.on("popup.update", handleUpdateRequest);
    });
    onUnmounted(() => {
      quasar.bex?.off("popup.update", handleUpdateRequest);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createVNode(_sfc_main$a)
        ]),
        createBaseVNode("div", _hoisted_3, toDisplayString(title.value), 1),
        popupType.value === PopupRequestType.CONFIRMATION && popupRequest.value === RpcMethod.ETH_REQUEST_ACCOUNTS ? (openBlock(), createElementBlock("div", _hoisted_4, [
          createVNode(_sfc_main$6, {
            title: title.value,
            "onUpdate:title": _cache[0] || (_cache[0] = ($event) => title.value = $event)
          }, null, 8, ["title"])
        ])) : createCommentVNode("", true),
        popupType.value === PopupRequestType.CONFIRMATION && popupRequest.value === RpcMethod.LINERA_GRAPHQL_MUTATION ? (openBlock(), createElementBlock("div", _hoisted_5, [
          createVNode(_sfc_main$4, {
            title: title.value,
            "onUpdate:title": _cache[1] || (_cache[1] = ($event) => title.value = $event)
          }, null, 8, ["title"])
        ])) : createCommentVNode("", true),
        popupType.value === PopupRequestType.CONFIRMATION && popupRequest.value === RpcMethod.ETH_SIGN ? (openBlock(), createElementBlock("div", _hoisted_6, [
          createVNode(_sfc_main$1, {
            title: title.value,
            "onUpdate:title": _cache[2] || (_cache[2] = ($event) => title.value = $event)
          }, null, 8, ["title"])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_7, toDisplayString(_ctx.$t("MSG_ONLY_APPROVE_TRUSTED_APPLICATIONS")), 1)
      ]);
    };
  }
});
export { _sfc_main as default };

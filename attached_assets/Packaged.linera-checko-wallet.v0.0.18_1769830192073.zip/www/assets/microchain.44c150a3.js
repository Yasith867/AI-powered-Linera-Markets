var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { a as computed } from "./index.facf9114.js";
import { d as dbBase, a as dbWallet } from "./db.46ddc67f.js";
import { h as defaultNetwork, M as MicrochainState } from "./application.ca271889.js";
const useTransitionProps = {
  transitionShow: {
    type: String,
    default: "fade"
  },
  transitionHide: {
    type: String,
    default: "fade"
  },
  transitionDuration: {
    type: [String, Number],
    default: 300
  }
};
function useTransition(props, defaultShowFn = () => {
}, defaultHideFn = () => {
}) {
  return {
    transitionProps: computed(() => {
      const show = `q-transition--${props.transitionShow || defaultShowFn()}`;
      const hide = `q-transition--${props.transitionHide || defaultHideFn()}`;
      return {
        appear: true,
        enterFromClass: `${show}-enter-from`,
        enterActiveClass: `${show}-enter-active`,
        enterToClass: `${show}-enter-to`,
        leaveFromClass: `${hide}-leave-from`,
        leaveActiveClass: `${hide}-leave-active`,
        leaveToClass: `${hide}-leave-to`
      };
    }),
    transitionStyle: computed(() => `--q-transition-duration: ${props.transitionDuration}ms`)
  };
}
const _Network = class {
};
let Network = _Network;
__publicField(Network, "initialize", async () => {
  if (await _Network.selected())
    return;
  await dbBase.networks.add(defaultNetwork);
});
__publicField(Network, "resetSelected", async () => {
  const networks = await dbBase.networks.filter((network) => network.selected).toArray();
  for (const network of networks) {
    await dbBase.networks.update(network.id, { selected: false });
  }
});
__publicField(Network, "create", async (network) => {
  if (await _Network.exists(network.name))
    return Promise.reject("Already exists");
  if (network.selected)
    await _Network.resetSelected();
  await dbBase.networks.add(network);
});
__publicField(Network, "update", async (network) => {
  if (await _Network.exists(network.name) && !await _Network.exists(network.name, network.id))
    return Promise.reject("Already exists");
  if (network.selected)
    await _Network.resetSelected();
  await dbBase.networks.update(network.id, network);
});
__publicField(Network, "delete", async (id) => {
  await dbBase.networks.delete(id);
});
__publicField(Network, "selected", async () => {
  return (await dbBase.networks.toArray()).find((el) => el.selected);
});
__publicField(Network, "exists", async (name, id) => {
  return await dbBase.networks.where("name").equals(name).and((network) => id === void 0 || network.id === id).count() > 0;
});
__publicField(Network, "rpcEndpoint", async () => {
  const network = await _Network.selected();
  if (!network)
    return "";
  return network.rpcUrl;
});
__publicField(Network, "subscriptionEndpoint", async () => {
  const network = await _Network.selected();
  if (!network)
    return "";
  return network.rpcWsUrl;
});
class MicrochainOwner {
}
__publicField(MicrochainOwner, "ownerMicrochainOwners", async (owner) => {
  return await dbWallet.microchainOwners.where("owner").equals(owner).toArray();
});
__publicField(MicrochainOwner, "microchainOwners", async (microchain) => {
  const _microchainOwners = await dbWallet.microchainOwners.where("microchain").equals(microchain).toArray();
  if (!_microchainOwners.length)
    return [];
  const owners = _microchainOwners.reduce((ids, a) => {
    ids.push(a.owner);
    return ids;
  }, []);
  return await dbWallet.owners.where("owner").anyOf(owners).toArray();
});
__publicField(MicrochainOwner, "create", async (owner, microchain) => {
  await dbWallet.microchainOwners.add({
    microchain,
    owner,
    balance: 0
  });
});
class Microchain {
}
__publicField(Microchain, "microchains", async (offset, limit, imported, states, owner) => {
  let microchainOwners = void 0;
  if (owner) {
    microchainOwners = await dbWallet.microchainOwners.where("owner").equals(owner).toArray();
  }
  return await dbWallet.microchains.filter(
    (op) => (!owner || microchainOwners.findIndex(
      (el) => el.owner === owner && el.microchain === op.microchain
    ) >= 0) && (imported === void 0 || op.imported === imported) && (states === void 0 || states.length === 0 || states.includes(op.state))
  ).offset(offset).limit(limit || 9999).toArray();
});
__publicField(Microchain, "microchain", async (microchain) => {
  return await dbWallet.microchains.where("microchain").equals(microchain).first();
});
__publicField(Microchain, "anyMicrochain", async () => {
  return await dbWallet.microchains.offset(0).first();
});
__publicField(Microchain, "count", async () => {
  return await dbWallet.microchains.count();
});
__publicField(Microchain, "microchainOwner", async (microchain) => {
  const microchainOwners = (await dbWallet.microchainOwners.toArray()).filter(
    (el) => el.microchain === microchain
  );
  if (!microchainOwners.length)
    return void 0;
  return (await dbWallet.owners.toArray()).find(
    (el) => microchainOwners.findIndex((el1) => el1.owner === el.owner) >= 0
  );
});
__publicField(Microchain, "create", async (owner, microchainId, creatorChainId, name, _default) => {
  let microchain = await dbWallet.microchains.where("microchain").equals(microchainId).first();
  if (microchain)
    return microchain;
  const selectedNetwork = await Network.selected();
  if (!selectedNetwork)
    return Promise.reject("Invalid network");
  microchain = {
    microchain: microchainId,
    balance: 0,
    creatorChainId,
    networkId: selectedNetwork.id,
    name,
    default: _default,
    imported: true,
    state: MicrochainState.CLAIMING
  };
  await MicrochainOwner.create(owner, microchainId);
  await dbWallet.microchains.add(microchain);
  return microchain;
});
__publicField(Microchain, "update", async (microchain) => {
  await dbWallet.microchains.update(microchain.id, microchain);
});
export { Microchain as M, Network as N, useTransition as a, MicrochainOwner as b, useTransitionProps as u };

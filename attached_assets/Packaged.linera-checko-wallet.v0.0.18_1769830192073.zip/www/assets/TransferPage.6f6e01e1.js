var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { Q as QSpace } from "./QSpace.27146b0a.js";
import { t as createComponent, a as computed, h, Q as QIcon, d as defineComponent, ar as mergeModels, as as toRef, aq as useModel, H as openBlock, P as createBlock, J as withCtx, K as createBaseVNode, L as toDisplayString, k as createVNode, r as ref, I as createElementBlock, F as Fragment, M as renderList, V as createCommentVNode, _ as _export_sfc, w as watch, o as onMounted, R as createTextVNode, aw as QBtn, aF as QAvatar, u as unref, a0 as normalizeStyle, X as useRoute, W as useRouter, O as withDirectives, a_ as vShow } from "./index.facf9114.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { v as ownerFromPublicKey, s as OperationType, O as OperationState, q as dbModel } from "./application.ca271889.js";
import "./db.46ddc67f.js";
import { M as Microchain, b as MicrochainOwner } from "./microchain.44c150a3.js";
import { C as ChainOperation, b as _sfc_main$7, T as Token } from "./TokenBridge.0a26909e.js";
import { A as Account, a as _sfc_main$8, O as OwnerSelector, M as MemeApplicationOperation } from "./TokenCardView.41a4cbdd.js";
import "./index.d2b21240.js";
import { s as stringify, v as v4, Q as QBtnDropdown, a as QDialog, B as BlockWorker, d as BlockEventType } from "./block.fef35c05.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { u as useCheckboxProps, a as useCheckboxEmits, b as useCheckbox } from "./use-checkbox.7dc62ae3.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import { M as MicrochainsInnerView, s as shortid, f as _sfc_main$9, e as _sfc_main$a } from "./MicrochainsInnerView.9e5fbcce.js";
import { O as Owner } from "./owner.bc60a389.js";
import "./use-dark.ea7d71c2.js";
import "./_commonjsHelpers.294d03c4.js";
import "./index.f58c37d0.js";
import "./GenerateKey.376e5b53.js";
import "./use-panel.a32f17c8.js";
import "./selection.ef9ae985.js";
import "./use-timeout.0aac84f1.js";
import "./PasswordBridge.41db8c1b.js";
import "./position-engine.5060c7a9.js";
import "./private.use-form.4c048d1b.js";
const _Operation = class {
  static async waitOperation(operationId) {
    const operation = await ChainOperation.get(
      operationId
    );
    if (!operation)
      return Promise.reject("Invalid operation");
    if (operation?.state >= OperationState.CONFIRMED)
      return operation?.state !== OperationState.FAILED;
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        _Operation.waitOperation(operationId).then((success) => {
          resolve(success);
        }).catch((e) => {
          reject(e);
        });
      }, 1e3);
    });
  }
};
let Operation = _Operation;
__publicField(Operation, "transfer", async (fromPublicKey, fromChainId, toPublicKey, toChainId, amount) => {
  const fromOwner = fromPublicKey !== void 0 ? await ownerFromPublicKey(fromPublicKey) : void 0;
  const toOwner = toPublicKey !== void 0 ? Account.accountOwner(await ownerFromPublicKey(toPublicKey)) : void 0;
  let amountStr = stringify(amount) || "0";
  if (Number(amountStr) === 0)
    return Promise.reject("Invalid amount");
  if (!amountStr?.endsWith(".") && !amountStr?.includes(".")) {
    amountStr += ".";
  }
  const operationId = v4();
  const _fromOwner = fromOwner ? Account.accountOwner(fromOwner) : Account.CHAIN;
  const _toOwner = toOwner ? Account.accountOwner(toOwner) : Account.CHAIN;
  const operation = {
    operationType: OperationType.TRANSFER,
    operationId,
    microchain: fromChainId,
    operation: stringify({
      System: {
        Transfer: {
          owner: _fromOwner,
          recipient: {
            chainId: toChainId,
            owner: _toOwner
          },
          amount: amountStr
        }
      }
    })
  };
  await ChainOperation.create({ ...operation });
  return operationId;
});
var QToggle = createComponent({
  name: "QToggle",
  props: {
    ...useCheckboxProps,
    icon: String,
    iconColor: String
  },
  emits: useCheckboxEmits,
  setup(props) {
    function getInner(isTrue, isIndeterminate) {
      const icon = computed(
        () => (isTrue.value === true ? props.checkedIcon : isIndeterminate.value === true ? props.indeterminateIcon : props.uncheckedIcon) || props.icon
      );
      const color = computed(() => isTrue.value === true ? props.iconColor : null);
      return () => [
        h("div", { class: "q-toggle__track" }),
        h(
          "div",
          {
            class: "q-toggle__thumb absolute flex flex-center no-wrap"
          },
          icon.value !== void 0 ? [
            h(QIcon, {
              name: icon.value,
              color: color.value
            })
          ] : void 0
        )
      ];
    }
    return useCheckbox("toggle", getInner);
  }
});
const _hoisted_1$6 = { class: "text-center text-bold text-grey-9 selector-title" };
const _sfc_main$6 = defineComponent({
  __name: "MicrochainSelector",
  props: /* @__PURE__ */ mergeModels({
    owner: {}
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const owner = toRef(props, "owner");
    const microchain = useModel(__props, "modelValue");
    const emit = __emit;
    const onMicrochainSelected = (_microchain) => {
      microchain.value = _microchain;
      emit("selected", _microchain);
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, { class: "selector-card" }, {
        default: withCtx(() => [
          createBaseVNode("p", _hoisted_1$6, toDisplayString(_ctx.$t("MSG_SELECT_A_MICROCHAIN")), 1),
          createVNode(MicrochainsInnerView, {
            owner: owner.value,
            searchable: true,
            onSelected: onMicrochainSelected
          }, null, 8, ["owner"])
        ]),
        _: 1
      });
    };
  }
});
var TokenSelector_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$5 = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_2$4 = { class: "selector-search" };
const _hoisted_3$4 = { key: 0 };
const _sfc_main$5 = defineComponent({
  __name: "TokenSelector",
  props: {
    "modelValue": {},
    "modelModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const token = useModel(__props, "modelValue");
    const emit = __emit;
    const tokens = ref([]);
    const searchText = ref("");
    const displayTokens = computed(() => tokens.value.filter((el) => el.name.toLowerCase().includes(searchText.value.toLowerCase())));
    const onTokenClick = (_token) => {
      token.value = _token;
      emit("selected", _token);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, { class: "selector-card" }, {
          default: withCtx(() => [
            createBaseVNode("p", _hoisted_1$5, toDisplayString(_ctx.$t("MSG_SELECT_A_TOKEN")), 1),
            createBaseVNode("div", _hoisted_2$4, [
              createVNode(QInput, {
                dense: "",
                outlined: "",
                rounded: "",
                modelValue: searchText.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchText.value = $event)
              }, {
                prepend: withCtx(() => [
                  createVNode(QIcon, {
                    name: "bi-search",
                    size: "16px"
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            displayTokens.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_3$4, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(displayTokens.value, (_token) => {
                return openBlock(), createBlock(_sfc_main$8, {
                  key: _token.id,
                  token: _token,
                  onClick: ($event) => onTokenClick(_token),
                  "active-native": false,
                  active: token.value?.applicationId === _token.applicationId
                }, null, 8, ["token", "onClick", "active"]);
              }), 128))
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createVNode(_sfc_main$7, {
          tokens: tokens.value,
          "onUpdate:tokens": _cache[1] || (_cache[1] = ($event) => tokens.value = $event)
        }, null, 8, ["tokens"])
      ], 64);
    };
  }
});
var TokenSelector = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-b81295ac"]]);
const _hoisted_1$4 = { class: "vertical-menus-margin decorate-underline" };
const _hoisted_2$3 = { class: "row full-width" };
const _hoisted_3$3 = {
  key: 0,
  class: "header-items-margin-x-left text-left",
  style: { width: "calc(100% - 36px - 12px - 20px)" }
};
const _hoisted_4$3 = {
  key: 0,
  class: "text-grey-6 page-header-network"
};
const _hoisted_5$3 = {
  key: 1,
  class: "text-grey-6 page-header-network"
};
const _hoisted_6$3 = { class: "vertical-menus-margin decorate-underline" };
const _hoisted_7$2 = { class: "row full-width" };
const _hoisted_8$2 = {
  key: 0,
  class: "header-items-margin-x-left text-left"
};
const _hoisted_9$1 = { class: "text-grey-6 page-header-network" };
const _hoisted_10$1 = { class: "row full-width" };
const _hoisted_11$1 = {
  key: 0,
  class: "header-items-margin-x-left text-left"
};
const _hoisted_12$1 = { class: "text-grey-6 page-header-network" };
const _hoisted_13$1 = {
  key: 1,
  class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin transfer-tip text-grey-6 cursor-pointer"
};
const _hoisted_14$1 = { class: "like-link" };
const _hoisted_15$1 = {
  key: 2,
  class: "vertical-items-margin"
};
const _hoisted_16$1 = { class: "vertical-sections-margin decorate-underline row" };
const _hoisted_17$1 = { class: "vertical-menus-margin" };
const _hoisted_18$1 = { class: "row full-width" };
const _hoisted_19$1 = { class: "header-items-margin-x-left text-left" };
const _hoisted_20$1 = { class: "text-grey-6 page-header-network" };
const _hoisted_21$1 = { class: "vertical-items-margin" };
const _hoisted_22$1 = { class: "row full-width" };
const _hoisted_23$1 = { class: "header-items-margin-x-left text-left" };
const _hoisted_24$1 = { class: "text-grey-6 page-header-network" };
const _hoisted_25$1 = {
  key: 3,
  class: "vertical-items-margin"
};
const _hoisted_26$1 = { class: "page-y-padding" };
const _sfc_main$4 = defineComponent({
  __name: "SelectTransferAccount",
  props: {
    "selectedFromOwner": {},
    "selectedFromOwnerModifiers": {},
    "selectedFromMicrochain": {},
    "selectedFromMicrochainModifiers": {},
    "selectedToOwner": {},
    "selectedToOwnerModifiers": {},
    "selectedToMicrochain": {},
    "selectedToMicrochainModifiers": {},
    "toAddress": {},
    "toAddressModifiers": {},
    "toMicrochain": {},
    "toMicrochainModifiers": {},
    "fromChainBalance": { type: Boolean },
    "fromChainBalanceModifiers": {},
    "toChainBalance": { type: Boolean },
    "toChainBalanceModifiers": {},
    "selectedToken": {},
    "selectedTokenModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["next"], ["update:selectedFromOwner", "update:selectedFromMicrochain", "update:selectedToOwner", "update:selectedToMicrochain", "update:toAddress", "update:toMicrochain", "update:fromChainBalance", "update:toChainBalance", "update:selectedToken"]),
  setup(__props, { emit: __emit }) {
    const selectedFromOwner = useModel(__props, "selectedFromOwner");
    const selectedFromMicrochain = useModel(__props, "selectedFromMicrochain");
    const fromMicrochains = ref([]);
    const selectedToOwner = useModel(__props, "selectedToOwner");
    const selectedToMicrochain = useModel(__props, "selectedToMicrochain");
    const toAddress = useModel(__props, "toAddress");
    const toMicrochain = useModel(__props, "toMicrochain");
    const fromChainBalance = useModel(__props, "fromChainBalance");
    const toChainBalance = useModel(__props, "toChainBalance");
    const selectedToken = useModel(__props, "selectedToken");
    const selectingFromOwner = ref(false);
    const selectingFromMicrochain = ref(false);
    const selectingToOwner = ref(false);
    const selectingToMicrochain = ref(false);
    const selectingToken = ref(false);
    const selectedTokenLogo = ref("");
    const toMicrochainOwners = ref([]);
    const onFromAccountClick = () => {
      selectingFromOwner.value = true;
    };
    const onFromOwnerSelected = () => {
      selectingFromOwner.value = false;
    };
    const onFromMicrochainClick = () => {
      selectingFromMicrochain.value = true;
    };
    const onFromMicrochainSelected = () => {
      selectingFromMicrochain.value = false;
    };
    const onSelectToAccountClick = () => {
      selectingToOwner.value = true;
    };
    const onToAccountClick = () => {
      selectingToOwner.value = true;
    };
    const onSelectToMicrochainClick = () => {
      selectingToMicrochain.value = true;
    };
    const onToMicrochainSelected = () => {
      selectingToMicrochain.value = false;
    };
    const onToMicrochainClick = () => {
      selectingToMicrochain.value = true;
    };
    const onClearToMicrochainClick = () => {
      selectedToMicrochain.value = void 0;
      toMicrochain.value = "";
    };
    const onClearToAccountClick = () => {
      selectedToOwner.value = void 0;
      selectedToMicrochain.value = void 0;
      toAddress.value = "";
      toMicrochain.value = "";
    };
    const onToOwnerSelected = (owner) => {
      selectingToOwner.value = false;
      toAddress.value = owner?.address || "";
    };
    watch(toAddress, async () => {
      if (!toAddress.value)
        return;
      toMicrochainOwners.value = await MicrochainOwner.ownerMicrochainOwners(toAddress.value);
    });
    const onTokenClick = () => {
      selectingToken.value = true;
    };
    const onTokenSelected = () => {
      selectingToken.value = false;
    };
    watch(selectedToMicrochain, () => {
      toMicrochain.value = selectedToMicrochain.value?.microchain;
    });
    watch(selectedToken, async () => {
      selectedTokenLogo.value = await Token.logo(selectedToken.value?.id);
    });
    const canGotoNext = computed(() => {
      return selectedFromOwner.value !== void 0 && selectedFromMicrochain.value !== void 0 && toAddress.value && toAddress.value.length > 0 && toMicrochain.value && toMicrochain.value.length > 0;
    });
    watch(selectedFromOwner, async () => {
      if (!selectedFromOwner.value)
        return;
      fromMicrochains.value = await Microchain.microchains(0, 1e3, void 0, void 0, selectedFromOwner.value?.owner);
      selectedFromMicrochain.value = fromMicrochains.value.find((el) => el.default) || fromMicrochains.value[0];
    });
    watch(selectedToOwner, async () => {
      if (!selectedToOwner.value)
        return;
      const microchains = await Microchain.microchains(0, 1e3, void 0, void 0, selectedToOwner.value?.owner);
      selectedToMicrochain.value = microchains.find((el) => el.default) || microchains[0];
    });
    const emit = __emit;
    const onTransferClick = () => {
      emit("next");
    };
    onMounted(async () => {
      if (!selectedFromOwner.value) {
        selectedFromOwner.value = await Owner.selected();
      }
      if (selectedFromOwner.value) {
        fromMicrochains.value = await Microchain.microchains(0, 1e3, void 0, void 0, selectedFromOwner.value?.owner);
        selectedFromMicrochain.value = fromMicrochains.value.find((el) => el.default) || fromMicrochains.value[0];
      }
      if (selectedToOwner.value) {
        const microchains = await Microchain.microchains(0, 1e3, void 0, void 0, selectedToOwner.value?.owner);
        selectedFromMicrochain.value = microchains.find((el) => el.default) || microchains[0];
      }
      if (selectedToken.value) {
        selectedTokenLogo.value = await Token.logo(selectedToken.value?.id);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$4, toDisplayString(_ctx.$t("MSG_TOKEN")), 1),
        createVNode(QBtnDropdown, {
          flat: "",
          filled: "",
          class: "btn-alt full-width btn-radius btn-grey-border vertical-menus-margin",
          "no-caps": "",
          dense: "",
          "dropdown-icon": "bi-chevron-down",
          "menu-anchor": "bottom left",
          "menu-self": "top left",
          onClick: onTokenClick
        }, {
          label: withCtx(() => [
            createBaseVNode("div", _hoisted_2$3, [
              createVNode(QAvatar, null, {
                default: withCtx(() => [
                  selectedToken.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: selectedTokenLogo.value,
                    width: "36px",
                    height: "36px",
                    fit: "contain"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              }),
              selectedToken.value ? (openBlock(), createElementBlock("div", _hoisted_3$3, [
                createBaseVNode("div", null, toDisplayString(selectedToken.value.ticker), 1),
                selectedToken.value.native ? (openBlock(), createElementBlock("div", _hoisted_4$3, toDisplayString(selectedToken.value.name), 1)) : (openBlock(), createElementBlock("div", _hoisted_5$3, " 0x" + toDisplayString(unref(shortid).shortId(selectedToken.value.applicationId, 10)), 1))
              ])) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        }),
        createBaseVNode("div", _hoisted_6$3, toDisplayString(_ctx.$t("MSG_FROM")), 1),
        createVNode(QBtnDropdown, {
          flat: "",
          filled: "",
          class: "btn-alt full-width btn-radius btn-grey-border vertical-menus-margin",
          "no-caps": "",
          dense: "",
          "dropdown-icon": "bi-chevron-down",
          "menu-anchor": "bottom left",
          "menu-self": "top left",
          onClick: onFromAccountClick
        }, {
          label: withCtx(() => [
            createBaseVNode("div", _hoisted_7$2, [
              createVNode(QAvatar, null, {
                default: withCtx(() => [
                  selectedFromOwner.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: unref(dbModel).ownerAvatar(selectedFromOwner.value),
                    width: "36px",
                    height: "36px"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              }),
              selectedFromOwner.value ? (openBlock(), createElementBlock("div", _hoisted_8$2, [
                createBaseVNode("div", null, toDisplayString(selectedFromOwner.value.name), 1),
                createBaseVNode("div", _hoisted_9$1, " 0x" + toDisplayString(unref(shortid).shortId(selectedFromOwner.value.owner, 6)), 1)
              ])) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        }),
        fromMicrochains.value.length > 0 ? (openBlock(), createBlock(QBtnDropdown, {
          key: 0,
          flat: "",
          filled: "",
          class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin",
          "no-caps": "",
          dense: "",
          "dropdown-icon": "bi-chevron-down",
          "menu-anchor": "bottom left",
          "menu-self": "top left",
          onClick: onFromMicrochainClick
        }, {
          label: withCtx(() => [
            createBaseVNode("div", _hoisted_10$1, [
              createVNode(QAvatar, null, {
                default: withCtx(() => [
                  selectedFromMicrochain.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: unref(dbModel).microchainAvatar(selectedFromMicrochain.value),
                    width: "36px",
                    height: "36px"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              }),
              selectedFromMicrochain.value ? (openBlock(), createElementBlock("div", _hoisted_11$1, [
                createBaseVNode("div", null, toDisplayString(selectedFromMicrochain.value.name || "Microchain"), 1),
                createBaseVNode("div", _hoisted_12$1, " 0x" + toDisplayString(unref(shortid).shortId(selectedFromMicrochain.value.microchain, 6)), 1)
              ])) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        })) : (openBlock(), createElementBlock("div", _hoisted_13$1, [
          createTextVNode(toDisplayString(_ctx.$t("MSG_NO_USABLE_MICROCHAIN")) + " ", 1),
          createBaseVNode("span", _hoisted_14$1, toDisplayString(_ctx.$t("MSG_CREATE")), 1)
        ])),
        fromMicrochains.value.length > 0 && selectedToken.value?.native ? (openBlock(), createElementBlock("div", _hoisted_15$1, [
          createVNode(QToggle, {
            dense: "",
            rounded: "",
            label: _ctx.$t("MSG_SEND_FROM_MICROCHAIN_BALANCE"),
            modelValue: fromChainBalance.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => fromChainBalance.value = $event)
          }, null, 8, ["label", "modelValue"])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_16$1, toDisplayString(_ctx.$t("MSG_TO")), 1),
        createBaseVNode("div", _hoisted_17$1, [
          selectedToOwner.value === void 0 ? (openBlock(), createBlock(QInput, {
            key: 0,
            outlined: "",
            modelValue: toAddress.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => toAddress.value = $event),
            placeholder: "Input address"
          }, {
            append: withCtx(() => [
              createVNode(QBtn, {
                flat: "",
                dense: "",
                class: "text-blue-8 cursor-pointer label-text-small",
                onClick: onSelectToAccountClick
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.$t("MSG_SELECT")), 1)
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])) : (openBlock(), createBlock(QBtnDropdown, {
            key: 1,
            flat: "",
            filled: "",
            class: "btn-alt full-width btn-radius btn-grey-border",
            "no-caps": "",
            dense: "",
            "dropdown-icon": "bi-chevron-down",
            "menu-anchor": "bottom left",
            "menu-self": "top left",
            onClick: onToAccountClick
          }, {
            label: withCtx(() => [
              createBaseVNode("div", _hoisted_18$1, [
                createVNode(QAvatar, null, {
                  default: withCtx(() => [
                    selectedToOwner.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).ownerAvatar(selectedToOwner.value),
                      width: "36px",
                      height: "36px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_19$1, [
                  createBaseVNode("div", null, toDisplayString(selectedToOwner.value?.name || "Microchain"), 1),
                  createBaseVNode("div", _hoisted_20$1, " 0x" + toDisplayString(unref(shortid).shortId(selectedToOwner.value?.owner, 6)), 1)
                ]),
                createVNode(QSpace),
                createBaseVNode("div", {
                  class: "flex justify-center items-center cursor-pointer",
                  onClick: onClearToAccountClick
                }, [
                  createVNode(QIcon, {
                    name: "bi-x",
                    size: "20px"
                  })
                ])
              ])
            ]),
            _: 1
          }))
        ]),
        createBaseVNode("div", _hoisted_21$1, [
          selectedToMicrochain.value === void 0 ? (openBlock(), createBlock(QInput, {
            key: 0,
            outlined: "",
            modelValue: toMicrochain.value,
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => toMicrochain.value = $event),
            placeholder: "Input microchain ID",
            disable: !selectedToOwner.value && !toAddress.value
          }, {
            append: withCtx(() => [
              createVNode(QBtn, {
                flat: "",
                dense: "",
                disable: toMicrochainOwners.value.length === 0,
                class: "text-blue-8 cursor-pointer label-text-small",
                onClick: onSelectToMicrochainClick
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.$t("MSG_SELECT")), 1)
                ]),
                _: 1
              }, 8, ["disable"])
            ]),
            _: 1
          }, 8, ["modelValue", "disable"])) : (openBlock(), createBlock(QBtnDropdown, {
            key: 1,
            flat: "",
            filled: "",
            class: "btn-alt full-width btn-radius btn-grey-border",
            "no-caps": "",
            dense: "",
            "dropdown-icon": "bi-chevron-down",
            "menu-anchor": "bottom left",
            "menu-self": "top left",
            onClick: onToMicrochainClick
          }, {
            label: withCtx(() => [
              createBaseVNode("div", _hoisted_22$1, [
                createVNode(QAvatar, null, {
                  default: withCtx(() => [
                    selectedToMicrochain.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).microchainAvatar(selectedToMicrochain.value),
                      width: "36px",
                      height: "36px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_23$1, [
                  createBaseVNode("div", null, toDisplayString(selectedToMicrochain.value?.name || "Microchain"), 1),
                  createBaseVNode("div", _hoisted_24$1, " 0x" + toDisplayString(unref(shortid).shortId(selectedToMicrochain.value?.microchain, 6)), 1)
                ]),
                createVNode(QSpace),
                createBaseVNode("div", {
                  class: "flex justify-center items-center cursor-pointer",
                  onClick: onClearToMicrochainClick
                }, [
                  createVNode(QIcon, {
                    name: "bi-x",
                    size: "20px"
                  })
                ])
              ])
            ]),
            _: 1
          }))
        ]),
        toMicrochain.value && toMicrochain.value.length > 0 && selectedToken.value?.native ? (openBlock(), createElementBlock("div", _hoisted_25$1, [
          createVNode(QToggle, {
            dense: "",
            rounded: "",
            label: _ctx.$t("MSG_SEND_TO_MICROCHAIN_BALANCE"),
            modelValue: toChainBalance.value,
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => toChainBalance.value = $event)
          }, null, 8, ["label", "modelValue"])
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_26$1, [
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            label: _ctx.$t("MSG_CONTINUE"),
            class: "btn full-width extra-margin-bottom",
            onClick: onTransferClick,
            "no-caps": "",
            disable: !canGotoNext.value
          }, null, 8, ["label", "disable"])
        ]),
        createVNode(QDialog, {
          modelValue: selectingFromOwner.value,
          "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => selectingFromOwner.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(OwnerSelector, {
              modelValue: selectedFromOwner.value,
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => selectedFromOwner.value = $event),
              onSelected: onFromOwnerSelected,
              creatable: false,
              persistent: false
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: selectingFromMicrochain.value,
          "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => selectingFromMicrochain.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$6, {
              owner: selectedFromOwner.value?.owner,
              modelValue: selectedFromMicrochain.value,
              "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => selectedFromMicrochain.value = $event),
              onSelected: onFromMicrochainSelected
            }, null, 8, ["owner", "modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: selectingToOwner.value,
          "onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => selectingToOwner.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(OwnerSelector, {
              modelValue: selectedToOwner.value,
              "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => selectedToOwner.value = $event),
              onSelected: onToOwnerSelected,
              creatable: false,
              persistent: false
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: selectingToMicrochain.value,
          "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => selectingToMicrochain.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$6, {
              owner: selectedToOwner.value?.owner,
              modelValue: selectedToMicrochain.value,
              "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => selectedToMicrochain.value = $event),
              onSelected: onToMicrochainSelected
            }, null, 8, ["owner", "modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: selectingToken.value,
          "onUpdate:modelValue": _cache[13] || (_cache[13] = ($event) => selectingToken.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(TokenSelector, {
              modelValue: selectedToken.value,
              "onUpdate:modelValue": _cache[12] || (_cache[12] = ($event) => selectedToken.value = $event),
              onSelected: onTokenSelected
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 64);
    };
  }
});
var SetTranserAmount_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$3 = { class: "full-width" };
const _hoisted_2$2 = { class: "row text-center" };
const _hoisted_3$2 = { class: "label-text-extra-large page-item-x-margin-left" };
const _hoisted_4$2 = { class: "row tip info-bg vertical-sections-margin flax items-center justify-center" };
const _hoisted_5$2 = { class: "page-item-x-margin-left" };
const _hoisted_6$2 = {
  key: 0,
  class: "row"
};
const _hoisted_7$1 = { class: "text-grey-8" };
const _hoisted_8$1 = { class: "page-y-padding" };
const _sfc_main$3 = defineComponent({
  __name: "SetTranserAmount",
  props: /* @__PURE__ */ mergeModels({
    fromOwner: {},
    fromMicrochain: {},
    token: {}
  }, {
    "modelValue": { default: 0 },
    "modelModifiers": {},
    "fromChainBalance": { type: Boolean },
    "fromChainBalanceModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["next"], ["update:modelValue", "update:fromChainBalance"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const fromOwner = toRef(props, "fromOwner");
    const fromMicrochain = toRef(props, "fromMicrochain");
    const token = toRef(props, "token");
    const amount = useModel(__props, "modelValue");
    const fromChainBalance = useModel(__props, "fromChainBalance");
    watch(amount, () => {
      if (amount.value.toString().startsWith("0.0")) {
        if (!amount.value.toString().match(/[1-9]/)) {
          return;
        }
      }
      amount.value = Math.min(fromChainBalance.value ? chainTokenBalance.value : accountTokenBalance.value, Number(amount.value));
    });
    const inputWidth = computed(() => (Math.max(Math.min(amount.value.toString().length, 8), 2) * 16).toString() + "px");
    const chainTokenBalance = ref(0);
    const accountTokenBalance = ref(0);
    const tokenLogo = ref("");
    const dbTokenBridge = ref();
    const emit = __emit;
    const onChangeFromBalanceClick = () => {
      fromChainBalance.value = !fromChainBalance.value;
    };
    const onMaxAmountClick = () => {
      amount.value = fromChainBalance.value ? chainTokenBalance.value : accountTokenBalance.value;
    };
    const onContinueClick = () => {
      emit("next");
    };
    onMounted(async () => {
      tokenLogo.value = await Token.logo(token.value.id);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$3, [
          _cache[4] || (_cache[4] = createBaseVNode("div", { class: "transfer-amount-space" }, null, -1)),
          createBaseVNode("div", _hoisted_2$2, [
            createVNode(QSpace),
            createVNode(QInput, {
              class: "label-text-extra-large text-right",
              dense: "",
              modelValue: amount.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => amount.value = $event),
              style: normalizeStyle({ width: inputWidth.value, minWidth: "16px", maxWidth: "calc(100% - 42px)" }),
              autofocus: "",
              type: "number"
            }, null, 8, ["modelValue", "style"]),
            createBaseVNode("div", _hoisted_3$2, toDisplayString(token.value.ticker), 1),
            createVNode(QSpace)
          ]),
          _cache[5] || (_cache[5] = createBaseVNode("div", { class: "transfer-amount-space" }, null, -1)),
          createBaseVNode("div", _hoisted_4$2, [
            createVNode(QAvatar, null, {
              default: withCtx(() => [
                createVNode(QImg, {
                  src: tokenLogo.value,
                  width: "36px",
                  height: "36px",
                  fit: "contain"
                }, null, 8, ["src"])
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_5$2, [
              token.value.native ? (openBlock(), createElementBlock("div", _hoisted_6$2, [
                createBaseVNode("div", _hoisted_7$1, toDisplayString(fromChainBalance.value ? "Chain balance" : "Account balance"), 1),
                createBaseVNode("div", {
                  class: "page-item-x-margin-left cursor-pointer",
                  onClick: onChangeFromBalanceClick
                }, [
                  createVNode(QIcon, {
                    name: "bi-arrow-down-up",
                    size: "12px"
                  })
                ])
              ])) : createCommentVNode("", true),
              createBaseVNode("div", null, toDisplayString(fromChainBalance.value ? chainTokenBalance.value : accountTokenBalance.value) + " " + toDisplayString(token.value.ticker), 1)
            ]),
            createVNode(QSpace),
            createBaseVNode("div", {
              class: "cursor-pointer text-blue-6",
              onClick: onMaxAmountClick
            }, toDisplayString(_ctx.$t("MSG_MAX")), 1),
            _cache[3] || (_cache[3] = createBaseVNode("div", { class: "page-item-x-margin-left" }, null, -1))
          ]),
          createBaseVNode("div", _hoisted_8$1, [
            createVNode(QBtn, {
              flat: "",
              rounded: "",
              label: _ctx.$t("MSG_CONTINUE"),
              class: "btn full-width extra-margin-bottom",
              onClick: onContinueClick,
              "no-caps": "",
              disable: amount.value <= 0
            }, null, 8, ["label", "disable"])
          ])
        ]),
        createVNode(_sfc_main$7, {
          ref_key: "dbTokenBridge",
          ref: dbTokenBridge
        }, null, 512),
        createVNode(_sfc_main$9, {
          owner: fromOwner.value.owner,
          "microchain-id": fromMicrochain.value.microchain,
          "token-id": token.value.id,
          "token-balance": accountTokenBalance.value,
          "onUpdate:tokenBalance": _cache[1] || (_cache[1] = ($event) => accountTokenBalance.value = $event)
        }, null, 8, ["owner", "microchain-id", "token-id", "token-balance"]),
        createVNode(_sfc_main$a, {
          "microchain-id": fromMicrochain.value.microchain,
          "token-id": token.value.id,
          "token-balance": chainTokenBalance.value,
          "onUpdate:tokenBalance": _cache[2] || (_cache[2] = ($event) => chainTokenBalance.value = $event)
        }, null, 8, ["microchain-id", "token-id", "token-balance"])
      ], 64);
    };
  }
});
var SetTranserAmount = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-669857c4"]]);
const _hoisted_1$2 = { class: "text-grey-6 vertical-sections-margin" };
const _hoisted_2$1 = { class: "row flex items-center vertical-items-margin extra-margin-bottom" };
const _hoisted_3$1 = { class: "selector-margin-x-left" };
const _hoisted_4$1 = { class: "label-text-extra-large" };
const _hoisted_5$1 = { class: "page-y-padding" };
const _hoisted_6$1 = { class: "text-grey-6" };
const _hoisted_7 = { class: "like-link" };
const _hoisted_8 = { class: "row full-width" };
const _hoisted_9 = {
  key: 0,
  class: "header-items-margin-x-left text-left"
};
const _hoisted_10 = { class: "text-grey-6 page-header-network" };
const _hoisted_11 = { class: "row full-width" };
const _hoisted_12 = {
  key: 0,
  class: "header-items-margin-x-left text-left"
};
const _hoisted_13 = { class: "text-grey-6 page-header-network" };
const _hoisted_14 = { class: "text-grey-6 vertical-menus-margin" };
const _hoisted_15 = { class: "like-link" };
const _hoisted_16 = { class: "row full-width" };
const _hoisted_17 = {
  key: 0,
  class: "header-items-margin-x-left text-left"
};
const _hoisted_18 = { class: "text-grey-6 page-header-network" };
const _hoisted_19 = {
  key: 1,
  class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin transfer-tip text-grey-6 cursor-pointer word-break-all"
};
const _hoisted_20 = { class: "row full-width" };
const _hoisted_21 = {
  key: 0,
  class: "header-items-margin-x-left text-left"
};
const _hoisted_22 = { class: "text-grey-6 page-header-network" };
const _hoisted_23 = {
  key: 3,
  class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin transfer-tip text-grey-6 cursor-pointer word-break-all"
};
const _hoisted_24 = { class: "row info info-bg tip" };
const _hoisted_25 = {
  style: { width: "calc(100% - 26px)", fontSize: "13px" },
  class: "page-item-x-margin-left text-grey-8"
};
const _hoisted_26 = { class: "page-y-padding" };
const _sfc_main$2 = defineComponent({
  __name: "ConfirmTransfer",
  props: {
    token: {},
    fromOwner: {},
    fromMicrochain: {},
    toOwner: {},
    toMicrochain: {},
    toAddress: {},
    toMicrochainId: {},
    fromChainBalance: { type: Boolean },
    toChainBalance: { type: Boolean },
    amount: {},
    transferring: { type: Boolean }
  },
  emits: ["confirmed"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const token = toRef(props, "token");
    const fromOwner = toRef(props, "fromOwner");
    const fromMicrochain = toRef(props, "fromMicrochain");
    const toOwner = toRef(props, "toOwner");
    const toMicrochain = toRef(props, "toMicrochain");
    const toAddress = toRef(props, "toAddress");
    const toMicrochainId = toRef(props, "toMicrochainId");
    const fromChainBalance = toRef(props, "fromChainBalance");
    const toChainBalance = toRef(props, "toChainBalance");
    const amount = toRef(props, "amount");
    const transferring = toRef(props, "transferring");
    const tokenLogo = ref("");
    const emit = __emit;
    const onTransferClick = () => {
      emit("confirmed");
    };
    onMounted(async () => {
      tokenLogo.value = await Token.logo(token.value.id);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$2, toDisplayString(_ctx.$t("MSG_TRANSFER")), 1),
        createBaseVNode("div", _hoisted_2$1, [
          createVNode(QAvatar, null, {
            default: withCtx(() => [
              createVNode(QImg, {
                src: tokenLogo.value,
                width: "48px",
                height: "48px",
                fit: "contain"
              }, null, 8, ["src"])
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_3$1, [
            createBaseVNode("div", _hoisted_4$1, toDisplayString(amount.value) + " " + toDisplayString(token.value.ticker), 1),
            _cache[0] || (_cache[0] = createBaseVNode("div", {
              class: "text-grey-6",
              style: { marginTop: "-4px" }
            }, " \u2248 $ 0.00 ", -1))
          ])
        ]),
        createBaseVNode("div", _hoisted_5$1, [
          createBaseVNode("div", _hoisted_6$1, [
            createTextVNode(toDisplayString(_ctx.$t("MSG_FROM")) + " ", 1),
            createBaseVNode("span", _hoisted_7, toDisplayString(fromChainBalance.value ? "chain balance" : "account balance"), 1)
          ]),
          createVNode(QBtnDropdown, {
            flat: "",
            filled: "",
            class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin",
            "no-caps": "",
            dense: "",
            "dropdown-icon": "none",
            "menu-anchor": "bottom left",
            "menu-self": "top left"
          }, {
            label: withCtx(() => [
              createBaseVNode("div", _hoisted_8, [
                createVNode(QAvatar, null, {
                  default: withCtx(() => [
                    fromOwner.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).ownerAvatar(fromOwner.value),
                      width: "36px",
                      height: "36px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                fromOwner.value ? (openBlock(), createElementBlock("div", _hoisted_9, [
                  createBaseVNode("div", null, toDisplayString(fromOwner.value.name), 1),
                  createBaseVNode("div", _hoisted_10, " 0x" + toDisplayString(unref(shortid).shortId(fromOwner.value.owner, 6)), 1)
                ])) : createCommentVNode("", true)
              ])
            ]),
            _: 1
          }),
          createVNode(QBtnDropdown, {
            flat: "",
            filled: "",
            class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin",
            "no-caps": "",
            dense: "",
            "dropdown-icon": "none",
            "menu-anchor": "bottom left",
            "menu-self": "top left"
          }, {
            label: withCtx(() => [
              createBaseVNode("div", _hoisted_11, [
                createVNode(QAvatar, null, {
                  default: withCtx(() => [
                    fromMicrochain.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).microchainAvatar(fromMicrochain.value),
                      width: "36px",
                      height: "36px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                fromMicrochain.value ? (openBlock(), createElementBlock("div", _hoisted_12, [
                  createBaseVNode("div", null, toDisplayString(fromMicrochain.value.name || "Microchain"), 1),
                  createBaseVNode("div", _hoisted_13, " 0x" + toDisplayString(unref(shortid).shortId(fromMicrochain.value.microchain, 6)), 1)
                ])) : createCommentVNode("", true)
              ])
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_14, [
            createTextVNode(toDisplayString(_ctx.$t("MSG_TO")) + " ", 1),
            createBaseVNode("span", _hoisted_15, toDisplayString(toChainBalance.value ? "chain balance" : "account balance"), 1)
          ]),
          toOwner.value ? (openBlock(), createBlock(QBtnDropdown, {
            key: 0,
            flat: "",
            filled: "",
            class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin",
            "no-caps": "",
            dense: "",
            "dropdown-icon": "none",
            "menu-anchor": "bottom left",
            "menu-self": "top left"
          }, {
            label: withCtx(() => [
              createBaseVNode("div", _hoisted_16, [
                createVNode(QAvatar, null, {
                  default: withCtx(() => [
                    toOwner.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).ownerAvatar(toOwner.value),
                      width: "36px",
                      height: "36px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                toOwner.value ? (openBlock(), createElementBlock("div", _hoisted_17, [
                  createBaseVNode("div", null, toDisplayString(toOwner.value.name), 1),
                  createBaseVNode("div", _hoisted_18, " 0x" + toDisplayString(unref(shortid).shortId(toOwner.value.owner, 6)), 1)
                ])) : createCommentVNode("", true)
              ])
            ]),
            _: 1
          })) : (openBlock(), createElementBlock("div", _hoisted_19, toDisplayString(toAddress.value), 1)),
          toMicrochain.value ? (openBlock(), createBlock(QBtnDropdown, {
            key: 2,
            flat: "",
            filled: "",
            class: "btn-alt full-width btn-radius btn-grey-border vertical-items-margin",
            "no-caps": "",
            dense: "",
            "dropdown-icon": "none",
            "menu-anchor": "bottom left",
            "menu-self": "top left"
          }, {
            label: withCtx(() => [
              createBaseVNode("div", _hoisted_20, [
                createVNode(QAvatar, null, {
                  default: withCtx(() => [
                    toMicrochain.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).microchainAvatar(toMicrochain.value),
                      width: "36px",
                      height: "36px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                toMicrochain.value ? (openBlock(), createElementBlock("div", _hoisted_21, [
                  createBaseVNode("div", null, toDisplayString(toMicrochain.value.name || "Microchain"), 1),
                  createBaseVNode("div", _hoisted_22, " 0x" + toDisplayString(unref(shortid).shortId(toMicrochain.value.microchain, 6)), 1)
                ])) : createCommentVNode("", true)
              ])
            ]),
            _: 1
          })) : (openBlock(), createElementBlock("div", _hoisted_23, toDisplayString(toMicrochainId.value), 1))
        ]),
        createBaseVNode("div", _hoisted_24, [
          createVNode(QIcon, {
            name: "bi-info-circle-fill",
            size: "20px",
            color: "green-6"
          }),
          createBaseVNode("div", _hoisted_25, toDisplayString(_ctx.$t("MSG_SMALL_AMOUNT_NATIVE_TOKEN_FOR_GAS")), 1)
        ]),
        createBaseVNode("div", _hoisted_26, [
          createVNode(QBtn, {
            flat: "",
            rounded: "",
            label: _ctx.$t("MSG_CONTINUE"),
            class: "btn full-width extra-margin-bottom",
            onClick: onTransferClick,
            "no-caps": "",
            loading: transferring.value
          }, null, 8, ["label", "loading"])
        ])
      ]);
    };
  }
});
const _hoisted_1$1 = { class: "transfer-card" };
const _hoisted_2 = { class: "row" };
const _hoisted_3 = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_4 = {
  key: 0,
  class: "full-width"
};
const _hoisted_5 = {
  key: 1,
  class: "full-width"
};
const _hoisted_6 = {
  key: 2,
  class: "full-width"
};
const _sfc_main$1 = defineComponent({
  __name: "CreateTransfer",
  setup(__props) {
    const route = useRoute();
    const fromMicrochainId = ref(route.query.fromMicrochainId);
    const applicationId = ref(route.query.applicationId);
    const step = ref(1);
    const selectedToken = ref(void 0);
    const selectedFromOwner = ref(void 0);
    const selectedFromMicrochain = ref(void 0);
    const selectedToOwner = ref(void 0);
    const selectedToMicrochain = ref(void 0);
    const toAddress = ref("");
    const toMicrochain = ref("");
    const fromChainBalance = ref(false);
    const toChainBalance = ref(false);
    const amount = ref(0);
    const transferring = ref(false);
    const router = useRouter();
    const onSelectTransferAccountNext = () => {
      step.value++;
    };
    const onSetTransferAmountNext = () => {
      step.value++;
    };
    const onBackClick = () => {
      if (step.value > 1)
        return step.value--;
      void router.back();
    };
    const onTransferConfirmed = async () => {
      transferring.value = true;
      try {
        let operationId = void 0;
        if (!selectedToken.value.native) {
          const chainAccountOwner = {
            chainId: selectedToMicrochain.value?.microchain || toMicrochain.value,
            owner: Account.accountOwner(selectedToOwner.value?.owner || await ownerFromPublicKey(toAddress.value))
          };
          operationId = await MemeApplicationOperation.transfer(
            selectedFromMicrochain.value?.microchain,
            selectedToken.value.applicationId,
            chainAccountOwner,
            amount.value
          );
        } else {
          operationId = await Operation.transfer(
            fromChainBalance.value ? void 0 : selectedFromOwner.value?.address,
            selectedFromMicrochain.value?.microchain,
            toChainBalance.value ? void 0 : selectedToOwner.value?.address || toAddress.value,
            selectedToMicrochain.value?.microchain || toMicrochain.value,
            amount.value
          );
        }
        const payload = {
          microchain: selectedFromMicrochain.value?.microchain,
          operationId
        };
        BlockWorker.send(BlockEventType.NEW_OPERATION, payload);
        await Operation.waitOperation(operationId);
      } catch (e) {
        console.log("Failed transfer", e);
      }
      transferring.value = false;
      void router.back();
    };
    onMounted(async () => {
      if (fromMicrochainId.value) {
        selectedFromMicrochain.value = await Microchain.microchain(fromMicrochainId.value);
      }
      if (applicationId.value) {
        selectedToken.value = await Token.token(applicationId.value);
      } else {
        selectedToken.value = await Token.native();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, {
        flat: "",
        class: "full-width page-x-padding vertical-menus-margin row"
      }, {
        default: withCtx(() => [
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_1$1, [
            createBaseVNode("div", _hoisted_2, [
              createVNode(QIcon, {
                name: "bi-arrow-left-short",
                size: "24px",
                class: "cursor-pointer",
                onClick: onBackClick
              }),
              createVNode(QSpace),
              createBaseVNode("p", _hoisted_3, toDisplayString(_ctx.$t("MSG_TRANSFER_TOKENS")), 1),
              createVNode(QSpace),
              withDirectives(createBaseVNode("div", null, [
                createVNode(QIcon, {
                  name: "bi-x",
                  size: "24px",
                  class: "cursor-pointer",
                  onClick: onBackClick
                })
              ], 512), [
                [vShow, false]
              ])
            ]),
            step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_4, [
              createVNode(_sfc_main$4, {
                onNext: onSelectTransferAccountNext,
                "selected-from-owner": selectedFromOwner.value,
                "onUpdate:selectedFromOwner": _cache[0] || (_cache[0] = ($event) => selectedFromOwner.value = $event),
                "selected-from-microchain": selectedFromMicrochain.value,
                "onUpdate:selectedFromMicrochain": _cache[1] || (_cache[1] = ($event) => selectedFromMicrochain.value = $event),
                "selected-to-owner": selectedToOwner.value,
                "onUpdate:selectedToOwner": _cache[2] || (_cache[2] = ($event) => selectedToOwner.value = $event),
                "selected-to-microchain": selectedToMicrochain.value,
                "onUpdate:selectedToMicrochain": _cache[3] || (_cache[3] = ($event) => selectedToMicrochain.value = $event),
                "to-address": toAddress.value,
                "onUpdate:toAddress": _cache[4] || (_cache[4] = ($event) => toAddress.value = $event),
                "to-microchain": toMicrochain.value,
                "onUpdate:toMicrochain": _cache[5] || (_cache[5] = ($event) => toMicrochain.value = $event),
                "from-chain-balance": fromChainBalance.value,
                "onUpdate:fromChainBalance": _cache[6] || (_cache[6] = ($event) => fromChainBalance.value = $event),
                "to-chain-balance": toChainBalance.value,
                "onUpdate:toChainBalance": _cache[7] || (_cache[7] = ($event) => toChainBalance.value = $event),
                "selected-token": selectedToken.value,
                "onUpdate:selectedToken": _cache[8] || (_cache[8] = ($event) => selectedToken.value = $event)
              }, null, 8, ["selected-from-owner", "selected-from-microchain", "selected-to-owner", "selected-to-microchain", "to-address", "to-microchain", "from-chain-balance", "to-chain-balance", "selected-token"])
            ])) : createCommentVNode("", true),
            step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_5, [
              createVNode(SetTranserAmount, {
                "from-owner": selectedFromOwner.value,
                "from-microchain": selectedFromMicrochain.value,
                token: selectedToken.value,
                "from-chain-balance": fromChainBalance.value,
                "onUpdate:fromChainBalance": _cache[9] || (_cache[9] = ($event) => fromChainBalance.value = $event),
                onNext: onSetTransferAmountNext,
                modelValue: amount.value,
                "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => amount.value = $event)
              }, null, 8, ["from-owner", "from-microchain", "token", "from-chain-balance", "modelValue"])
            ])) : createCommentVNode("", true),
            step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_6, [
              createVNode(_sfc_main$2, {
                token: selectedToken.value,
                "from-owner": selectedFromOwner.value,
                "from-microchain": selectedFromMicrochain.value,
                "to-owner": selectedToOwner.value,
                "to-microchain": selectedToMicrochain.value,
                "to-address": toAddress.value,
                "to-microchain-id": toMicrochain.value,
                "from-chain-balance": fromChainBalance.value,
                "to-chain-balance": toChainBalance.value,
                amount: amount.value,
                transferring: transferring.value,
                onConfirmed: onTransferConfirmed
              }, null, 8, ["token", "from-owner", "from-microchain", "to-owner", "to-microchain", "to-address", "to-microchain-id", "from-chain-balance", "to-chain-balance", "amount", "transferring"])
            ])) : createCommentVNode("", true)
          ]),
          createVNode(QSpace)
        ]),
        _: 1
      });
    };
  }
});
const _hoisted_1 = { class: "full-width" };
const _sfc_main = defineComponent({
  __name: "TransferPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$1)
      ]);
    };
  }
});
export { _sfc_main as default };

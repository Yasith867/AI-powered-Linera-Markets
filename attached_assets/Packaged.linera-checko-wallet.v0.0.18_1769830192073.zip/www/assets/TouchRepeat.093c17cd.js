import { t as createComponent, a1 as useSpinnerProps, a2 as useSpinner, h, am as createDirective, al as client, ac as addEvt, ad as cleanEvt, E as noop, aU as leftClick, aa as isKeyCode, ap as stopAndPrevent, at as position } from "./index.facf9114.js";
import { c as clearSelection } from "./selection.ef9ae985.js";
const innerHTML = '<g transform="translate(-20,-20)"><path d="M79.9,52.6C80,51.8,80,50.9,80,50s0-1.8-0.1-2.6l-5.1-0.4c-0.3-2.4-0.9-4.6-1.8-6.7l4.2-2.9c-0.7-1.6-1.6-3.1-2.6-4.5 L70,35c-1.4-1.9-3.1-3.5-4.9-4.9l2.2-4.6c-1.4-1-2.9-1.9-4.5-2.6L59.8,27c-2.1-0.9-4.4-1.5-6.7-1.8l-0.4-5.1C51.8,20,50.9,20,50,20 s-1.8,0-2.6,0.1l-0.4,5.1c-2.4,0.3-4.6,0.9-6.7,1.8l-2.9-4.1c-1.6,0.7-3.1,1.6-4.5,2.6l2.1,4.6c-1.9,1.4-3.5,3.1-5,4.9l-4.5-2.1 c-1,1.4-1.9,2.9-2.6,4.5l4.1,2.9c-0.9,2.1-1.5,4.4-1.8,6.8l-5,0.4C20,48.2,20,49.1,20,50s0,1.8,0.1,2.6l5,0.4 c0.3,2.4,0.9,4.7,1.8,6.8l-4.1,2.9c0.7,1.6,1.6,3.1,2.6,4.5l4.5-2.1c1.4,1.9,3.1,3.5,5,4.9l-2.1,4.6c1.4,1,2.9,1.9,4.5,2.6l2.9-4.1 c2.1,0.9,4.4,1.5,6.7,1.8l0.4,5.1C48.2,80,49.1,80,50,80s1.8,0,2.6-0.1l0.4-5.1c2.3-0.3,4.6-0.9,6.7-1.8l2.9,4.2 c1.6-0.7,3.1-1.6,4.5-2.6L65,69.9c1.9-1.4,3.5-3,4.9-4.9l4.6,2.2c1-1.4,1.9-2.9,2.6-4.5L73,59.8c0.9-2.1,1.5-4.4,1.8-6.7L79.9,52.6 z M50,65c-8.3,0-15-6.7-15-15c0-8.3,6.7-15,15-15s15,6.7,15,15C65,58.3,58.3,65,50,65z" fill="currentColor"><animateTransform attributeName="transform" type="rotate" from="90 50 50" to="0 50 50" dur="1s" repeatCount="indefinite"></animateTransform></path></g><g transform="translate(20,20) rotate(15 50 50)"><path d="M79.9,52.6C80,51.8,80,50.9,80,50s0-1.8-0.1-2.6l-5.1-0.4c-0.3-2.4-0.9-4.6-1.8-6.7l4.2-2.9c-0.7-1.6-1.6-3.1-2.6-4.5 L70,35c-1.4-1.9-3.1-3.5-4.9-4.9l2.2-4.6c-1.4-1-2.9-1.9-4.5-2.6L59.8,27c-2.1-0.9-4.4-1.5-6.7-1.8l-0.4-5.1C51.8,20,50.9,20,50,20 s-1.8,0-2.6,0.1l-0.4,5.1c-2.4,0.3-4.6,0.9-6.7,1.8l-2.9-4.1c-1.6,0.7-3.1,1.6-4.5,2.6l2.1,4.6c-1.9,1.4-3.5,3.1-5,4.9l-4.5-2.1 c-1,1.4-1.9,2.9-2.6,4.5l4.1,2.9c-0.9,2.1-1.5,4.4-1.8,6.8l-5,0.4C20,48.2,20,49.1,20,50s0,1.8,0.1,2.6l5,0.4 c0.3,2.4,0.9,4.7,1.8,6.8l-4.1,2.9c0.7,1.6,1.6,3.1,2.6,4.5l4.5-2.1c1.4,1.9,3.1,3.5,5,4.9l-2.1,4.6c1.4,1,2.9,1.9,4.5,2.6l2.9-4.1 c2.1,0.9,4.4,1.5,6.7,1.8l0.4,5.1C48.2,80,49.1,80,50,80s1.8,0,2.6-0.1l0.4-5.1c2.3-0.3,4.6-0.9,6.7-1.8l2.9,4.2 c1.6-0.7,3.1-1.6,4.5-2.6L65,69.9c1.9-1.4,3.5-3,4.9-4.9l4.6,2.2c1-1.4,1.9-2.9,2.6-4.5L73,59.8c0.9-2.1,1.5-4.4,1.8-6.7L79.9,52.6 z M50,65c-8.3,0-15-6.7-15-15c0-8.3,6.7-15,15-15s15,6.7,15,15C65,58.3,58.3,65,50,65z" fill="currentColor"><animateTransform attributeName="transform" type="rotate" from="0 50 50" to="90 50 50" dur="1s" repeatCount="indefinite"></animateTransform></path></g>';
var QSpinnerGears = createComponent({
  name: "QSpinnerGears",
  props: useSpinnerProps,
  setup(props) {
    const { cSize, classes } = useSpinner(props);
    return () => h("svg", {
      class: classes.value,
      width: cSize.value,
      height: cSize.value,
      viewBox: "0 0 100 100",
      preserveAspectRatio: "xMidYMid",
      xmlns: "http://www.w3.org/2000/svg",
      innerHTML
    });
  }
});
const keyCodes = {
  esc: 27,
  tab: 9,
  enter: 13,
  space: 32,
  up: 38,
  left: 37,
  right: 39,
  down: 40,
  delete: [8, 46]
}, keyRegex = new RegExp(`^([\\d+]+|${Object.keys(keyCodes).join("|")})$`, "i");
function shouldEnd(evt, origin) {
  const { top, left } = position(evt);
  return Math.abs(left - origin.left) >= 7 || Math.abs(top - origin.top) >= 7;
}
var TouchRepeat = createDirective(
  {
    name: "touch-repeat",
    beforeMount(el, { modifiers, value, arg }) {
      const keyboard = Object.keys(modifiers).reduce((acc, key) => {
        if (keyRegex.test(key) === true) {
          const keyCode = isNaN(parseInt(key, 10)) ? keyCodes[key.toLowerCase()] : parseInt(key, 10);
          keyCode >= 0 && acc.push(keyCode);
        }
        return acc;
      }, []);
      if (modifiers.mouse !== true && client.has.touch !== true && keyboard.length === 0) {
        return;
      }
      const durations = typeof arg === "string" && arg.length !== 0 ? arg.split(":").map((val) => parseInt(val, 10)) : [0, 600, 300];
      const durationsLast = durations.length - 1;
      const ctx = {
        keyboard,
        handler: value,
        noop,
        mouseStart(evt) {
          if (ctx.event === void 0 && typeof ctx.handler === "function" && leftClick(evt) === true) {
            addEvt(ctx, "temp", [
              [document, "mousemove", "move", "passiveCapture"],
              [document, "click", "end", "notPassiveCapture"]
            ]);
            ctx.start(evt, true);
          }
        },
        keyboardStart(evt) {
          if (typeof ctx.handler === "function" && isKeyCode(evt, keyboard) === true) {
            if (durations[0] === 0 || ctx.event !== void 0) {
              stopAndPrevent(evt);
              el.focus();
              if (ctx.event !== void 0) {
                return;
              }
            }
            addEvt(ctx, "temp", [
              [document, "keyup", "end", "notPassiveCapture"],
              [document, "click", "end", "notPassiveCapture"]
            ]);
            ctx.start(evt, false, true);
          }
        },
        touchStart(evt) {
          if (evt.target !== void 0 && typeof ctx.handler === "function") {
            const target = evt.target;
            addEvt(ctx, "temp", [
              [target, "touchmove", "move", "passiveCapture"],
              [target, "touchcancel", "end", "notPassiveCapture"],
              [target, "touchend", "end", "notPassiveCapture"]
            ]);
            ctx.start(evt);
          }
        },
        start(evt, mouseEvent, keyboardEvent) {
          if (keyboardEvent !== true) {
            ctx.origin = position(evt);
          }
          function styleCleanup(withDelay) {
            ctx.styleCleanup = void 0;
            document.documentElement.style.cursor = "";
            const remove = () => {
              document.body.classList.remove("non-selectable");
            };
            if (withDelay === true) {
              clearSelection();
              setTimeout(remove, 10);
            } else {
              remove();
            }
          }
          if (client.is.mobile === true) {
            document.body.classList.add("non-selectable");
            clearSelection();
            ctx.styleCleanup = styleCleanup;
          }
          ctx.event = {
            touch: mouseEvent !== true && keyboardEvent !== true,
            mouse: mouseEvent === true,
            keyboard: keyboardEvent === true,
            startTime: Date.now(),
            repeatCount: 0
          };
          const fn = () => {
            ctx.timer = void 0;
            if (ctx.event === void 0) {
              return;
            }
            if (ctx.event.repeatCount === 0) {
              ctx.event.evt = evt;
              if (keyboardEvent === true) {
                ctx.event.keyCode = evt.keyCode;
              } else {
                ctx.event.position = position(evt);
              }
              if (client.is.mobile !== true) {
                document.documentElement.style.cursor = "pointer";
                document.body.classList.add("non-selectable");
                clearSelection();
                ctx.styleCleanup = styleCleanup;
              }
            }
            ctx.event.duration = Date.now() - ctx.event.startTime;
            ctx.event.repeatCount += 1;
            ctx.handler(ctx.event);
            const index = durationsLast < ctx.event.repeatCount ? durationsLast : ctx.event.repeatCount;
            ctx.timer = setTimeout(fn, durations[index]);
          };
          if (durations[0] === 0) {
            fn();
          } else {
            ctx.timer = setTimeout(fn, durations[0]);
          }
        },
        move(evt) {
          if (ctx.event !== void 0 && ctx.timer !== void 0 && shouldEnd(evt, ctx.origin) === true) {
            clearTimeout(ctx.timer);
            ctx.timer = void 0;
          }
        },
        end(evt) {
          if (ctx.event === void 0) {
            return;
          }
          ctx.styleCleanup !== void 0 && ctx.styleCleanup(true);
          evt !== void 0 && ctx.event.repeatCount > 0 && stopAndPrevent(evt);
          cleanEvt(ctx, "temp");
          if (ctx.timer !== void 0) {
            clearTimeout(ctx.timer);
            ctx.timer = void 0;
          }
          ctx.event = void 0;
        }
      };
      el.__qtouchrepeat = ctx;
      if (modifiers.mouse === true) {
        const capture = modifiers.mouseCapture === true || modifiers.mousecapture === true ? "Capture" : "";
        addEvt(ctx, "main", [
          [el, "mousedown", "mouseStart", `passive${capture}`]
        ]);
      }
      client.has.touch === true && addEvt(ctx, "main", [
        [el, "touchstart", "touchStart", `passive${modifiers.capture === true ? "Capture" : ""}`],
        [el, "touchend", "noop", "passiveCapture"]
      ]);
      if (keyboard.length !== 0) {
        const capture = modifiers.keyCapture === true || modifiers.keycapture === true ? "Capture" : "";
        addEvt(ctx, "main", [
          [el, "keydown", "keyboardStart", `notPassive${capture}`]
        ]);
      }
    },
    updated(el, { oldValue, value }) {
      const ctx = el.__qtouchrepeat;
      if (ctx !== void 0 && oldValue !== value) {
        typeof value !== "function" && ctx.end();
        ctx.handler = value;
      }
    },
    beforeUnmount(el) {
      const ctx = el.__qtouchrepeat;
      if (ctx !== void 0) {
        ctx.timer !== void 0 && clearTimeout(ctx.timer);
        cleanEvt(ctx, "main");
        cleanEvt(ctx, "temp");
        ctx.styleCleanup !== void 0 && ctx.styleCleanup();
        delete el.__qtouchrepeat;
      }
    }
  }
);
export { QSpinnerGears as Q, TouchRepeat as T };

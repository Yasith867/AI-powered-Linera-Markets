import { _ as _export_sfc, H as openBlock, I as createElementBlock, K as createBaseVNode, k as createVNode, aw as QBtn } from "./index.facf9114.js";
const _sfc_main = {};
const _hoisted_1 = { class: "fullscreen bg-blue text-white text-center q-pa-md flex flex-center" };
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1, [
    createBaseVNode("div", null, [
      _cache[0] || (_cache[0] = createBaseVNode("div", { style: { "font-size": "30vh" } }, " 404 ", -1)),
      _cache[1] || (_cache[1] = createBaseVNode("div", {
        class: "text-h2",
        style: { "opacity": "0.4" }
      }, " Oops. Nothing here... ", -1)),
      createVNode(QBtn, {
        class: "q-mt-xl",
        color: "white",
        "text-color": "blue",
        unelevated: "",
        to: "/",
        label: "Go Home",
        "no-caps": ""
      })
    ])
  ]);
}
var ErrorNotFound = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { ErrorNotFound as default };

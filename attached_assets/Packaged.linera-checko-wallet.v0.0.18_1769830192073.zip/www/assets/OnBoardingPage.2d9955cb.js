import { Q as QImg } from "./QImg.606c211a.js";
import { t as createComponent, a as computed, h, v as hSlot, r as ref, ae as vmHasRouter, w as watch, b2 as onBeforeMount, o as onMounted, m as onBeforeUnmount, az as History, j as getCurrentInstance, aN as hDir, b3 as isNumber, aw as QBtn, D as hMergeSlot, d as defineComponent, H as openBlock, I as createElementBlock, k as createVNode, J as withCtx, S as normalizeClass, u as unref, K as createBaseVNode, W as useRouter, L as toDisplayString, P as createBlock } from "./index.facf9114.js";
import { u as usePanelChildProps, a as usePanelProps, b as usePanelEmits, c as usePanel } from "./use-panel.a32f17c8.js";
import { u as useDarkProps, a as useDark } from "./use-dark.ea7d71c2.js";
import { Q as QSpace, l as localStore } from "./QSpace.27146b0a.js";
import { c as cheCkoLogo } from "./CheCko.b9dd764c.js";
import "./use-timeout.0aac84f1.js";
import "./selection.ef9ae985.js";
var onboardingExplorerBanner = "assets/OnboardingExplorerBanner.08db1726.png";
var onboardingLoginBanner = "assets/OnboardingLoginBanner.cbc75633.png";
var QCarouselSlide = createComponent({
  name: "QCarouselSlide",
  props: {
    ...usePanelChildProps,
    imgSrc: String
  },
  setup(props, { slots }) {
    const style = computed(() => props.imgSrc ? { backgroundImage: `url("${props.imgSrc}")` } : {});
    return () => h("div", {
      class: "q-carousel__slide",
      style: style.value
    }, hSlot(slots.default));
  }
});
let counter = 0;
const useFullscreenProps = {
  fullscreen: Boolean,
  noRouteFullscreenExit: Boolean
};
const useFullscreenEmits = ["update:fullscreen", "fullscreen"];
function useFullscreen() {
  const vm = getCurrentInstance();
  const { props, emit, proxy } = vm;
  let historyEntry, fullscreenFillerNode, container;
  const inFullscreen = ref(false);
  vmHasRouter(vm) === true && watch(() => proxy.$route.fullPath, () => {
    props.noRouteFullscreenExit !== true && exitFullscreen();
  });
  watch(() => props.fullscreen, (v) => {
    if (inFullscreen.value !== v) {
      toggleFullscreen();
    }
  });
  watch(inFullscreen, (v) => {
    emit("update:fullscreen", v);
    emit("fullscreen", v);
  });
  function toggleFullscreen() {
    if (inFullscreen.value === true) {
      exitFullscreen();
    } else {
      setFullscreen();
    }
  }
  function setFullscreen() {
    if (inFullscreen.value === true) {
      return;
    }
    inFullscreen.value = true;
    container = proxy.$el.parentNode;
    container.replaceChild(fullscreenFillerNode, proxy.$el);
    document.body.appendChild(proxy.$el);
    counter++;
    if (counter === 1) {
      document.body.classList.add("q-body--fullscreen-mixin");
    }
    historyEntry = {
      handler: exitFullscreen
    };
    History.add(historyEntry);
  }
  function exitFullscreen() {
    if (inFullscreen.value !== true) {
      return;
    }
    if (historyEntry !== void 0) {
      History.remove(historyEntry);
      historyEntry = void 0;
    }
    container.replaceChild(proxy.$el, fullscreenFillerNode);
    inFullscreen.value = false;
    counter = Math.max(0, counter - 1);
    if (counter === 0) {
      document.body.classList.remove("q-body--fullscreen-mixin");
      if (proxy.$el.scrollIntoView !== void 0) {
        setTimeout(() => {
          proxy.$el.scrollIntoView();
        });
      }
    }
  }
  onBeforeMount(() => {
    fullscreenFillerNode = document.createElement("span");
  });
  onMounted(() => {
    props.fullscreen === true && setFullscreen();
  });
  onBeforeUnmount(exitFullscreen);
  Object.assign(proxy, {
    toggleFullscreen,
    setFullscreen,
    exitFullscreen
  });
  return {
    inFullscreen,
    toggleFullscreen
  };
}
const navigationPositionOptions = ["top", "right", "bottom", "left"];
const controlTypeOptions = ["regular", "flat", "outline", "push", "unelevated"];
var QCarousel = createComponent({
  name: "QCarousel",
  props: {
    ...useDarkProps,
    ...usePanelProps,
    ...useFullscreenProps,
    transitionPrev: {
      type: String,
      default: "fade"
    },
    transitionNext: {
      type: String,
      default: "fade"
    },
    height: String,
    padding: Boolean,
    controlColor: String,
    controlTextColor: String,
    controlType: {
      type: String,
      validator: (v) => controlTypeOptions.includes(v),
      default: "flat"
    },
    autoplay: [Number, Boolean],
    arrows: Boolean,
    prevIcon: String,
    nextIcon: String,
    navigation: Boolean,
    navigationPosition: {
      type: String,
      validator: (v) => navigationPositionOptions.includes(v)
    },
    navigationIcon: String,
    navigationActiveIcon: String,
    thumbnails: Boolean
  },
  emits: [
    ...useFullscreenEmits,
    ...usePanelEmits
  ],
  setup(props, { slots }) {
    const { proxy: { $q } } = getCurrentInstance();
    const isDark = useDark(props, $q);
    let timer = null, panelsLen;
    const {
      updatePanelsList,
      getPanelContent,
      panelDirectives,
      goToPanel,
      previousPanel,
      nextPanel,
      getEnabledPanels,
      panelIndex
    } = usePanel();
    const { inFullscreen } = useFullscreen();
    const style = computed(() => inFullscreen.value !== true && props.height !== void 0 ? { height: props.height } : {});
    const direction = computed(() => props.vertical === true ? "vertical" : "horizontal");
    const navigationPosition = computed(
      () => props.navigationPosition || (props.vertical === true ? "right" : "bottom")
    );
    const classes = computed(
      () => `q-carousel q-panel-parent q-carousel--with${props.padding === true ? "" : "out"}-padding` + (inFullscreen.value === true ? " fullscreen" : "") + (isDark.value === true ? " q-carousel--dark q-dark" : "") + (props.arrows === true ? ` q-carousel--arrows-${direction.value}` : "") + (props.navigation === true ? ` q-carousel--navigation-${navigationPosition.value}` : "")
    );
    const arrowIcons = computed(() => {
      const ico = [
        props.prevIcon || $q.iconSet.carousel[props.vertical === true ? "up" : "left"],
        props.nextIcon || $q.iconSet.carousel[props.vertical === true ? "down" : "right"]
      ];
      return props.vertical === false && $q.lang.rtl === true ? ico.reverse() : ico;
    });
    const navIcon = computed(() => props.navigationIcon || $q.iconSet.carousel.navigationIcon);
    const navActiveIcon = computed(() => props.navigationActiveIcon || navIcon.value);
    const controlProps = computed(() => ({
      color: props.controlColor,
      textColor: props.controlTextColor,
      round: true,
      [props.controlType]: true,
      dense: true
    }));
    watch(() => props.modelValue, () => {
      if (props.autoplay) {
        startTimer();
      }
    });
    watch(() => props.autoplay, (val) => {
      if (val) {
        startTimer();
      } else if (timer !== null) {
        clearTimeout(timer);
        timer = null;
      }
    });
    function startTimer() {
      const duration = isNumber(props.autoplay) === true ? Math.abs(props.autoplay) : 5e3;
      timer !== null && clearTimeout(timer);
      timer = setTimeout(() => {
        timer = null;
        if (duration >= 0) {
          nextPanel();
        } else {
          previousPanel();
        }
      }, duration);
    }
    onMounted(() => {
      props.autoplay && startTimer();
    });
    onBeforeUnmount(() => {
      timer !== null && clearTimeout(timer);
    });
    function getNavigationContainer(type, mapping) {
      return h("div", {
        class: `q-carousel__control q-carousel__navigation no-wrap absolute flex q-carousel__navigation--${type} q-carousel__navigation--${navigationPosition.value}` + (props.controlColor !== void 0 ? ` text-${props.controlColor}` : "")
      }, [
        h("div", {
          class: "q-carousel__navigation-inner flex flex-center no-wrap"
        }, getEnabledPanels().map(mapping))
      ]);
    }
    function getContent() {
      const node = [];
      if (props.navigation === true) {
        const fn = slots["navigation-icon"] !== void 0 ? slots["navigation-icon"] : (opts) => h(QBtn, {
          key: "nav" + opts.name,
          class: `q-carousel__navigation-icon q-carousel__navigation-icon--${opts.active === true ? "" : "in"}active`,
          ...opts.btnProps,
          onClick: opts.onClick
        });
        const maxIndex = panelsLen - 1;
        node.push(
          getNavigationContainer("buttons", (panel, index) => {
            const name = panel.props.name;
            const active = panelIndex.value === index;
            return fn({
              index,
              maxIndex,
              name,
              active,
              btnProps: {
                icon: active === true ? navActiveIcon.value : navIcon.value,
                size: "sm",
                ...controlProps.value
              },
              onClick: () => {
                goToPanel(name);
              }
            });
          })
        );
      } else if (props.thumbnails === true) {
        const color = props.controlColor !== void 0 ? ` text-${props.controlColor}` : "";
        node.push(getNavigationContainer("thumbnails", (panel) => {
          const slide = panel.props;
          return h("img", {
            key: "tmb#" + slide.name,
            class: `q-carousel__thumbnail q-carousel__thumbnail--${slide.name === props.modelValue ? "" : "in"}active` + color,
            src: slide.imgSrc || slide["img-src"],
            onClick: () => {
              goToPanel(slide.name);
            }
          });
        }));
      }
      if (props.arrows === true && panelIndex.value >= 0) {
        if (props.infinite === true || panelIndex.value > 0) {
          node.push(
            h("div", {
              key: "prev",
              class: `q-carousel__control q-carousel__arrow q-carousel__prev-arrow q-carousel__prev-arrow--${direction.value} absolute flex flex-center`
            }, [
              h(QBtn, {
                icon: arrowIcons.value[0],
                ...controlProps.value,
                onClick: previousPanel
              })
            ])
          );
        }
        if (props.infinite === true || panelIndex.value < panelsLen - 1) {
          node.push(
            h("div", {
              key: "next",
              class: `q-carousel__control q-carousel__arrow q-carousel__next-arrow q-carousel__next-arrow--${direction.value} absolute flex flex-center`
            }, [
              h(QBtn, {
                icon: arrowIcons.value[1],
                ...controlProps.value,
                onClick: nextPanel
              })
            ])
          );
        }
      }
      return hMergeSlot(slots.control, node);
    }
    return () => {
      panelsLen = updatePanelsList(slots);
      return h("div", {
        class: classes.value,
        style: style.value
      }, [
        hDir(
          "div",
          { class: "q-carousel__slides-container" },
          getPanelContent(),
          "sl-cont",
          props.swipeable,
          () => panelDirectives.value
        )
      ].concat(getContent()));
    };
  }
});
const _hoisted_1 = { class: "onboarding-page-title" };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = ["innerHTML"];
const _hoisted_4 = { style: { margin: "80px 0" } };
const _hoisted_5 = ["innerHTML"];
const _hoisted_6 = ["innerHTML"];
const _hoisted_7 = { style: { margin: "16px 0" } };
const _hoisted_8 = { class: "onboarding-page-title" };
const _hoisted_9 = { style: { margin: "16px 0" } };
const _hoisted_10 = ["innerHTML"];
const _hoisted_11 = { class: "row full-width page-x-padding" };
const _hoisted_12 = { class: "onboarding-btns" };
const _sfc_main$1 = defineComponent({
  __name: "OnBoarding",
  setup(__props) {
    const router = useRouter();
    const slide = ref("first");
    const onCreateWalletClick = () => {
      void router.push({
        path: localStore.setting.formalizePath("/improvement"),
        query: {
          target: "/initializewallet"
        }
      });
    };
    const onImportWalletClick = () => {
      void router.push({
        path: localStore.setting.formalizePath("/improvement"),
        query: {
          target: "/importwallet"
        }
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["fill-parent text-center onboarding-container shadow-1", unref(localStore).setting.extensionMode ? "" : "onboarding-padding"])
      }, [
        createVNode(QCarousel, {
          modelValue: slide.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => slide.value = $event),
          "transition-prev": "scale",
          "transition-next": "scale",
          swipeable: "",
          animated: "",
          "control-color": "brown-10",
          navigation: "",
          padding: "",
          arrows: "",
          class: normalizeClass(["text-black rounded-borders", unref(localStore).setting.extensionMode ? "carousel-dense-slides" : ""])
        }, {
          default: withCtx(() => [
            createVNode(QCarouselSlide, {
              name: "first",
              class: "column no-wrap flex-center"
            }, {
              default: withCtx(() => [
                createBaseVNode("h5", _hoisted_1, toDisplayString(_ctx.$t("MSG_LETS_GET_STARTED")), 1),
                unref(localStore).setting.extensionMode ? (openBlock(), createElementBlock("p", _hoisted_2, toDisplayString(_ctx.$t("MSG_CHECKO_SECURE_WALLET_MAKING_REAL_TIME_DAPPS_ON_LINERA_ACCESSIBLE_TO_ALL")), 1)) : (openBlock(), createElementBlock("p", {
                  key: 1,
                  innerHTML: _ctx.$t("MSG_CHECKO_SECURE_WALLET_MAKING_REAL_TIME_DAPPS_ON_LINERA_ACCESSIBLE_TO_ALL_LINE_FEED")
                }, null, 8, _hoisted_3)),
                createBaseVNode("div", _hoisted_4, [
                  createVNode(QImg, {
                    src: unref(cheCkoLogo),
                    width: "240px"
                  }, null, 8, ["src"])
                ])
              ]),
              _: 1
            }),
            createVNode(QCarouselSlide, {
              name: "second",
              class: "column no-wrap flex-center"
            }, {
              default: withCtx(() => [
                createBaseVNode("h5", {
                  class: "onboarding-page-title",
                  innerHTML: _ctx.$t("MSG_EXPLORER_REAL_TIME_AND_REACTIVE_DAPPS")
                }, null, 8, _hoisted_5),
                createBaseVNode("p", {
                  innerHTML: _ctx.$t("MSG_INTERACT_WITH_WEB3_DAPPS_LIKE_WEB2")
                }, null, 8, _hoisted_6),
                createBaseVNode("div", _hoisted_7, [
                  createVNode(QImg, {
                    src: unref(onboardingExplorerBanner),
                    width: "320px"
                  }, null, 8, ["src"])
                ])
              ]),
              _: 1
            }),
            createVNode(QCarouselSlide, {
              name: "third",
              class: "column no-wrap flex-center"
            }, {
              default: withCtx(() => [
                createBaseVNode("h5", _hoisted_8, toDisplayString(_ctx.$t("MSG_LOGIN_WITH_YOUR_WALLET")), 1),
                createBaseVNode("p", null, toDisplayString(_ctx.$t("MSG_USE_YOUR_WALLET_TO_LOGIN_TO_DAPPS_LIKE_METAMASK")), 1),
                createBaseVNode("div", _hoisted_9, [
                  createVNode(QImg, {
                    src: unref(onboardingLoginBanner),
                    width: "320px"
                  }, null, 8, ["src"])
                ])
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue", "class"]),
        createBaseVNode("p", {
          innerHTML: _ctx.$t("MSG_BY_CONTINUE_YOU_AGREE_TO_CHECKO_TERM_OF_USE")
        }, null, 8, _hoisted_10),
        createBaseVNode("div", _hoisted_11, [
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_12, [
            createVNode(QBtn, {
              flat: "",
              label: _ctx.$t("MSG_CREATE_A_NEW_WALLET"),
              class: "btn vertical-items-margin full-width",
              onClick: onCreateWalletClick,
              "no-caps": ""
            }, null, 8, ["label"]),
            createVNode(QBtn, {
              flat: "",
              label: _ctx.$t("MSG_IMPORTING_AN_EXISTING_WALLET"),
              class: "btn btn-alt vertical-items-margin full-width",
              onClick: onImportWalletClick,
              "no-caps": ""
            }, null, 8, ["label"])
          ]),
          createVNode(QSpace)
        ])
      ], 2);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "OnBoardingPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1);
    };
  }
});
export { _sfc_main as default };

import { d as defineComponent, ar as mergeModels, aq as useModel, r as ref, H as openBlock, I as createElementBlock, k as createVNode, J as withCtx, F as Fragment, W as useRouter, K as createBaseVNode, L as toDisplayString, u as unref, aw as QBtn, S as normalizeClass, X as useRoute, P as createBlock } from "./index.facf9114.js";
import { Q as QSpace, l as localStore } from "./QSpace.27146b0a.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { _ as _sfc_main$4 } from "./InputPassword.6c64acdf.js";
import { _ as _sfc_main$3 } from "./PasswordBridge.41db8c1b.js";
import { c as cheCkoLogo } from "./CheCko.b9dd764c.js";
import { a as verify } from "./verify.2de89a24.js";
import { u as useI18n } from "./vue-i18n.runtime.8c1649dd.js";
import "./db.46ddc67f.js";
import "./application.ca271889.js";
import { L as LoginTimestamp } from "./login_timestamp.410697ca.js";
import "./index.d2b21240.js";
import "./use-timeout.0aac84f1.js";
import "./use-dark.ea7d71c2.js";
import "./QInput.c11607b6.js";
import "./private.use-form.4c048d1b.js";
import "./index.f58c37d0.js";
import "./_commonjsHelpers.294d03c4.js";
const _hoisted_1 = { class: "onboarding-page-title" };
const _hoisted_2 = { style: { marginTop: "-12px" } };
const _hoisted_3 = { class: "row" };
const _hoisted_4 = { class: "full-width" };
const _hoisted_5 = { style: { margin: "80px 0 0 0" } };
const _sfc_main$2 = defineComponent({
  __name: "LoginPassword",
  props: {
    "password": { default: "" },
    "passwordModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["unlocked"], ["update:password"]),
  setup(__props, { emit: __emit }) {
    const { t } = useI18n({ useScope: "global" });
    const password = useModel(__props, "password");
    const decryptedPassword = ref("");
    const emit = __emit;
    const passwordError = ref(false);
    const unlock = () => {
      if (password.value === decryptedPassword.value)
        return emit("unlocked");
      localStore.notification.pushNotification({
        Title: t("MSG_RESTORE_WALLET"),
        Message: t("MSG_FAILED_RESTORE_WALLET"),
        Popup: true,
        Type: localStore.notify.NotifyType.Error
      });
    };
    const onUnlockClick = () => {
      if (passwordError.value)
        return;
      unlock();
    };
    const router = useRouter();
    const onForgetPasswordClick = () => {
      void router.push({ path: localStore.setting.formalizePath("/resetwallet") });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, {
          flat: "",
          class: "full-width page-x-padding"
        }, {
          default: withCtx(() => [
            createBaseVNode("h5", _hoisted_1, toDisplayString(_ctx.$t("MSG_WELCOME_BACK")), 1),
            createBaseVNode("p", _hoisted_2, toDisplayString(_ctx.$t("MSG_THE_REAL_TIME_AND_REACTIVE_DWEB_AWAITS")), 1),
            createBaseVNode("div", null, [
              createVNode(QImg, {
                src: unref(cheCkoLogo),
                width: "240px",
                style: { margin: "80px 0 0 0" }
              }, null, 8, ["src"])
            ]),
            createBaseVNode("div", _hoisted_3, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_4, [
                createBaseVNode("div", _hoisted_5, [
                  createVNode(_sfc_main$4, {
                    password: password.value,
                    "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
                    error: passwordError.value,
                    "onUpdate:error": _cache[1] || (_cache[1] = ($event) => passwordError.value = $event)
                  }, null, 8, ["password", "error"])
                ]),
                createVNode(QBtn, {
                  flat: "",
                  class: "btn full-width vertical-sections-margin",
                  label: _ctx.$t("MSG_UNLOCK"),
                  onClick: onUnlockClick,
                  disable: !unref(verify).validatePassword(password.value) || passwordError.value,
                  "no-caps": ""
                }, null, 8, ["label", "disable"]),
                createVNode(QBtn, {
                  flat: "",
                  dense: "",
                  rounded: "",
                  class: "text-blue-6 full-width",
                  label: _ctx.$t("MSG_FORGET_PASSWORD"),
                  onClick: onForgetPasswordClick,
                  "no-caps": ""
                }, null, 8, ["label"])
              ]),
              createVNode(QSpace)
            ])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$3, {
          password: decryptedPassword.value,
          "onUpdate:password": _cache[2] || (_cache[2] = ($event) => decryptedPassword.value = $event)
        }, null, 8, ["password"])
      ], 64);
    };
  }
});
const _sfc_main$1 = defineComponent({
  __name: "RecoveryWallet",
  setup(__props) {
    const password = ref("");
    const router = useRouter();
    const route = useRoute();
    const targetPath = ref(route.query.target);
    const unlocked = async () => {
      await LoginTimestamp.save();
      void router.push({ path: targetPath.value || localStore.setting.formalizePath("/home") });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["text-center onboarding-container shadow-1", unref(localStore).setting.extensionMode ? "" : "onboarding-padding"])
      }, [
        createVNode(_sfc_main$2, {
          password: password.value,
          "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
          onUnlocked: unlocked
        }, null, 8, ["password"])
      ], 2);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "RecoveryPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1);
    };
  }
});
export { _sfc_main as default };

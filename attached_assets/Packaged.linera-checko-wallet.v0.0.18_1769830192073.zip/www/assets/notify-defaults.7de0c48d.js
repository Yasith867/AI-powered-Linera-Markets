import { b as boot, N as Notify } from "./index.facf9114.js";
var notifyDefaults = boot(() => {
  Notify.setDefaults({
    color: "white",
    timeout: 3e3,
    position: "bottom-right",
    progress: true
  });
});
export { notifyDefaults as default };

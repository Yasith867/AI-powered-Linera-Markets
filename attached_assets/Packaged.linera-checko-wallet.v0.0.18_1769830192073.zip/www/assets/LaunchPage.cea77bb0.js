import { _ as _export_sfc, H as openBlock, I as createElementBlock } from "./index.facf9114.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div");
}
var LaunchPage = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export { LaunchPage as default };

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { u as useDarkProps, a as useDark } from "./use-dark.ea7d71c2.js";
import { t as createComponent, an as useRouterLinkProps, ao as useRouterLink, r as ref, a as computed, h, aa as isKeyCode, ap as stopAndPrevent, y as hUniqueSlot, j as getCurrentInstance, v as hSlot, al as client, d as defineComponent, aq as useModel, w as watch, ar as mergeModels, as as toRef, H as openBlock, P as createBlock } from "./index.facf9114.js";
import { a as dbWallet, d as dbBase, l as liveQuery } from "./db.46ddc67f.js";
import { O as OperationState, l as lineraToken, T as TokenType, A as APPLICATION_URLS } from "./application.ca271889.js";
import { u as useObservable } from "./index.f58c37d0.js";
import { M as Microchain } from "./microchain.44c150a3.js";
import "./QSpace.27146b0a.js";
import "./index.d2b21240.js";
var QItem = createComponent({
  name: "QItem",
  props: {
    ...useDarkProps,
    ...useRouterLinkProps,
    tag: {
      type: String,
      default: "div"
    },
    active: {
      type: Boolean,
      default: null
    },
    clickable: Boolean,
    dense: Boolean,
    insetLevel: Number,
    tabindex: [String, Number],
    focused: Boolean,
    manualFocus: Boolean
  },
  emits: ["click", "keyup"],
  setup(props, { slots, emit }) {
    const { proxy: { $q } } = getCurrentInstance();
    const isDark = useDark(props, $q);
    const { hasLink, linkAttrs, linkClass, linkTag, navigateOnClick } = useRouterLink();
    const rootRef = ref(null);
    const blurTargetRef = ref(null);
    const isActionable = computed(
      () => props.clickable === true || hasLink.value === true || props.tag === "label"
    );
    const isClickable = computed(
      () => props.disable !== true && isActionable.value === true
    );
    const classes = computed(
      () => "q-item q-item-type row no-wrap" + (props.dense === true ? " q-item--dense" : "") + (isDark.value === true ? " q-item--dark" : "") + (hasLink.value === true && props.active === null ? linkClass.value : props.active === true ? ` q-item--active${props.activeClass !== void 0 ? ` ${props.activeClass}` : ""}` : "") + (props.disable === true ? " disabled" : "") + (isClickable.value === true ? " q-item--clickable q-link cursor-pointer " + (props.manualFocus === true ? "q-manual-focusable" : "q-focusable q-hoverable") + (props.focused === true ? " q-manual-focusable--focused" : "") : "")
    );
    const style = computed(() => {
      if (props.insetLevel === void 0) {
        return null;
      }
      const dir = $q.lang.rtl === true ? "Right" : "Left";
      return {
        ["padding" + dir]: 16 + props.insetLevel * 56 + "px"
      };
    });
    function onClick(e) {
      if (isClickable.value === true) {
        if (blurTargetRef.value !== null) {
          if (e.qKeyEvent !== true && document.activeElement === rootRef.value) {
            blurTargetRef.value.focus();
          } else if (document.activeElement === blurTargetRef.value) {
            rootRef.value.focus();
          }
        }
        navigateOnClick(e);
      }
    }
    function onKeyup(e) {
      if (isClickable.value === true && isKeyCode(e, [13, 32]) === true) {
        stopAndPrevent(e);
        e.qKeyEvent = true;
        const evt = new MouseEvent("click", e);
        evt.qKeyEvent = true;
        rootRef.value.dispatchEvent(evt);
      }
      emit("keyup", e);
    }
    function getContent() {
      const child = hUniqueSlot(slots.default, []);
      isClickable.value === true && child.unshift(
        h("div", { class: "q-focus-helper", tabindex: -1, ref: blurTargetRef })
      );
      return child;
    }
    return () => {
      const data = {
        ref: rootRef,
        class: classes.value,
        style: style.value,
        role: "listitem",
        onClick,
        onKeyup
      };
      if (isClickable.value === true) {
        data.tabindex = props.tabindex || "0";
        Object.assign(data, linkAttrs.value);
      } else if (isActionable.value === true) {
        data["aria-disabled"] = "true";
      }
      return h(
        linkTag.value,
        data,
        getContent()
      );
    };
  }
});
const roleAttrExceptions = ["ul", "ol"];
var QList = createComponent({
  name: "QList",
  props: {
    ...useDarkProps,
    bordered: Boolean,
    dense: Boolean,
    separator: Boolean,
    padding: Boolean,
    tag: {
      type: String,
      default: "div"
    }
  },
  setup(props, { slots }) {
    const vm = getCurrentInstance();
    const isDark = useDark(props, vm.proxy.$q);
    const role = computed(
      () => roleAttrExceptions.includes(props.tag) ? null : "list"
    );
    const classes = computed(
      () => "q-list" + (props.bordered === true ? " q-list--bordered" : "") + (props.dense === true ? " q-list--dense" : "") + (props.separator === true ? " q-list--separator" : "") + (isDark.value === true ? " q-list--dark" : "") + (props.padding === true ? " q-list--padding" : "")
    );
    return () => h(props.tag, { class: classes.value, role: role.value }, hSlot(slots.default));
  }
});
const handlers = [];
function trigger(e) {
  handlers[handlers.length - 1](e);
}
function addFocusout(fn) {
  if (client.is.desktop === true) {
    handlers.push(fn);
    if (handlers.length === 1) {
      document.body.addEventListener("focusin", trigger);
    }
  }
}
function removeFocusout(fn) {
  const index = handlers.indexOf(fn);
  if (index !== -1) {
    handlers.splice(index, 1);
    if (handlers.length === 0) {
      document.body.removeEventListener("focusin", trigger);
    }
  }
}
class ChainOperation {
}
__publicField(ChainOperation, "create", async (chainOperation) => {
  chainOperation.state = OperationState.CREATED;
  chainOperation.createdAt = Date.now();
  await dbWallet.chainOperations.add(chainOperation);
});
__publicField(ChainOperation, "get", async (operationId) => {
  return await dbWallet.chainOperations.where("operationId").equals(operationId).first();
});
__publicField(ChainOperation, "count", async (microchain, states) => {
  return await dbWallet.chainOperations.filter(
    (op) => (!microchain || op.microchain === microchain) && (states === void 0 || states.length === 0 || states.includes(op.state))
  ).count();
});
__publicField(ChainOperation, "chainOperations", async (offset, limit, microchain, states, certificateHash, error) => {
  return await dbWallet.chainOperations.filter(
    (op) => (!microchain || op.microchain === microchain) && (!certificateHash || op.certificateHash === certificateHash) && (error === void 0 || error && !!op.errorAt || !error && !op.errorAt) && (states === void 0 || states.length === 0 || states.includes(op.state))
  ).offset(offset).limit(limit || 9999).toArray();
});
__publicField(ChainOperation, "update", async (chainOperation) => {
  await dbWallet.chainOperations.update(chainOperation.id, chainOperation);
});
__publicField(ChainOperation, "delete", async (id) => {
  await dbWallet.chainOperations.delete(id);
});
__publicField(ChainOperation, "exists", async (microchain, operationType, applicationId, states, createdBefore, createdAfter) => {
  return await dbWallet.chainOperations.where("microchain").equals(microchain).and((op) => op.operationType === operationType).and((op) => !applicationId || op.applicationId === applicationId).and((op) => !states?.length || states.includes(op.state)).and(
    (op) => createdBefore === void 0 || (op.createdAt || 0) <= createdBefore
  ).and(
    (op) => createdAfter === void 0 || (op.createdAt || 0) > createdAfter
  ).first() !== void 0;
});
__publicField(ChainOperation, "operationBlobs", async (operationId) => {
  return (await dbWallet.operationBlobs.where("operationId").equals(operationId).toArray()).map((blob) => blob.blob);
});
__publicField(ChainOperation, "createOperationBlobs", async (operationId, blobs) => {
  if (!blobs.length)
    return;
  await dbWallet.operationBlobs.bulkAdd(
    blobs.map((blob) => {
      return {
        operationId,
        blob: new Uint8Array(
          JSON.parse(blob)
        )
      };
    })
  );
});
const _Token = class {
};
let Token = _Token;
__publicField(Token, "initialize", async (nativeLogo) => {
  if (await _Token.native())
    return;
  lineraToken.logo = nativeLogo;
  await dbBase.tokens.add(lineraToken);
});
__publicField(Token, "create", async (token) => {
  if ((await dbBase.tokens.toArray()).findIndex(
    (el) => el.applicationId === token.applicationId
  ) >= 0)
    return;
  await dbBase.tokens.add(token);
});
__publicField(Token, "update", async (token) => {
  await dbBase.tokens.update(token.id, token);
});
__publicField(Token, "delete", async (id) => {
  await dbBase.tokens.delete(id);
});
__publicField(Token, "native", async () => {
  return (await dbBase.tokens.toArray()).find((el) => el.native);
});
__publicField(Token, "fungibles", async () => {
  return (await dbBase.tokens.toArray()).filter(
    (el) => el.tokenType === TokenType.Fungible
  );
});
__publicField(Token, "token", async (applicationId) => {
  return (await dbBase.tokens.toArray()).find(
    (el) => el.applicationId === applicationId
  );
});
__publicField(Token, "tokens", async (offset, limit, applicationIds, creatorChainId) => {
  return await dbBase.tokens.filter(
    (op) => (creatorChainId === void 0 || op.creatorChainId === creatorChainId) && (applicationIds === void 0 || applicationIds.length === 0 || applicationIds.includes(op.applicationId))
  ).offset(offset).limit(limit || 9999).toArray();
});
__publicField(Token, "count", async () => {
  return await dbBase.tokens.count();
});
__publicField(Token, "tokenWithId", async (id) => {
  return (await dbBase.tokens.toArray()).find((el) => el.id === id);
});
__publicField(Token, "exists", async (applicationId) => {
  return await dbBase.tokens.where("applicationId").equals(applicationId).first() !== void 0;
});
__publicField(Token, "logo", async (tokenId) => {
  const token = await dbBase.tokens.get(tokenId);
  if (!token)
    return void 0;
  if (token.native)
    return token.logo;
  const blobGatewayUrl = APPLICATION_URLS.BLOB_GATEWAY;
  return blobGatewayUrl + "/images/" + token.logo;
});
const _sfc_main$2 = defineComponent({
  __name: "NetworkBridge",
  props: {
    "networks": {},
    "networksModifiers": {},
    "selectedNetwork": {},
    "selectedNetworkModifiers": {}
  },
  emits: ["update:networks", "update:selectedNetwork"],
  setup(__props) {
    const networks = useModel(__props, "networks");
    const selectedNetwork = useModel(__props, "selectedNetwork");
    const _networks = useObservable(
      liveQuery(async () => {
        return await dbBase.networks.toArray();
      })
    );
    watch(_networks, () => {
      selectedNetwork.value = _networks.value?.find((el) => el.selected);
      networks.value = _networks.value;
    });
    return () => {
    };
  }
});
const _sfc_main$1 = defineComponent({
  __name: "MicrochainBridge",
  props: /* @__PURE__ */ mergeModels({
    owner: {}
  }, {
    "microchains": {},
    "microchainsModifiers": {},
    "defaultMicrochain": {},
    "defaultMicrochainModifiers": {},
    "count": {},
    "countModifiers": {}
  }),
  emits: ["update:microchains", "update:defaultMicrochain", "update:count"],
  setup(__props) {
    const props = __props;
    const owner = toRef(props, "owner");
    const selectedNetwork = ref(void 0);
    const microchains = useModel(__props, "microchains");
    const defaultMicrochain = useModel(__props, "defaultMicrochain");
    const count = useModel(__props, "count");
    const _microchains = useObservable(
      liveQuery(async () => {
        if (owner.value !== void 0) {
          return await Microchain.microchains(0, 1e3, void 0, void 0, owner.value);
        }
        return await dbWallet.microchains.toArray();
      })
    );
    const _count = useObservable(
      liveQuery(async () => {
        if (owner.value !== void 0) {
          return (await Microchain.microchains(0, 1e3, void 0, void 0, owner.value)).length;
        }
        return await Microchain.count();
      })
    );
    const updateMicrochains = (__microchains) => {
      microchains.value = [...__microchains || []];
      defaultMicrochain.value = microchains.value.find((el) => el.default);
      if (defaultMicrochain.value === void 0 && microchains.value.length > 0) {
        defaultMicrochain.value = microchains.value[0];
      }
    };
    watch(_microchains, () => {
      updateMicrochains(_microchains.value ? _microchains.value : []);
    });
    watch(_count, () => {
      count.value = _count.value;
    });
    watch(owner, async () => {
      if (owner.value === void 0)
        return;
      const __microchains = await Microchain.microchains(0, 1e3, void 0, void 0, owner.value);
      updateMicrochains(__microchains);
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$2, {
        "selected-network": selectedNetwork.value,
        "onUpdate:selectedNetwork": _cache[0] || (_cache[0] = ($event) => selectedNetwork.value = $event)
      }, null, 8, ["selected-network"]);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "TokenBridge",
  props: {
    "tokens": {},
    "tokensModifiers": {},
    "count": {},
    "countModifiers": {}
  },
  emits: ["update:tokens", "update:count"],
  setup(__props) {
    const tokens = useModel(__props, "tokens");
    const count = useModel(__props, "count");
    const _tokens = useObservable(
      liveQuery(async () => {
        return await dbBase.tokens.toArray();
      })
    );
    const _count = useObservable(
      liveQuery(async () => {
        return await Token.count();
      })
    );
    watch(_tokens, () => {
      if (tokens.value === _tokens.value)
        return;
      tokens.value = _tokens.value;
    });
    watch(_count, () => {
      count.value = _count.value;
    });
    return () => {
    };
  }
});
export { ChainOperation as C, QList as Q, Token as T, _sfc_main$1 as _, QItem as a, _sfc_main as b, addFocusout as c, _sfc_main$2 as d, removeFocusout as r };

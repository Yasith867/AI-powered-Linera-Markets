import { A as ApolloClients } from "./index.d2b21240.js";
import { b as boot } from "./index.facf9114.js";
var apollo = boot(
  ({ app }) => {
    const apolloClients = {};
    app.provide(ApolloClients, apolloClients);
  }
);
export { apollo as default };

import { Q as QSpace } from "./QSpace.27146b0a.js";
import { b4 as EffectScope, b5 as ReactiveEffect, b6 as TrackOpTypes, b7 as TriggerOpTypes, b8 as customRef, b9 as effect, e as effectScope, aC as getCurrentScope, ba as getCurrentWatcher, bb as isProxy, bc as isReactive, bd as isReadonly, g as isRef, be as isShallow, bf as markRaw, aD as onScopeDispose, bg as onWatcherCleanup, bh as proxyRefs, q as reactive, bi as readonly, r as ref, bj as shallowReactive, bk as shallowReadonly, s as shallowRef, bl as stop, b1 as toRaw, as as toRef, bm as toRefs, bn as toValue, bo as triggerRef, u as unref, bp as camelize, bq as capitalize, S as normalizeClass, br as normalizeProps, a0 as normalizeStyle, L as toDisplayString, bs as toHandlerKey, bt as BaseTransition, bu as BaseTransitionPropsValidators, bv as Comment, bw as DeprecationTypes, bx as ErrorCodes, by as ErrorTypeStrings, F as Fragment, aS as KeepAlive, bz as Static, bA as Suspense, ag as Teleport, T as Text, bB as assertNumber, bC as callWithAsyncErrorHandling, bD as callWithErrorHandling, bE as cloneVNode, bF as compatUtils, a as computed, P as createBlock, V as createCommentVNode, I as createElementBlock, K as createBaseVNode, bG as createHydrationRenderer, bH as createPropsRestProxy, bI as createRenderer, bJ as createSlots, bK as createStaticVNode, R as createTextVNode, k as createVNode, bL as defineAsyncComponent, d as defineComponent, bM as defineEmits, bN as defineExpose, bO as defineModel, bP as defineOptions, bQ as defineProps, bR as defineSlots, bS as devtools, j as getCurrentInstance, bT as getTransitionRawChildren, bU as guardReactiveProps, h, bV as handleError, p as hasInjectionContext, bW as hydrateOnIdle, bX as hydrateOnInteraction, bY as hydrateOnMediaQuery, bZ as hydrateOnVisible, b_ as initCustomFormatter, i as inject, b$ as isMemoSame, c0 as isRuntimeOnly, c1 as isVNode, c2 as mergeDefaults, ar as mergeModels, c3 as mergeProps, n as nextTick, aM as onActivated, b2 as onBeforeMount, m as onBeforeUnmount, aX as onBeforeUpdate, aj as onDeactivated, c4 as onErrorCaptured, o as onMounted, c5 as onRenderTracked, c6 as onRenderTriggered, l as onServerPrefetch, f as onUnmounted, aG as onUpdated, H as openBlock, c7 as popScopeId, B as provide, c8 as pushScopeId, c9 as queuePostFlushCb, ca as registerRuntimeCompiler, M as renderList, cb as renderSlot, Y as resolveComponent, cc as resolveDirective, $ as resolveDynamicComponent, cd as resolveFilter, ce as resolveTransitionHooks, cf as setBlockTracking, cg as setDevtoolsHook, ch as setTransitionHooks, ci as ssrContextKey, cj as ssrUtils, ck as toHandlers, cl as transformVNodeArgs, cm as useAttrs, cn as useId, aq as useModel, co as useSSRContext, cp as useSlots, cq as useTemplateRef, cr as useTransitionState, cs as version, ct as warn, w as watch, cu as watchEffect, cv as watchPostEffect, cw as watchSyncEffect, cx as withAsyncContext, J as withCtx, cy as withDefaults, O as withDirectives, cz as withMemo, cA as withScopeId, Z as Transition, cB as TransitionGroup, cC as VueElement, cD as createApp, cE as createSSRApp, cF as defineCustomElement, cG as defineSSRCustomElement, cH as hydrate, cI as initDirectivesForSSR, cJ as render, cK as useCssModule, cL as useCssVars, cM as useHost, cN as useShadowRoot, cO as vModelCheckbox, cP as vModelDynamic, cQ as vModelRadio, cR as vModelSelect, cS as vModelText, a_ as vShow, cT as withKeys, aH as withModifiers, t as createComponent, ad as cleanEvt, ac as addEvt, v as hSlot, ap as stopAndPrevent, Q as QIcon, aw as QBtn } from "./index.facf9114.js";
import { x as useAnchorStaticProps, h as useModelToggleProps, v as validatePosition, i as validateOffset, s as scrollTargetProp, j as useModelToggleEmits, k as useTick, l as useScrollTarget, d as useAnchor, m as useModelToggle, n as usePortal, r as removeClickOutside, o as setPosition, g as getScrollTarget, p as parsePosition, q as addClickOutside } from "./position-engine.5060c7a9.js";
import { u as useTransitionProps, a as useTransition } from "./microchain.44c150a3.js";
import { u as useTimeout } from "./use-timeout.0aac84f1.js";
import { c as clearSelection } from "./selection.ef9ae985.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import { v as validatePassword } from "./verify.2de89a24.js";
import { g as getAugmentedNamespace, c as commonjsGlobal } from "./_commonjsHelpers.294d03c4.js";
/**
* vue v3.5.3
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
const compile = () => {
};
var vue_runtime_esmBundler = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  compile,
  EffectScope,
  ReactiveEffect,
  TrackOpTypes,
  TriggerOpTypes,
  customRef,
  effect,
  effectScope,
  getCurrentScope,
  getCurrentWatcher,
  isProxy,
  isReactive,
  isReadonly,
  isRef,
  isShallow,
  markRaw,
  onScopeDispose,
  onWatcherCleanup,
  proxyRefs,
  reactive,
  readonly,
  ref,
  shallowReactive,
  shallowReadonly,
  shallowRef,
  stop,
  toRaw,
  toRef,
  toRefs,
  toValue,
  triggerRef,
  unref,
  camelize,
  capitalize,
  normalizeClass,
  normalizeProps,
  normalizeStyle,
  toDisplayString,
  toHandlerKey,
  BaseTransition,
  BaseTransitionPropsValidators,
  Comment,
  DeprecationTypes,
  ErrorCodes,
  ErrorTypeStrings,
  Fragment,
  KeepAlive,
  Static,
  Suspense,
  Teleport,
  Text,
  assertNumber,
  callWithAsyncErrorHandling,
  callWithErrorHandling,
  cloneVNode,
  compatUtils,
  computed,
  createBlock,
  createCommentVNode,
  createElementBlock,
  createElementVNode: createBaseVNode,
  createHydrationRenderer,
  createPropsRestProxy,
  createRenderer,
  createSlots,
  createStaticVNode,
  createTextVNode,
  createVNode,
  defineAsyncComponent,
  defineComponent,
  defineEmits,
  defineExpose,
  defineModel,
  defineOptions,
  defineProps,
  defineSlots,
  devtools,
  getCurrentInstance,
  getTransitionRawChildren,
  guardReactiveProps,
  h,
  handleError,
  hasInjectionContext,
  hydrateOnIdle,
  hydrateOnInteraction,
  hydrateOnMediaQuery,
  hydrateOnVisible,
  initCustomFormatter,
  inject,
  isMemoSame,
  isRuntimeOnly,
  isVNode,
  mergeDefaults,
  mergeModels,
  mergeProps,
  nextTick,
  onActivated,
  onBeforeMount,
  onBeforeUnmount,
  onBeforeUpdate,
  onDeactivated,
  onErrorCaptured,
  onMounted,
  onRenderTracked,
  onRenderTriggered,
  onServerPrefetch,
  onUnmounted,
  onUpdated,
  openBlock,
  popScopeId,
  provide,
  pushScopeId,
  queuePostFlushCb,
  registerRuntimeCompiler,
  renderList,
  renderSlot,
  resolveComponent,
  resolveDirective,
  resolveDynamicComponent,
  resolveFilter,
  resolveTransitionHooks,
  setBlockTracking,
  setDevtoolsHook,
  setTransitionHooks,
  ssrContextKey,
  ssrUtils,
  toHandlers,
  transformVNodeArgs,
  useAttrs,
  useId,
  useModel,
  useSSRContext,
  useSlots,
  useTemplateRef,
  useTransitionState,
  version,
  warn,
  watch,
  watchEffect,
  watchPostEffect,
  watchSyncEffect,
  withAsyncContext,
  withCtx,
  withDefaults,
  withDirectives,
  withMemo,
  withScopeId,
  Transition,
  TransitionGroup,
  VueElement,
  createApp,
  createSSRApp,
  defineCustomElement,
  defineSSRCustomElement,
  hydrate,
  initDirectivesForSSR,
  render,
  useCssModule,
  useCssVars,
  useHost,
  useShadowRoot,
  vModelCheckbox,
  vModelDynamic,
  vModelRadio,
  vModelSelect,
  vModelText,
  vShow,
  withKeys,
  withModifiers
}, Symbol.toStringTag, { value: "Module" }));
var QTooltip = createComponent({
  name: "QTooltip",
  inheritAttrs: false,
  props: {
    ...useAnchorStaticProps,
    ...useModelToggleProps,
    ...useTransitionProps,
    maxHeight: {
      type: String,
      default: null
    },
    maxWidth: {
      type: String,
      default: null
    },
    transitionShow: {
      ...useTransitionProps.transitionShow,
      default: "jump-down"
    },
    transitionHide: {
      ...useTransitionProps.transitionHide,
      default: "jump-up"
    },
    anchor: {
      type: String,
      default: "bottom middle",
      validator: validatePosition
    },
    self: {
      type: String,
      default: "top middle",
      validator: validatePosition
    },
    offset: {
      type: Array,
      default: () => [14, 14],
      validator: validateOffset
    },
    scrollTarget: scrollTargetProp,
    delay: {
      type: Number,
      default: 0
    },
    hideDelay: {
      type: Number,
      default: 0
    },
    persistent: Boolean
  },
  emits: [
    ...useModelToggleEmits
  ],
  setup(props, { slots, emit, attrs }) {
    let unwatchPosition, observer;
    const vm = getCurrentInstance();
    const { proxy: { $q } } = vm;
    const innerRef = ref(null);
    const showing = ref(false);
    const anchorOrigin = computed(() => parsePosition(props.anchor, $q.lang.rtl));
    const selfOrigin = computed(() => parsePosition(props.self, $q.lang.rtl));
    const hideOnRouteChange = computed(() => props.persistent !== true);
    const { registerTick, removeTick } = useTick();
    const { registerTimeout } = useTimeout();
    const { transitionProps, transitionStyle } = useTransition(props);
    const { localScrollTarget, changeScrollEvent, unconfigureScrollTarget } = useScrollTarget(props, configureScrollTarget);
    const { anchorEl, canShow, anchorEvents } = useAnchor({ showing, configureAnchorEl });
    const { show, hide } = useModelToggle({
      showing,
      canShow,
      handleShow,
      handleHide,
      hideOnRouteChange,
      processOnMount: true
    });
    Object.assign(anchorEvents, { delayShow, delayHide });
    const { showPortal, hidePortal, renderPortal } = usePortal(vm, innerRef, renderPortalContent, "tooltip");
    if ($q.platform.is.mobile === true) {
      const clickOutsideProps = {
        anchorEl,
        innerRef,
        onClickOutside(e) {
          hide(e);
          if (e.target.classList.contains("q-dialog__backdrop")) {
            stopAndPrevent(e);
          }
          return true;
        }
      };
      const hasClickOutside = computed(
        () => props.modelValue === null && props.persistent !== true && showing.value === true
      );
      watch(hasClickOutside, (val) => {
        const fn = val === true ? addClickOutside : removeClickOutside;
        fn(clickOutsideProps);
      });
      onBeforeUnmount(() => {
        removeClickOutside(clickOutsideProps);
      });
    }
    function handleShow(evt) {
      showPortal();
      registerTick(() => {
        observer = new MutationObserver(() => updatePosition());
        observer.observe(innerRef.value, { attributes: false, childList: true, characterData: true, subtree: true });
        updatePosition();
        configureScrollTarget();
      });
      if (unwatchPosition === void 0) {
        unwatchPosition = watch(
          () => $q.screen.width + "|" + $q.screen.height + "|" + props.self + "|" + props.anchor + "|" + $q.lang.rtl,
          updatePosition
        );
      }
      registerTimeout(() => {
        showPortal(true);
        emit("show", evt);
      }, props.transitionDuration);
    }
    function handleHide(evt) {
      removeTick();
      hidePortal();
      anchorCleanup();
      registerTimeout(() => {
        hidePortal(true);
        emit("hide", evt);
      }, props.transitionDuration);
    }
    function anchorCleanup() {
      if (observer !== void 0) {
        observer.disconnect();
        observer = void 0;
      }
      if (unwatchPosition !== void 0) {
        unwatchPosition();
        unwatchPosition = void 0;
      }
      unconfigureScrollTarget();
      cleanEvt(anchorEvents, "tooltipTemp");
    }
    function updatePosition() {
      setPosition({
        targetEl: innerRef.value,
        offset: props.offset,
        anchorEl: anchorEl.value,
        anchorOrigin: anchorOrigin.value,
        selfOrigin: selfOrigin.value,
        maxHeight: props.maxHeight,
        maxWidth: props.maxWidth
      });
    }
    function delayShow(evt) {
      if ($q.platform.is.mobile === true) {
        clearSelection();
        document.body.classList.add("non-selectable");
        const target = anchorEl.value;
        const evts = ["touchmove", "touchcancel", "touchend", "click"].map((e) => [target, e, "delayHide", "passiveCapture"]);
        addEvt(anchorEvents, "tooltipTemp", evts);
      }
      registerTimeout(() => {
        show(evt);
      }, props.delay);
    }
    function delayHide(evt) {
      if ($q.platform.is.mobile === true) {
        cleanEvt(anchorEvents, "tooltipTemp");
        clearSelection();
        setTimeout(() => {
          document.body.classList.remove("non-selectable");
        }, 10);
      }
      registerTimeout(() => {
        hide(evt);
      }, props.hideDelay);
    }
    function configureAnchorEl() {
      if (props.noParentEvent === true || anchorEl.value === null)
        return;
      const evts = $q.platform.is.mobile === true ? [
        [anchorEl.value, "touchstart", "delayShow", "passive"]
      ] : [
        [anchorEl.value, "mouseenter", "delayShow", "passive"],
        [anchorEl.value, "mouseleave", "delayHide", "passive"]
      ];
      addEvt(anchorEvents, "anchor", evts);
    }
    function configureScrollTarget() {
      if (anchorEl.value !== null || props.scrollTarget !== void 0) {
        localScrollTarget.value = getScrollTarget(anchorEl.value, props.scrollTarget);
        const fn = props.noParentEvent === true ? updatePosition : hide;
        changeScrollEvent(localScrollTarget.value, fn);
      }
    }
    function getTooltipContent() {
      return showing.value === true ? h("div", {
        ...attrs,
        ref: innerRef,
        class: [
          "q-tooltip q-tooltip--style q-position-engine no-pointer-events",
          attrs.class
        ],
        style: [
          attrs.style,
          transitionStyle.value
        ],
        role: "tooltip"
      }, hSlot(slots.default)) : null;
    }
    function renderPortalContent() {
      return h(Transition, transitionProps.value, getTooltipContent);
    }
    onBeforeUnmount(anchorCleanup);
    Object.assign(vm.proxy, { updatePosition });
    return renderPortal;
  }
});
var vueSimplePasswordMeter_umd = { exports: {} };
var require$$0 = /* @__PURE__ */ getAugmentedNamespace(vue_runtime_esmBundler);
(function(module, exports) {
  (function() {
    try {
      if (typeof document != "undefined") {
        var r = document.createElement("style");
        r.appendChild(document.createTextNode(".po-password-strength-bar{border-radius:2px;transition:all .2s linear;height:5px;margin-top:8px}.po-password-strength-bar.risky{background-color:#f95e68;width:10%}.po-password-strength-bar.guessable{background-color:#fb964d;width:32.5%}.po-password-strength-bar.weak{background-color:#fdd244;width:55%}.po-password-strength-bar.safe{background-color:#b0dc53;width:77.5%}.po-password-strength-bar.secure{background-color:#35cc62;width:100%}")), document.head.appendChild(r);
      }
    } catch (o) {
      console.error("vite-plugin-css-injected-by-js", o);
    }
  })();
  (function(t, n) {
    module.exports = n(require$$0);
  })(commonjsGlobal, function(t) {
    const n = ["123456", "qwerty", "password", "111111", "Abc123", "123456789", "12345678", "123123", "1234567890", "12345", "1234567", "qwertyuiop", "qwerty123", "1q2w3e", "password1", "123321", "Iloveyou", "12345"], h2 = (e) => n.includes(e), d = (e) => {
      let s = 0, r = 0, o = 0, c = 0, a = 0;
      const x = /[^A-Za-z0-9]/g, C = /(.*[a-z].*)/g, y = /(.*[A-Z].*)/g, v = /(.*[0-9].*)/g, k = /(\w)(\1+\1+\1+\1+)/g, M = x.test(e), i = C.test(e), u = y.test(e), l = v.test(e), p = k.test(e);
      if (e.length > 4) {
        if (h2(e))
          return 0;
        (i || u) && l && (a = 1), u && i && (c = 1), (i || u || l) && M && (o = 1), e.length > 8 && (r = 1), e.length > 12 && !p && (r = 2), e.length > 20 && !p && (r = 3), s = r + o + c + a, s > 4 && (s = 4);
      }
      return s;
    }, f = (e) => {
      switch (e) {
        case 0:
          return "risky";
        case 1:
          return "guessable";
        case 2:
          return "weak";
        case 3:
          return "safe";
        case 4:
          return "secure";
        default:
          return "";
      }
    }, w = (e) => {
      const s = d(e);
      return f(s);
    }, g = { name: "PasswordMeter", props: { password: String }, emits: ["score"], computed: { passwordClass() {
      if (!this.password)
        return null;
      const e = w(this.password), s = d(this.password);
      return this.$emit("score", { score: s, strength: e }), { [e]: true, scored: true };
    } } }, m = (e, s) => {
      const r = e.__vccOpts || e;
      for (const [o, c] of s)
        r[o] = c;
      return r;
    };
    function _(e, s, r, o, c, a) {
      return t.openBlock(), t.createElementBlock("div", { class: t.normalizeClass(["po-password-strength-bar", a.passwordClass]) }, null, 2);
    }
    return m(g, [["render", _]]);
  });
})(vueSimplePasswordMeter_umd);
var PasswordMeter = vueSimplePasswordMeter_umd.exports;
const _hoisted_1$1 = { class: "full-width text-center flex items-center justify-center" };
const _hoisted_2$1 = { class: "row fill-parent" };
const _hoisted_3$1 = {
  style: { width: "400px" },
  class: "text-left"
};
const _hoisted_4 = {
  style: { margin: "4px 0", lineHeight: "32px" },
  class: "row"
};
const _hoisted_5 = {
  style: { marginRight: "4px" },
  class: "text-bold"
};
const _hoisted_6 = {
  style: { margin: "4px 0", lineHeight: "32px" },
  class: "text-bold"
};
const _sfc_main$1 = defineComponent({
  __name: "NewPasswordInputView",
  props: {
    "password": { default: "" },
    "passwordModifiers": {},
    "error": { type: Boolean, ...{ default: false } },
    "errorModifiers": {}
  },
  emits: ["update:password", "update:error"],
  setup(__props) {
    const password = useModel(__props, "password");
    const confirmPassword = ref("");
    const display = ref(false);
    const displayHideText = ref("Display");
    const error = useModel(__props, "error");
    const passwordError = ref(false);
    const confirmPasswordError = ref(false);
    const passwordScore = ref(0);
    watch(display, () => {
      displayHideText.value = display.value ? "Hide" : "Display";
    });
    const updateError = () => {
      if (error.value) {
        passwordError.value = error.value;
        confirmPasswordError.value = error.value;
      }
    };
    const resetError = () => {
      confirmPasswordError.value = false;
      passwordError.value = false;
    };
    const onPasswordBlur = () => {
      updateError();
    };
    const onPasswordFocus = () => {
      resetError();
    };
    const onConfirmPasswordBlur = () => {
      updateError();
    };
    const onConfirmPasswordFocus = () => {
      resetError();
    };
    watch([password, confirmPassword], () => {
      passwordError.value = password.value === void 0 || !validatePassword(password.value);
      confirmPasswordError.value = confirmPassword.value === void 0 || !validatePassword(confirmPassword.value);
      error.value = password.value !== confirmPassword.value || passwordError.value || confirmPasswordError.value;
    });
    const onScore = (payload) => {
      passwordScore.value = payload.score;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2$1, [
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_3$1, [
            createBaseVNode("div", _hoisted_4, [
              createBaseVNode("span", _hoisted_5, toDisplayString(_ctx.$t("MSG_NEW_PASSWORD")), 1),
              createVNode(QIcon, {
                name: "bi-question-circle-fill",
                size: "12px",
                class: "cursor-pointer",
                color: "grey-6",
                style: { marginTop: "10px", marginLeft: "2px" }
              }, {
                default: withCtx(() => [
                  createVNode(QTooltip, null, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.$t("MSG_AT_LEAST_8_LETTERS_WITH_BRACKETS")), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(QSpace),
              createVNode(QBtn, {
                flat: "",
                dense: "",
                size: "0.8rem",
                label: displayHideText.value,
                onClick: _cache[0] || (_cache[0] = ($event) => display.value = !display.value),
                color: "blue-6",
                "no-caps": ""
              }, null, 8, ["label"])
            ]),
            createVNode(QInput, {
              outlined: "",
              dense: "",
              modelValue: password.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => password.value = $event),
              onBlur: onPasswordBlur,
              onFocus: onPasswordFocus,
              "hide-bottom-space": "",
              type: display.value ? "text" : "password"
            }, null, 8, ["modelValue", "type"]),
            createVNode(unref(PasswordMeter), {
              onScore,
              password: password.value
            }, null, 8, ["password"]),
            createBaseVNode("div", _hoisted_6, toDisplayString(_ctx.$t("MSG_CONFIRM_PASSWORD")), 1),
            createVNode(QInput, {
              outlined: "",
              dense: "",
              modelValue: confirmPassword.value,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => confirmPassword.value = $event),
              onBlur: onConfirmPasswordBlur,
              onFocus: onConfirmPasswordFocus,
              "hide-bottom-space": "",
              type: display.value ? "text" : "password"
            }, null, 8, ["modelValue", "type"])
          ]),
          createVNode(QSpace)
        ])
      ]);
    };
  }
});
const _hoisted_1 = { class: "full-width text-center flex items-center justify-center" };
const _hoisted_2 = { class: "onboarding-page-title" };
const _hoisted_3 = ["innerHTML"];
const _sfc_main = defineComponent({
  __name: "NewPassword",
  props: {
    "password": { default: "" },
    "passwordModifiers": {},
    "error": { type: Boolean, ...{ default: false } },
    "errorModifiers": {}
  },
  emits: ["update:password", "update:error"],
  setup(__props) {
    const password = useModel(__props, "password");
    const error = useModel(__props, "error");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("h5", _hoisted_2, toDisplayString(_ctx.$t("MSG_CREATE_PASSWORD")), 1),
        createBaseVNode("p", null, toDisplayString(_ctx.$t("MSG_THIS_PASSWORD_WILL_UNLOCK_CHECKO_ON_THIS_DEVICE")), 1),
        createVNode(_sfc_main$1, {
          password: password.value,
          "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
          error: error.value,
          "onUpdate:error": _cache[1] || (_cache[1] = ($event) => error.value = $event)
        }, null, 8, ["password", "error"]),
        createBaseVNode("p", {
          class: "text-center",
          style: { margin: "24px 0 0 0" },
          innerHTML: _ctx.$t("MSG_BY_CONTINUE_YOU_UNDERSTAND_CHECKO_CANNOT_RECOVER_PASSWORD")
        }, null, 8, _hoisted_3)
      ]);
    };
  }
});
export { _sfc_main as _, _sfc_main$1 as a };

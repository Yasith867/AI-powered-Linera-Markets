import { _ as _sfc_main$4, Q as QStepper, a as QStep } from "./GenerateKey.376e5b53.js";
import { Q as QSpace, l as localStore } from "./QSpace.27146b0a.js";
import { d as defineComponent, ar as mergeModels, as as toRef, aq as useModel, a as computed, r as ref, w as watch, o as onMounted, H as openBlock, I as createElementBlock, K as createBaseVNode, L as toDisplayString, k as createVNode, F as Fragment, M as renderList, P as createBlock, J as withCtx, aw as QBtn, V as createCommentVNode, S as normalizeClass, Q as QIcon, u as unref, W as useRouter } from "./index.facf9114.js";
import { _ as _sfc_main$5 } from "./PasswordBridge.41db8c1b.js";
import { _ as _sfc_main$6 } from "./NewPassword.aa418b24.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import "./db.46ddc67f.js";
import "./application.ca271889.js";
import { L as LoginTimestamp } from "./login_timestamp.410697ca.js";
import { O as Owner } from "./owner.bc60a389.js";
import { P as Password } from "./password.cda421c2.js";
import "./index.d2b21240.js";
import { u as useI18n } from "./vue-i18n.runtime.8c1649dd.js";
import "./use-panel.a32f17c8.js";
import "./selection.ef9ae985.js";
import "./use-timeout.0aac84f1.js";
import "./use-dark.ea7d71c2.js";
import "./index.f58c37d0.js";
import "./position-engine.5060c7a9.js";
import "./microchain.44c150a3.js";
import "./verify.2de89a24.js";
import "./_commonjsHelpers.294d03c4.js";
import "./private.use-form.4c048d1b.js";
const _hoisted_1$2 = { class: "text-center fill-parent" };
const _hoisted_2$2 = ["innerHTML"];
const _hoisted_3$1 = ["innerHTML"];
const _hoisted_4$1 = {
  class: "text-left text-bold vertical-sections-margin",
  style: { paddingLeft: "20px" }
};
const _hoisted_5$1 = {
  class: "text-left",
  style: { marginTop: "8px" }
};
const _hoisted_6$1 = {
  key: 0,
  class: "vertical-sections-margin"
};
const _hoisted_7 = { class: "row" };
const _hoisted_8 = { class: "text-bold" };
const _hoisted_9 = { class: "row vertical-items-margin" };
const _hoisted_10 = { class: "text-white vertical-items-margin label-text-small extra-margin-bottom" };
const _hoisted_11 = {
  key: 2,
  class: "full-width vertical-sections-margin"
};
const _sfc_main$3 = defineComponent({
  __name: "InitializeAccount",
  props: /* @__PURE__ */ mergeModels({
    password: {}
  }, {
    "showInnerActionBtn": { type: Boolean },
    "showInnerActionBtnModifiers": {},
    "mnemonic": {},
    "mnemonicModifiers": {},
    "privateKeyHex": {},
    "privateKeyHexModifiers": {}
  }),
  emits: ["update:showInnerActionBtn", "update:mnemonic", "update:privateKeyHex"],
  setup(__props) {
    const props = __props;
    const password = toRef(props, "password");
    const showInnerActionBtn = useModel(__props, "showInnerActionBtn");
    const mnemonic = useModel(__props, "mnemonic");
    const privateKeyHex = useModel(__props, "privateKeyHex");
    const mnemonicWords = computed(() => mnemonic.value?.split(" "));
    const showMnemonic = ref(false);
    watch(showMnemonic, () => {
      showInnerActionBtn.value = !showMnemonic.value;
    });
    onMounted(() => {
      showInnerActionBtn.value = true;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("h5", {
          class: "onboarding-page-title",
          innerHTML: _ctx.$t("MSG_WRITE_DOWN_RECOVERY_PHRASE")
        }, null, 8, _hoisted_2$2),
        createBaseVNode("p", {
          innerHTML: _ctx.$t("MSG_WRITE_DOWN_24_WORDS_RECOVERY_PHRASE_AND_SAVE_IT")
        }, null, 8, _hoisted_3$1),
        createBaseVNode("div", _hoisted_4$1, toDisplayString(_ctx.$t("MSG_TIPS")) + toDisplayString(_ctx.$t("MSG_COLON")), 1),
        createBaseVNode("ul", _hoisted_5$1, [
          createBaseVNode("li", null, toDisplayString(_ctx.$t("MSG_SAVE_IN_A_PASSWORD_MANAGER")), 1),
          createBaseVNode("li", null, toDisplayString(_ctx.$t("MSG_STORE_IN_A_SAFE_DEPOSIT_BOX")), 1),
          createBaseVNode("li", null, toDisplayString(_ctx.$t("MSG_WRITE_DOWN_AND_STORE_IN_MULTIPLE_SECRET_PLACES")), 1)
        ]),
        showMnemonic.value ? (openBlock(), createElementBlock("div", _hoisted_6$1, [
          createBaseVNode("div", _hoisted_7, [
            createBaseVNode("div", _hoisted_8, toDisplayString(_ctx.$t("MSG_MNEMONIC")), 1),
            createVNode(QSpace),
            createBaseVNode("div", {
              class: "text-blue-6 cursor-pointer label-text-small",
              onClick: _cache[0] || (_cache[0] = ($event) => showMnemonic.value = false)
            }, toDisplayString(_ctx.$t("MSG_HIDE")), 1)
          ]),
          createBaseVNode("div", _hoisted_9, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(mnemonicWords.value, (word, i) => {
              return openBlock(), createElementBlock("div", {
                key: word,
                class: normalizeClass(["mnemonic-grid", i % 5 === 0 ? "mnemonic-grid-start" : "", i < 5 ? "mnemonic-grid-top" : ""])
              }, toDisplayString(word), 3);
            }), 128))
          ])
        ])) : (openBlock(), createBlock(QCard, {
          key: 1,
          bordered: "",
          flat: "",
          class: "page-y-padding vertical-sections-margin bg-grey-9"
        }, {
          default: withCtx(() => [
            createVNode(QIcon, {
              name: "bi-eye",
              size: "20px",
              color: "white",
              class: "vertical-sections-margin"
            }),
            createBaseVNode("div", _hoisted_10, toDisplayString(_ctx.$t("MSG_MAKE_SURE_NOBODY_IS_LOOKING")), 1)
          ]),
          _: 1
        })),
        showInnerActionBtn.value ? (openBlock(), createElementBlock("div", _hoisted_11, [
          createVNode(QBtn, {
            flat: "",
            label: "Reveal secret recovery phrase",
            class: "btn full-width vertical-menus-margin",
            "no-caps": "",
            onClick: _cache[1] || (_cache[1] = ($event) => showMnemonic.value = !showMnemonic.value)
          })
        ])) : createCommentVNode("", true),
        createVNode(_sfc_main$4, {
          password: password.value,
          mnemonic: mnemonic.value,
          "onUpdate:mnemonic": _cache[2] || (_cache[2] = ($event) => mnemonic.value = $event),
          "private-key-hex": privateKeyHex.value,
          "onUpdate:privateKeyHex": _cache[3] || (_cache[3] = ($event) => privateKeyHex.value = $event)
        }, null, 8, ["password", "mnemonic", "private-key-hex"])
      ]);
    };
  }
});
const _hoisted_1$1 = { class: "fill-parent text-center" };
const _hoisted_2$1 = { class: "onboarding-page-title" };
const _hoisted_3 = {
  class: "text-left text-bold vertical-sections-margin",
  style: { paddingLeft: "20px" }
};
const _hoisted_4 = {
  class: "text-left",
  style: { marginTop: "8px" }
};
const _hoisted_5 = { class: "row vertical-sections-margin" };
const _hoisted_6 = { key: 0 };
const _sfc_main$2 = defineComponent({
  __name: "ValidateAccount",
  props: /* @__PURE__ */ mergeModels({
    mnemonic: {}
  }, {
    "modelValue": { type: Boolean },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const props = __props;
    const mnemonic = toRef(props, "mnemonic");
    const mnemonicWords = computed(() => mnemonic.value.split(" "));
    const blankIndexes = computed(() => [
      Math.floor(Math.random() * mnemonicWords.value.length),
      Math.floor(Math.random() * mnemonicWords.value.length),
      Math.floor(Math.random() * mnemonicWords.value.length),
      Math.floor(Math.random() * mnemonicWords.value.length),
      Math.floor(Math.random() * mnemonicWords.value.length),
      Math.floor(Math.random() * mnemonicWords.value.length),
      Math.floor(Math.random() * mnemonicWords.value.length)
    ].filter((el, i) => i % 2 === 0).slice(0, 3));
    const mnemonicPartialWords = ref(Array.from(mnemonicWords.value).map((el, i) => blankIndexes.value.includes(i) ? "" : el));
    const shadowMnemonicWords = ref(Array.from(mnemonicPartialWords.value));
    const valid = useModel(__props, "modelValue");
    watch(() => [shadowMnemonicWords.value[blankIndexes.value[0]], shadowMnemonicWords.value[blankIndexes.value[1]], shadowMnemonicWords.value[blankIndexes.value[2]]], () => {
      valid.value = shadowMnemonicWords.value[blankIndexes.value[0]] === mnemonicWords.value[blankIndexes.value[0]] && shadowMnemonicWords.value[blankIndexes.value[1]] === mnemonicWords.value[blankIndexes.value[1]] && shadowMnemonicWords.value[blankIndexes.value[2]] === mnemonicWords.value[blankIndexes.value[2]];
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("h5", _hoisted_2$1, toDisplayString(_ctx.$t("MSG_VALIDATE_SECRET_RECOVERY_PHRASE")), 1),
        createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_FILL_RIGHT_MNEMONIC_INTO_EMPTY_FIELDS")), 1),
        createBaseVNode("div", _hoisted_3, toDisplayString(_ctx.$t("MSG_TIPS")) + toDisplayString(_ctx.$t("MSG_COLON")), 1),
        createBaseVNode("ul", _hoisted_4, [
          createBaseVNode("li", null, toDisplayString(_ctx.$t("MSG_DONT_SAVE_MNEMONIC_PROPERLY_SAFE_TO_CREATE_NEW")), 1)
        ]),
        createBaseVNode("div", _hoisted_5, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(mnemonicPartialWords.value, (word, i) => {
            return openBlock(), createElementBlock("div", {
              key: word,
              class: normalizeClass(["mnemonic-grid", i % 5 === 0 ? "mnemonic-grid-start" : "", i < 5 ? "mnemonic-grid-top" : ""])
            }, [
              !blankIndexes.value.includes(i) ? (openBlock(), createElementBlock("div", _hoisted_6, toDisplayString(word), 1)) : (openBlock(), createBlock(QInput, {
                key: 1,
                borderless: "",
                dense: "",
                "hide-bottom-space": "",
                "input-class": "blank-text",
                modelValue: shadowMnemonicWords.value[i],
                "onUpdate:modelValue": ($event) => shadowMnemonicWords.value[i] = $event
              }, null, 8, ["modelValue", "onUpdate:modelValue"]))
            ], 2);
          }), 128))
        ])
      ]);
    };
  }
});
const _hoisted_1 = {
  key: 0,
  class: "row page-x-padding"
};
const _hoisted_2 = { class: "onboarding-btns row" };
const _sfc_main$1 = defineComponent({
  __name: "InitializeWallet",
  setup(__props) {
    const { t } = useI18n({ useScope: "global" });
    const step = ref(1);
    const password = ref(void 0);
    const passwordError = ref(false);
    const privateKeyHex = ref("");
    const mnemonic = ref("");
    const mnemonicValid = ref(false);
    const showInnerActionBtn = ref(false);
    const passwordBridge = ref();
    const router = useRouter();
    const canGotoNext = () => {
      switch (step.value) {
        case 1:
          return !passwordError.value && password.value?.length;
        case 3:
          return mnemonicValid.value;
        default:
          return true;
      }
    };
    const btnText = computed(() => {
      switch (step.value) {
        case 1:
          return t("MSG_CREATE_A_NEW_WALLET");
        case 2:
          return t("MSG_VALIDATE_SECURE_RECOVERY_PHRASE");
        case 3:
          return t("MSG_LINERA_NOW");
      }
      return t("MSG_NEXT");
    });
    const savePassword = async () => {
      await Password.save(password.value);
      await LoginTimestamp.save();
    };
    const saveAccount = async () => {
      await Owner.create(privateKeyHex.value, void 0, password.value);
      void router.push({ path: localStore.setting.formalizePath("/home") });
    };
    const onNextStepClick = async () => {
      switch (step.value) {
        case 1:
          step.value++;
          break;
        case 2:
          step.value++;
          break;
        case 3:
          await savePassword();
          await saveAccount();
          break;
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["full-width text-center onboarding-container", unref(localStore).setting.extensionMode ? "" : "onboarding-stepper-padding"])
      }, [
        createVNode(QStepper, {
          flat: "",
          modelValue: step.value,
          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => step.value = $event),
          "done-color": "green-6",
          animated: "",
          "alternative-labels": "",
          "header-class": "hide"
        }, {
          default: withCtx(() => [
            createVNode(QStep, {
              name: 1,
              title: _ctx.$t("MSG_CREATE_PASSWORD"),
              done: step.value > 1
            }, {
              default: withCtx(() => [
                createVNode(_sfc_main$6, {
                  password: password.value,
                  "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
                  error: passwordError.value,
                  "onUpdate:error": _cache[1] || (_cache[1] = ($event) => passwordError.value = $event)
                }, null, 8, ["password", "error"])
              ]),
              _: 1
            }, 8, ["title", "done"]),
            createVNode(QStep, {
              name: 2,
              title: _ctx.$t("MSG_SECURE_WALLET"),
              done: step.value > 2
            }, {
              default: withCtx(() => [
                createVNode(_sfc_main$3, {
                  password: password.value,
                  "show-inner-action-btn": showInnerActionBtn.value,
                  "onUpdate:showInnerActionBtn": _cache[2] || (_cache[2] = ($event) => showInnerActionBtn.value = $event),
                  mnemonic: mnemonic.value,
                  "onUpdate:mnemonic": _cache[3] || (_cache[3] = ($event) => mnemonic.value = $event),
                  "private-key-hex": privateKeyHex.value,
                  "onUpdate:privateKeyHex": _cache[4] || (_cache[4] = ($event) => privateKeyHex.value = $event)
                }, null, 8, ["password", "show-inner-action-btn", "mnemonic", "private-key-hex"])
              ]),
              _: 1
            }, 8, ["title", "done"]),
            createVNode(QStep, {
              name: 3,
              title: _ctx.$t("MSG_VALIDATE_RECOVERY"),
              done: step.value > 3
            }, {
              default: withCtx(() => [
                createVNode(_sfc_main$2, {
                  mnemonic: mnemonic.value,
                  modelValue: mnemonicValid.value,
                  "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => mnemonicValid.value = $event)
                }, null, 8, ["mnemonic", "modelValue"])
              ]),
              _: 1
            }, 8, ["title", "done"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        !showInnerActionBtn.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_2, [
            createVNode(QBtn, {
              flat: "",
              class: "btn full-width vertical-menus-margin",
              label: btnText.value,
              disable: !canGotoNext(),
              onClick: onNextStepClick,
              "no-caps": ""
            }, null, 8, ["label", "disable"])
          ]),
          createVNode(QSpace)
        ])) : createCommentVNode("", true),
        createVNode(_sfc_main$5, {
          ref_key: "passwordBridge",
          ref: passwordBridge,
          password: password.value,
          "onUpdate:password": _cache[7] || (_cache[7] = ($event) => password.value = $event)
        }, null, 8, ["password"])
      ], 2);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "InitializeWalletPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(_sfc_main$1)
      ]);
    };
  }
});
export { _sfc_main as default };

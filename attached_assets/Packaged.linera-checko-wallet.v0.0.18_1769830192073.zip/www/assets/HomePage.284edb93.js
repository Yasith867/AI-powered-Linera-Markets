var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { Q as QSpace, l as localStore, a as lineraGraphqlMutationQueryWithQuery } from "./QSpace.27146b0a.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { c as getClientOptionsWithEndpointType, E as EndpointType, A as ApolloClient, r as rootData, s as stringify, Q as QBtnDropdown, a as QDialog, b as QMenu } from "./block.fef35c05.js";
import { t as createComponent, a as computed, h, j as getCurrentInstance, d as defineComponent, ar as mergeModels, r as ref, aq as useModel, H as openBlock, I as createElementBlock, k as createVNode, J as withCtx, F as Fragment, K as createBaseVNode, L as toDisplayString, M as renderList, P as createBlock, S as normalizeClass, aF as QAvatar, Q as QIcon, V as createCommentVNode, aw as QBtn, aG as onUpdated, o as onMounted, as as toRef, u as unref, aH as withModifiers, O as withDirectives, R as createTextVNode, w as watch, W as useRouter, x as emptyRenderFn, m as onBeforeUnmount, i as inject, aI as Ripple, aJ as tabsKey, ap as stopAndPrevent, aa as isKeyCode, aK as shouldIgnoreKey, D as hMergeSlot, aL as isDeepEqual, a4 as uid, aj as onDeactivated, aM as onActivated, v as hSlot, B as provide, aN as hDir, aO as Plugin, aP as isDate, aQ as defaultLang, a0 as normalizeStyle, _ as _export_sfc, aR as Menu, f as onUnmounted } from "./index.facf9114.js";
import { Q as QItemSection, C as ClosePopup, p as parse } from "./parse.cb29f9cb.js";
import { d as _sfc_main$X, Q as QList, a as QItem, T as Token, b as _sfc_main$_, _ as _sfc_main$10, C as ChainOperation } from "./TokenBridge.0a26909e.js";
import { u as useDarkProps, a as useDark } from "./use-dark.ea7d71c2.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { j as _Web3, E as Ed25519, d as decryptPassword, p as privateKey, k as chain_description_id, m as OWNER_CHAINS, n as OPEN_CHAIN, I as IMPORT_CHAIN, o as NETWORK_INFO, q as dbModel, s as OperationType, O as OperationState, h as defaultNetwork, H as HTTPSchema, W as WSSchema, t as Web3, v as ownerFromPublicKey, w as TRANSFER } from "./application.ca271889.js";
import { _ as _sfc_main$Y, a as _copyToClipboard, s as shortid, c as copyToClipboard, b as _sfc_main$12, d as _sfc_main$13, Q as QBadge, l as lineraLogo, e as _sfc_main$14, f as _sfc_main$15, M as MicrochainsInnerView, g as _sfc_main$16 } from "./MicrochainsInnerView.9e5fbcce.js";
import { b as MicrochainOwner, M as Microchain$1, N as Network } from "./microchain.44c150a3.js";
import { a as dbWallet, d as dbBase, l as liveQuery } from "./db.46ddc67f.js";
import { p as provideApolloClient, k as useMutation, a as useQuery } from "./index.d2b21240.js";
import { A as Account, _ as _sfc_main$Z, O as OwnerSelector, M as MemeApplicationOperation, a as _sfc_main$11 } from "./TokenCardView.41a4cbdd.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import { O as Owner, M as MicrochainOwnerFungibleTokenBalance, a as MicrochainFungibleTokenBalance } from "./owner.bc60a389.js";
import { _ as _sfc_main$$ } from "./PasswordBridge.41db8c1b.js";
import { Q as QSpinnerGears, T as TouchRepeat } from "./TouchRepeat.093c17cd.js";
import { P as Password } from "./password.cda421c2.js";
import { Q as QResizeObserver, b as QInnerLoading, a as QSpinnerFacebook } from "./QInnerLoading.401a74c0.js";
import { k as useTick } from "./position-engine.5060c7a9.js";
import { u as useTimeout } from "./use-timeout.0aac84f1.js";
import { u as usePanelChildProps, a as usePanelProps, b as usePanelEmits, c as usePanel } from "./use-panel.a32f17c8.js";
import { Q as QStepper, a as QStep } from "./GenerateKey.376e5b53.js";
import { u as useI18n } from "./vue-i18n.runtime.8c1649dd.js";
import { u as useObservable } from "./index.f58c37d0.js";
import { c as cheCkoLogo } from "./CheCko.b9dd764c.js";
import "./_commonjsHelpers.294d03c4.js";
import "./private.use-form.4c048d1b.js";
import "./selection.ef9ae985.js";
class Activity {
}
__publicField(Activity, "addressActivities", async (publicKey) => {
  const acts = [];
  acts.push(
    ...await dbWallet.activities.where("targetAddress").equalsIgnoreCase(publicKey).toArray()
  );
  acts.push(
    ...await dbWallet.activities.where("sourceAddress").equalsIgnoreCase(publicKey).toArray()
  );
  return acts;
});
__publicField(Activity, "ownerActivities", async (offset, limit, owner) => {
  const microchainOwners = await MicrochainOwner.ownerMicrochainOwners(owner.owner) || [];
  if (!microchainOwners)
    return [];
  const microchains = microchainOwners.reduce(
    (ids, a) => {
      ids.push(a.microchain);
      return ids;
    },
    []
  ) || [];
  if (!microchains)
    return [];
  return await dbWallet.activities.where("targetChain").anyOf(microchains).or("sourceChain").anyOf(microchains).offset(offset).limit(limit).toArray();
});
__publicField(Activity, "count", async () => {
  return await dbWallet.activities.count();
});
__publicField(Activity, "create", async (microchain, tokenId, sourceChain, sourceAddress, targetChain, targetAddress, amount, blockHeight, timestamp, certificateHash, grant) => {
  const activities = (await dbWallet.activities.toArray()).filter(
    (activity2) => {
      return activity2.sourceChain === sourceChain && activity2.sourceAddress === sourceAddress && activity2.targetChain === targetChain && activity2.targetAddress === targetAddress && activity2.timestamp === timestamp && activity2.blockHeight === blockHeight && activity2.certificateHash === certificateHash;
    }
  );
  if (activities.length)
    return activities[0];
  const activity = {
    microchain,
    tokenId,
    sourceChain,
    sourceAddress,
    targetChain,
    targetAddress,
    amount,
    blockHeight,
    timestamp,
    certificateHash,
    grant
  };
  await dbWallet.activities.add(activity);
  return activity;
});
const _Microchain = class {
};
let Microchain = _Microchain;
__publicField(Microchain, "openChain", async (owner) => {
  const options = await getClientOptionsWithEndpointType(EndpointType.Faucet);
  if (!options)
    return void 0;
  const apolloClient = new ApolloClient(options);
  const { mutate } = provideApolloClient(apolloClient)(
    () => useMutation(OPEN_CHAIN)
  );
  owner = Account.accountOwner(owner);
  const res = await mutate({
    owner
  });
  return rootData(res).claim;
});
__publicField(Microchain, "initMicrochainStore", async (owner, secretKeyHex, chainId, creatorChainId) => {
  const options = await getClientOptionsWithEndpointType(EndpointType.Rpc);
  if (!options)
    return void 0;
  const apolloClient = new ApolloClient(options);
  const typeNameBytes = new TextEncoder().encode("Nonce::");
  const bytes = new Uint8Array([
    ...typeNameBytes,
    ..._Web3.hexToBytes(chainId)
  ]);
  const signature = {
    Ed25519: {
      signature: await Ed25519.signWithKeccac256Hash(secretKeyHex, bytes),
      public_key: Ed25519.publicHex(secretKeyHex)
    }
  };
  owner = Account.accountOwner(owner);
  const { mutate } = provideApolloClient(apolloClient)(
    () => useMutation(IMPORT_CHAIN)
  );
  return await mutate({
    owner,
    chainId,
    signature,
    creatorChainId
  });
});
__publicField(Microchain, "chains", async (owner) => {
  const options = await getClientOptionsWithEndpointType(EndpointType.Rpc);
  if (!options)
    return void 0;
  const apolloClient = new ApolloClient(options);
  owner = Account.accountOwner(owner);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      OWNER_CHAINS,
      {
        owner
      },
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      resolve(rootData(res).ownerChains);
    });
    onError((error) => {
      reject(new Error(`Get microchains: ${error}`));
    });
  });
});
__publicField(Microchain, "openMicrochain", async () => {
  const owner = (await dbWallet.owners.toArray()).find((el) => el.selected);
  if (!owner)
    return Promise.reject(new Error("Invalid owner"));
  const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
  if (!fingerPrint)
    return Promise.reject(new Error("Invalid fingerprint"));
  const password = (await dbBase.passwords.toArray()).find((el) => el.active);
  if (!password)
    return Promise.reject(new Error("Invalid password"));
  const _password = decryptPassword(password, fingerPrint.fingerPrint);
  const privateKeyHex = privateKey(owner, _password);
  const chainDescription = await _Microchain.openChain(owner?.owner);
  if (!chainDescription)
    return Promise.reject(new Error("Failed open chain"));
  const chainId = await chain_description_id(
    stringify(chainDescription).replace(
      "18446744073709552000",
      "18446744073709551615"
    )
  );
  const creatorChainId = chainDescription.origin.Child.parent;
  console.log("Open microchain", chainId, creatorChainId);
  await _Microchain.initMicrochainStore(
    owner.owner,
    privateKeyHex,
    chainId,
    creatorChainId
  );
  const microchain = await Microchain$1.create(
    owner.owner,
    chainId,
    creatorChainId
  );
  return microchain;
});
__publicField(Microchain, "importMicrochain", async (chainId, messageId, certificateHash) => {
  const owner = (await dbWallet.owners.toArray()).find((el) => el.selected);
  if (!owner)
    return Promise.reject(new Error("Invalid owner"));
  const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
  if (!fingerPrint)
    return Promise.reject(new Error("Invalid fingerprint"));
  const password = (await dbBase.passwords.toArray()).find((el) => el.active);
  if (!password)
    return Promise.reject(new Error("Invalid password"));
  const _password = decryptPassword(password, fingerPrint.fingerPrint);
  const privateKeyHex = privateKey(owner, _password);
  await _Microchain.initMicrochainStore(
    owner.owner,
    privateKeyHex,
    chainId,
    messageId
  );
  const microchain = await Microchain$1.create(
    owner.owner,
    chainId,
    messageId,
    certificateHash
  );
  return microchain;
});
class GenesisInfo {
}
__publicField(GenesisInfo, "getNetworkInfo", async () => {
  const options = await getClientOptionsWithEndpointType(EndpointType.Faucet);
  if (!options)
    return void 0;
  const apolloClient = new ApolloClient(options);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      NETWORK_INFO,
      {},
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      resolve(rootData(res));
    });
    onError((error) => {
      reject(new Error(`Get block: ${error}`));
    });
  });
});
const insetMap = {
  true: "inset",
  item: "item-inset",
  "item-thumbnail": "item-thumbnail-inset"
};
const margins = {
  xs: 2,
  sm: 4,
  md: 8,
  lg: 16,
  xl: 24
};
var QSeparator = createComponent({
  name: "QSeparator",
  props: {
    ...useDarkProps,
    spaced: [Boolean, String],
    inset: [Boolean, String],
    vertical: Boolean,
    color: String,
    size: String
  },
  setup(props) {
    const vm = getCurrentInstance();
    const isDark = useDark(props, vm.proxy.$q);
    const orientation = computed(() => props.vertical === true ? "vertical" : "horizontal");
    const orientClass = computed(() => ` q-separator--${orientation.value}`);
    const insetClass = computed(() => props.inset !== false ? `${orientClass.value}-${insetMap[props.inset]}` : "");
    const classes = computed(
      () => `q-separator${orientClass.value}${insetClass.value}` + (props.color !== void 0 ? ` bg-${props.color}` : "") + (isDark.value === true ? " q-separator--dark" : "")
    );
    const style = computed(() => {
      const acc = {};
      if (props.size !== void 0) {
        acc[props.vertical === true ? "width" : "height"] = props.size;
      }
      if (props.spaced !== false) {
        const size = props.spaced === true ? `${margins.md}px` : props.spaced in margins ? `${margins[props.spaced]}px` : props.spaced;
        const dir = props.vertical === true ? ["Left", "Right"] : ["Top", "Bottom"];
        acc[`margin${dir[0]}`] = acc[`margin${dir[1]}`] = size;
      }
      return acc;
    });
    return () => h("hr", {
      class: classes.value,
      style: style.value,
      "aria-orientation": orientation.value
    });
  }
});
const _hoisted_1$L = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_2$I = { class: "selector-margin-x-left" };
const _hoisted_3$E = { class: "text-bold text-grey-9" };
const _hoisted_4$A = { class: "selector-item-endpoint" };
const _hoisted_5$v = {
  key: 0,
  class: "selector-delete-btn"
};
const _hoisted_6$o = { class: "selector-action" };
const _sfc_main$W = defineComponent({
  __name: "NetworkSelector",
  props: {
    "modelValue": {},
    "modelModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["selected", "add"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const networks = ref([]);
    const network = useModel(__props, "modelValue");
    const emit = __emit;
    const onDeleteNetworkClick = async (network2) => {
      await Network.delete(network2.id);
    };
    const onNetworkSelected = async (_network) => {
      _network.selected = true;
      network.value = _network;
      await Network.update(_network);
      localStore.setting.NetworkInfo = await GenesisInfo.getNetworkInfo();
      emit("selected", _network);
    };
    const onAddNetworkClick = () => {
      localStore.setting.ShowSettingMenu = true;
      emit("add");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, { class: "selector-card" }, {
          default: withCtx(() => [
            createBaseVNode("p", _hoisted_1$L, toDisplayString(_ctx.$t("MSG_SELECT_A_NETWORK")), 1),
            createVNode(QList, { class: "selector-list" }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(networks.value, (_network) => {
                  return openBlock(), createBlock(QItem, {
                    key: _network.id,
                    clickable: "",
                    class: normalizeClass(["selector-item-padding-right tab-panel-item", _network.selected ? "selector-item-selected" : ""]),
                    onClick: ($event) => onNetworkSelected(_network)
                  }, {
                    default: withCtx(() => [
                      createBaseVNode("div", {
                        class: normalizeClass(["selector-indicator", _network.selected ? "selector-indicator-selected" : ""])
                      }, null, 2),
                      createVNode(QAvatar, { color: "red-1 selector-margin-x-left" }, {
                        default: withCtx(() => [
                          createVNode(QImg, {
                            src: _network.icon,
                            width: "48px",
                            height: "48px"
                          }, null, 8, ["src"])
                        ]),
                        _: 2
                      }, 1024),
                      createBaseVNode("div", _hoisted_2$I, [
                        createBaseVNode("div", _hoisted_3$E, toDisplayString(_network.name), 1),
                        createBaseVNode("div", _hoisted_4$A, toDisplayString(_network.faucetUrl), 1)
                      ]),
                      createVNode(QSpace),
                      !_network.preset && !_network.selected ? (openBlock(), createElementBlock("div", _hoisted_5$v, [
                        createVNode(QIcon, {
                          name: "bi-trash3",
                          size: "16px",
                          onClick: ($event) => onDeleteNetworkClick(_network)
                        }, null, 8, ["onClick"])
                      ])) : createCommentVNode("", true)
                    ]),
                    _: 2
                  }, 1032, ["class", "onClick"]);
                }), 128))
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_6$o, [
              createVNode(QBtn, {
                flat: "",
                class: "btn btn-alt full-width",
                label: _ctx.$t("MSG_ADD_NETWORK"),
                "no-caps": "",
                onClick: onAddNetworkClick
              }, null, 8, ["label"])
            ])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$X, {
          ref: "networkBridge",
          networks: networks.value,
          "onUpdate:networks": _cache[0] || (_cache[0] = ($event) => networks.value = $event)
        }, null, 8, ["networks"])
      ], 64);
    };
  }
});
var storageIcon = "assets/StorageIcon.76c36c7a.png";
var githubLogo = "assets/Github.5b8493ec.svg";
var discordLogo = "assets/Discord.12e6c995.svg";
var twitterLogo = "assets/Twitter.76e68b7f.svg";
var telegramLogo = "assets/Telegram.68cfd0af.svg";
var microchainLogo = "assets/Microchain.2e811191.svg";
var blobGatewayLogo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQEAAAEBCAIAAAD3joeqAAAACXBIWXMAAAsSAAALEgHS3X78AAALkUlEQVR4nO3dP0xb1x4HcPwnce519ajkQBcikQy8gT6lGyKjWUF6E3ImIjE8dSHDm6o248tWNe3QpY3UDZoxZjUjxJtR7AEPMRJe+hBvaGNf21zbT86NLJSm9jW+957fn+9naSMhOAa+nPO99/jcWOf1iVs+mQFQKT6fSbrlE2dvHz9/0Cm5vBTHjx6UQwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0QwZAO2QAtEMGQDtkALRDBkA7ZAC0S6p9/fH5TGI+Q2AgY7i1er/RHP0xsbSdvLsw+mN6DadbO4to0KzozYCV20hlVwkMZIz//fNfYz/m1saalVv3+QndSrX3dpCHbu3MrZ31/nsR4ug50JuB5L07BEYxRve07ufDEncneC3J5aXBf1bue//snV9cvq665WqnWBo74YikNwOJxTGLBwrcN75WL4nPrr+oi89lUtnVVHY1PbPVPa23C4edYknV5KA0Azc+XyIwivF8ruCDynNiccHe3rS3N91KtV04ah8cBvJpiVOagYkWDwb5yUAYeU4uLyWXl6yH6+3CUStfkL1GUnptlEsGLsvVsR8T3muJz2Ws3PqnPz21chuxtB3SVzFOaQbUFuJriNmWl4RbG2uhfiFTtM4DggpxNHmO2Za9vTn77AmXKdQ/jRlAIb62xOLC7Hff2NubkX3FCGjMAArxlG5trEmaEJABuswW4jFfd3Hhb//5982VL4x89WBpzAAKcSBitvXJV18KKMoq5wEU4uDY25vpnUdmxzAldRlAIQ7cYJ8F5xioywAKcRhYxwAZIIpyIf6odxvvHtAZj3/qMoBCHJ70zhbHK0X65gEU4jClHz+Kc3h33lW6MoBCHLbBBdPHzIqBrgygEEcgubzE66YBMkCRn0Icn79NdvzWQ057rXVlQFYhpltsvE2mBAbii7J5AIU4KqnsKpdyrCgDwgrx++MhCLNyG8RH6FGUAUmFmMVrSWVXWbQCZIAcP4U4yeS1sDjFTFEGUIijl1pjsHtC0zyAQhy5xOIC/WasJQMoxKbc+PzvxEeoJQMoxKYkyf/1QQZokVSIPdOchRoNLRlAITaF/rJNzTyAQmwO8bsEKjKAQmzW2GfkmKUiAyjEMAIyQIi8QsyCigygEMMIOuYBFGL4a/IzIO09xAzXQl3aTzeTnwFJhTg+n4nZViTDCRLxJ/whA1RILcQ+e45B8jOAQ7XM6v5G/TGvCuYBQYX4xj+Y3R0bvLTyCYFRjCI8AyjExvlZ45klPAMoxGb1zi98xtsgZIAEqYW486pEYBRjCM8ACrFZrXyB/iClzwMoxOa4lSrxOwMeyRlAITbL2c2zGKfkDKAQG+RWqvSvCHmQAfNEFmIuk4DwDKAQm9LKF7hMAtLnARRiE3rnF87ePpfRSs4ACrEpje9/6TeaXEYrOQMoxEY4e/uMVkEeZMAwX88hZvIwi/bBkbPHpgoPic2ApEKcJH9kp/dams9fEBjIxOTOA4IKMf05rXta//3rb3nVgCGZGZB2qNY90nlmHYDBt5fAGIInqRDH0nZ8jm4f6BSPGz8wuxD0AWTAJH93iOlOAq18gWkHuEpmBlCIw9ZvOs2fX7QPDgmObVJC5wEU4jB1T+t/PP2Rxb5oPwRmAIU4PP2m03pZ4HgTYASBGUAhDkmneNx8/quYP/9DyIAxjAqxW6k6u3l2myB8EpgBFOIAyf7t90icB1CIp9ZvOp1XJWcvL2/l82fSMoBCPKVO8fiyWOoUS6xve01EWgZQiK+hd35x+brqlquqfvWHkAEzzBbiftPp1s7cN2fdWv2yfKJhwTOCtAxIKsTx+dtuZaoy6r456zcc7//7jaY3+cguuNcgbh4QVIjbB4cyNiMQJ2rvtLBCDNEQlQFJhRgigwwYgBU5KaIyIKkQQ2RkzQOCCjFERk4GUIjheuRkAIUYrgcZiBoKMTVy7pHJukOcCfxsuV7DwRT0UXIyIKkQp7IPrNx6WGOoVHtv3+0XKp+4tbrCTXIfEJIBYYU41JPWk8vvPvnK/ZmZQcyUbxqVkwFhhTjKlxOfy6Syq6nsanpmq3tabxcOO8WSqp2kyECk/BRigyetJxYX7O1Ne3vTeyeNkh17QjIg6j3EBPJ8c+X+zZX71sP1duGolS/IXiMJuTaK9xCHIT6XsXLrn/701MptxNI2kVEFTkIGUIhDFbMtLwmp7ANSAwuKhAwIK8Rxkk+didlWemdr9tkTdo8KHwsZiI6fQkz8pPXE4sLsd99YuQ0CYwmMhAzIKsQMio2VW5999oTmfHUNIuYBQYWYxaPH3k8Iz57cXPmCwFimxT4DeA6xKTHb+uSrLwUUZfYZEFaIiT967M/SO1vpnUfURjURZCAiAgrxXxnss+AcA/YZQCGmgHUM+M8DuENMw7uNdyy7Ae8MoBCTkt7Z4niliHcGxBVi9rdg048fsbtvgAxEwed7iFms60YbXDB9zKwY8M6ApELMZV03VnJ56dbGGvFBXsV8HkAhJsl6yGmvNeMMCCvEYrbfeCsie3uTwEB8YZwBFGLKUtlVLqlGBkLnsxC/P+5BEC5brBlnQFIhlvfGFG8qYNEKOM8DkrZMS8yAFwMCoxiDawbE3SFmf2fgo1JrDHZPcM0ACjELicUF+s0YGQiX2kI8dIP8O+O4ZkDYKdPhj8WYJPlVK9t5AIWYicRnWAuFAFumGaG/zGOZAWGFmNrBctogAyHyu2Va9DxAf95mmQFhhdjUSevw/kfA8fuAQgwB4pcBFGIIFr8M4LFLECxkICx+7xBzO1juGrq0n27GLwOSCjHTg+UmRfwJfwznAVGFWMEk4O/PgUHMMiCsEHM5aX0a3d+oP+aVWQZQiNlxyyfEh4wMhMLvHWLy+8mm5/NbYRCzDEgqxDIOlhutd37hc0o0iNs8IKgQizlYboTOqxLZsQ1xygDuELPTyhfoD5lTBlCIeXErVeJ3BjzIQPB83yEWngFnN09gFONxygAKMSNupUr/ipCH1TyAQswHl0mAUwbEnTJ9O/yxGNPKF7hMApwyIK4Qi10I9c4vnL19AgPxCxkIGApx4/tf+o0mgYH4xSYDwgqx1IPlnL19RqsgD595AI9dIq99cOTssanCQzwyIG3LtMQMdE/rzecvCAxkYjwygEJMXPe0/vvX3/KqAUPIQJB0FmLWARj8OAiMYTxpd4gFrYU6xePGD8wuBH2ARwYkFWJJB8u18gWmHeAqBhlAISao33SaP79oHxwKeC0MMoAt09R0T+t/PP2Rxb5oP5CBwPgsxKxPWu83ndbLAsebACMwyAAKMRGd4nHz+a9i/vwPcZgHBBXiWNrmWIjdStXZzbPbBOET9QyIK8TM7o7J/u33UM+AtOcQMzlYrt90Oq9KrXyB/sko00MGgiHmsUud4vFlsdQplljf9poI9QxI2zJN8qT13vnF5euqW66q+tUfIj8PyCrERE5a7zedbu3MfXPWrdUvyyfyLvVMhHQGEnfvuBUGbcz1txCKz2cifjm9t87VBb13/K1bqyv8Yz9CrLn7kte7PwEClFxeYvlcSoAAIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaIQOgHTIA2iEDoB0yANohA6AdMgDaJePzmeTykvZvA2iVvHfn/3aoiOSNK0fyAAAAAElFTkSuQmCC";
var lineraSwapLogo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQEAAAEBCAIAAAD3joeqAAAACXBIWXMAAAsSAAALEgHS3X78AAAMm0lEQVR4nO3dPUxc2RkGYBINP9JFGo+wuEgQWxpGYLGCYbEiYYFo1pJxmhSk2YrKaaicYqnYIlRQhIoU62ZdpaLYFDFIuw0CCSWCgC0hg2A26wVpBi0aI82VxjBFtHs3swTm9/6cOed736farNhw74xfn3vPz/f96sv/vG4iQvXEjkdevnvD759gJe90/prfPoFjBggdM0DomAFCxwwQOmaA0DEDhI4ZIHTMAKFjBggdM0DomAFCxwwQOmaA0DEDhI4ZIHTMAKFjBggdM0DomAFCxwwQOmaA0DEDhI4ZIHTMAKFjBggdM0DomAFCxwwQOmaA0DEDhI4ZIHTMAKFjBggdM0DomAFCxwwQOmaA0DEDhI4ZIHTMAKFjBggdM0DomAFCxwwQOmaA0DEDZutqs4ajNvqn4A8zYLZ03pkfmJi+P4j+QfjADBhv9yIzfW/wxcjThBVD/yw8YQaMt3l+0tTU1GvFvhh5ygHBA2bAeLsXmeItcEDwgBkwXjrvHDvZ4l1wQKgXMyDB7vuzG3fhDghdbRb6R1MDZkCCtUzq9l30WrEXH/9uqvsB+qdTDTMgwZGTdQpXt2/EijTPxEeWhh5zQKiAGRBi4/z7cjeSjHZyQKiAGRBi7+LmK8F1HBAqYAaE2PhplaAyDgglMQNC5AqX12dIy3EHhPmBifZIC/pH9j/MgByrmW9rvJexjp6//fb34x098J9ZEzMgyt77TO23Y0Wa/zwwAT8gNDEDohw52cwHp647gh8QmpgBaXbrGQpcHBCYAVE2a5gdKskdEDCP4zADotQyQ1qOFWn+y9AnM/GHaAMCMyCK/z++U939L0aeQg0IzIAoM/ER/7djt1pQA0JEg2sIXXukJWHFettj7ZFmzS+1q9Xqamv3+N+2WXZrYFshprr7x+/2LBxsXT+jI5LwDEza8Sd2PBnt1OBazOMOCCunB8upbcG3KTYDCSs22z/ay1OFvk119w/f6Vw42DqqYS+GiWS+DySs2NLQYwYgKLLPZwrMQFebtTT02NL+0d84Ug/sC8zAbN8jBiAkIgcEaRlIWDG+AYdN2IAgLQNP7LgGVyGfOyDIOI4jbhxo53uwOjLOZ0rLAB+EFBNwPpN7Jcgv0w/sMwMUDHMHBGkZqFxihEJVHBDM2mwnLQPpfE6Dq4CWjHaadT5TWgY8H6SiAJl1PlNaBnb5LKSNsY6e+YEJ/a9TWgZyhUu+EugjGe2c1H7VUuC8kJ8ztRQ4W/sJU4EZqKvUFJHADHgoNUUhcQpXJfuDaEXmGtnGD3wcajyncPX89dfpvO5/H8nMwJ70Y+BGWE5tG3H8Uug4wNfiRls83FrV/inIJXa/EBfLGmgtkzIlAMwABW8tk1o43DLogxWbAfGVofR07GTNCoDkDNzo3k4KHDvZ56+/Me6Tlnx+4Hb3dgqPU7ia21/PFS6N+4wlZ4CvBMqYshRQkuhx4CJTsns7BW5uf93cSozCz1JW6N5OQVk8NLs2tfAMcB912JZTOwYtBZQkfhzgK0GI1jKpldO3pt+F8AzU2L2dPNg8PzFuKaAk+X1oVjPfzsTVFZ/7cZFIy1L9XW3W9L3BoGpRmrgWVo78+kKKj9RoO0OSzjsLh1uLQfzBddfCTFwKKEl+BhQfqdF8jnw1k/I5T+AUrhYOtsQEAKXOnIfu7Z7pX2/Qz1usuxYmrCkTRAZULhiPdfxG2e/yxk/5GVOOxdQFYxxQuEowrH3ha8/lZww6FlMXiAzkCpfKhoIxE2oMelg2WTk9EBkAoLrTKocC/Uttbta5hWQtkxLcohglA/V+634ko7ay3+VNOu/UPle2d3EmZimgJJQM1PWt+zR+14THodrKzxw72bn99fAvp5GAenAoKzpkt1r692yspfzMTzOhctbCygHKgMqiQ8k7uj8ObZyfVD5c4S4FiA8A2DhQ7VsPkBEdKCpv+pe3FlYOVj8yZUc9ktFO/dtPVJgvXjzUcdtfSLAyoHLBWP/FsnJ/I0hdCyuH40BY9F8sK1l+xqwScYHAyoDKokPj2m8cul1+xrgScYGA60+s7HSlFWnWf4b0enOAYye7nNpp6OU0BlwGNhW2JhjTfrHsyMm6c2XCjsXUBS4DxW9dASNmSDfOvze3RFwg4DKgsuhQrxXT/0jN5vmJuSXiAiH/TP1texdnQR0tr2o4aq/mvUyzjHf0THU/qPADXW2W3RpMwD43uUqcf4gZ2Dg/+UzV7xrr6PE21ZjOO0lVKwzJqI1ciAnxWUhlH+9hr/uoVZYCMGKja3gQM6B4htRzDFRudNX/vSU8oBlQWXTI84Kxyo2u+pcCCA9oBox40lD5jG7ENG5IQDOgsuiQnycNZZv8jNjoGhLcDBhRdIgbXRXAzYDKJw3Pf7y40VUBxPWBor+mdo5yZdeGdOit4m507VWy925Y+/OfIcHNwEz84fjdnk//+ZUG11LJ7vszNRlwSwEALhiDPgtN2vGp7n4jCkAofW+BXCxDzMCkHf+sb9T9Z/2/dZXdNTFnSOEykLBiM/GHxf9pyvZmNb+o14oBzpBiZSBhxZaGHluR5uK/MeJbV9ldE3AoAMpAe6Rltn/0egBc+n/rKqdxlW1W1QdKBtojLUtDn5ScYNF/Xlxld00jSgEECyUDs32j5WYYPe/rVMmIja6GgsjAbN9ohb/sjfjWlZYCAHslkJ+Bqe4HVU9O6v+tq9zoOnwH65VAeAYm7fhMfKTqjxnxrSvb6GpEKYAASc7AcNQuroVVZkoBCGW/C+pIjdgMJKzY/MBE7T8vu6dqvaD2UcvMQFebdWMtrCojeqqyu2YYBGagPdIyPzBRVwBM+dbZXTMMAjNQbi2sKnk9Vf3Qv7tmUKRloMJaWFXCeqr6hFN0SFQGZvtG/RRRlNRT1T8jDlcEQk4GJu24zyqidqs1W9tcagOpnMPVv7tmIIRk4PqxGD+e2PH5gQltd1NPdT9Q+e4O8los4TzxjWMxPo119Pz90R9UbtmvUcKK1TvZ5ZNbdEh8XwLjM3D7WEwgALfRlzQc7RRfktrsZ6EflwI+qnspgGqHsFhmcAbcYzFB9aGgkhCO1BicgfmBCTWFd5AZ0V3TJ1MzMNs3ykd2NcQXHTIyA9P3B5U1FCPxM6TmZWDSjk/fG9TgQlCIP1JjWAbGO3oCWQujusg+ZW9SBhJWbLbvkQYXAkf2DKkxGQhpLYxqwXGg8cqViCM1ZBcdMiADFUrEkTKCH4cMyMBMfIQBaDjBR2p0z4DPYzEUFMF9vLXOQMKKMQD6kFp0SOsMwHbM1ZPUokNaZyD9IafBVdDPpL4W652BvLNyeqDBhdDPRO4d0v2deDm1vZZJaXAh1CR1KDBgbnThcOvz/XVlvRmpApF9vM1YJ944P/n0X1+pLLxMJdmtlryJCmP2C+UKl3P764uHWxwQGkvesTLD9k6vZlLP/v0PDQufkLnMO0OTzjvPX3+9nNrhgECBMPU88crpWw4IDSGv5JbBdSU4IKjnFK6OVHVKVsb4eqPugKCshTW4DYUNEJSRUHM3nXee7bx6+e6NBtcinMgPWU7t9ZffvfnjzisOCOFZOT1I5xV1AFFJVA+OIyfLASEka5nUcmpb5K0J7EfGASFwK6cHC4dbwm6qSEL/gdvcAWH6/iCrcfm0eX6ycnqwe6GoRX5DyMyA6+V3bzZ/OJn/aCLU2tTypgvT+Vz6g3Ocy+5enIlvwCE8A78MCPcGp7r7A/k/dApXc/vrsv9eRCOzT/11ucLlcmr7T6+/CaSr6Zfv3jAAwsjPgGv3IvNs55X/U2mZPI93SoOSgaAGBJzu7TiAMuByBwTP5zNxurfjgMuAOyB4Pp8puNQULMQMuDyfz5RaagoWbgaK5zPrHRBAurfjgM6Aq94Bwe3eHvZVkTLMQJOHAUFq1UFMzMAvNs5PajyfidC9HQcz8H9qPJ8pstQULGaghKoH9u1WS3z3dhzMQGlVBwTx3dtxMAOVVBgQOEMqBjNQRXFAuPFjvVaMM6QyMAM1WTl9e/t8JocCGZiBWt0+sM8ZUhmYgfpcP7Avu3s7DmagbsUBQXb3dhzCzxOHxz2wz33UAjAD3h05WXkFaAHxWYjQMQOEjhkgdMwAoWMGCB0zQOiYAULHDBA6ZoDQMQOEjhkgdMwAoWMGCB0zQOiYAULHDBA6ZoDQMQOEjhkgdMwAoWMGCB0zQOiYAULHDBA6ZoDQMQOEjhkgdMwAoWMGCB0zQOiYAULHDBA6ZoDQMQOEjhkgdMwAoWMGCB0zQOiYAULHDBA6ZoDQMQOEjhkgdMwAoWMGCB0zQOgiyWgn+mdAwNojLf8F4b26wrcddGEAAAAASUVORK5CYII=";
var applicationManagementLogo = "assets/ApplicationManagement.eb72abc6.png";
/*!
 * qrcode.vue v3.4.1
 * A Vue.js component to generate QRCode.
 * © 2017-2023 @scopewu(https://github.com/scopewu)
 * MIT License.
 */
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
var qrcodegen;
(function(qrcodegen2) {
  var QrCode = function() {
    function QrCode2(version, errorCorrectionLevel, dataCodewords, msk) {
      this.version = version;
      this.errorCorrectionLevel = errorCorrectionLevel;
      this.modules = [];
      this.isFunction = [];
      if (version < QrCode2.MIN_VERSION || version > QrCode2.MAX_VERSION)
        throw new RangeError("Version value out of range");
      if (msk < -1 || msk > 7)
        throw new RangeError("Mask value out of range");
      this.size = version * 4 + 17;
      var row = [];
      for (var i = 0; i < this.size; i++)
        row.push(false);
      for (var i = 0; i < this.size; i++) {
        this.modules.push(row.slice());
        this.isFunction.push(row.slice());
      }
      this.drawFunctionPatterns();
      var allCodewords = this.addEccAndInterleave(dataCodewords);
      this.drawCodewords(allCodewords);
      if (msk == -1) {
        var minPenalty = 1e9;
        for (var i = 0; i < 8; i++) {
          this.applyMask(i);
          this.drawFormatBits(i);
          var penalty = this.getPenaltyScore();
          if (penalty < minPenalty) {
            msk = i;
            minPenalty = penalty;
          }
          this.applyMask(i);
        }
      }
      assert(0 <= msk && msk <= 7);
      this.mask = msk;
      this.applyMask(msk);
      this.drawFormatBits(msk);
      this.isFunction = [];
    }
    QrCode2.encodeText = function(text, ecl) {
      var segs = qrcodegen2.QrSegment.makeSegments(text);
      return QrCode2.encodeSegments(segs, ecl);
    };
    QrCode2.encodeBinary = function(data, ecl) {
      var seg = qrcodegen2.QrSegment.makeBytes(data);
      return QrCode2.encodeSegments([seg], ecl);
    };
    QrCode2.encodeSegments = function(segs, ecl, minVersion, maxVersion, mask, boostEcl) {
      if (minVersion === void 0) {
        minVersion = 1;
      }
      if (maxVersion === void 0) {
        maxVersion = 40;
      }
      if (mask === void 0) {
        mask = -1;
      }
      if (boostEcl === void 0) {
        boostEcl = true;
      }
      if (!(QrCode2.MIN_VERSION <= minVersion && minVersion <= maxVersion && maxVersion <= QrCode2.MAX_VERSION) || mask < -1 || mask > 7)
        throw new RangeError("Invalid value");
      var version;
      var dataUsedBits;
      for (version = minVersion; ; version++) {
        var dataCapacityBits_1 = QrCode2.getNumDataCodewords(version, ecl) * 8;
        var usedBits = QrSegment.getTotalBits(segs, version);
        if (usedBits <= dataCapacityBits_1) {
          dataUsedBits = usedBits;
          break;
        }
        if (version >= maxVersion)
          throw new RangeError("Data too long");
      }
      for (var _i = 0, _a = [QrCode2.Ecc.MEDIUM, QrCode2.Ecc.QUARTILE, QrCode2.Ecc.HIGH]; _i < _a.length; _i++) {
        var newEcl = _a[_i];
        if (boostEcl && dataUsedBits <= QrCode2.getNumDataCodewords(version, newEcl) * 8)
          ecl = newEcl;
      }
      var bb = [];
      for (var _b = 0, segs_1 = segs; _b < segs_1.length; _b++) {
        var seg = segs_1[_b];
        appendBits(seg.mode.modeBits, 4, bb);
        appendBits(seg.numChars, seg.mode.numCharCountBits(version), bb);
        for (var _c = 0, _d = seg.getData(); _c < _d.length; _c++) {
          var b = _d[_c];
          bb.push(b);
        }
      }
      assert(bb.length == dataUsedBits);
      var dataCapacityBits = QrCode2.getNumDataCodewords(version, ecl) * 8;
      assert(bb.length <= dataCapacityBits);
      appendBits(0, Math.min(4, dataCapacityBits - bb.length), bb);
      appendBits(0, (8 - bb.length % 8) % 8, bb);
      assert(bb.length % 8 == 0);
      for (var padByte = 236; bb.length < dataCapacityBits; padByte ^= 236 ^ 17)
        appendBits(padByte, 8, bb);
      var dataCodewords = [];
      while (dataCodewords.length * 8 < bb.length)
        dataCodewords.push(0);
      bb.forEach(function(b2, i) {
        return dataCodewords[i >>> 3] |= b2 << 7 - (i & 7);
      });
      return new QrCode2(version, ecl, dataCodewords, mask);
    };
    QrCode2.prototype.getModule = function(x, y) {
      return 0 <= x && x < this.size && 0 <= y && y < this.size && this.modules[y][x];
    };
    QrCode2.prototype.getModules = function() {
      return this.modules;
    };
    QrCode2.prototype.drawFunctionPatterns = function() {
      for (var i = 0; i < this.size; i++) {
        this.setFunctionModule(6, i, i % 2 == 0);
        this.setFunctionModule(i, 6, i % 2 == 0);
      }
      this.drawFinderPattern(3, 3);
      this.drawFinderPattern(this.size - 4, 3);
      this.drawFinderPattern(3, this.size - 4);
      var alignPatPos = this.getAlignmentPatternPositions();
      var numAlign = alignPatPos.length;
      for (var i = 0; i < numAlign; i++) {
        for (var j = 0; j < numAlign; j++) {
          if (!(i == 0 && j == 0 || i == 0 && j == numAlign - 1 || i == numAlign - 1 && j == 0))
            this.drawAlignmentPattern(alignPatPos[i], alignPatPos[j]);
        }
      }
      this.drawFormatBits(0);
      this.drawVersion();
    };
    QrCode2.prototype.drawFormatBits = function(mask) {
      var data = this.errorCorrectionLevel.formatBits << 3 | mask;
      var rem = data;
      for (var i = 0; i < 10; i++)
        rem = rem << 1 ^ (rem >>> 9) * 1335;
      var bits = (data << 10 | rem) ^ 21522;
      assert(bits >>> 15 == 0);
      for (var i = 0; i <= 5; i++)
        this.setFunctionModule(8, i, getBit(bits, i));
      this.setFunctionModule(8, 7, getBit(bits, 6));
      this.setFunctionModule(8, 8, getBit(bits, 7));
      this.setFunctionModule(7, 8, getBit(bits, 8));
      for (var i = 9; i < 15; i++)
        this.setFunctionModule(14 - i, 8, getBit(bits, i));
      for (var i = 0; i < 8; i++)
        this.setFunctionModule(this.size - 1 - i, 8, getBit(bits, i));
      for (var i = 8; i < 15; i++)
        this.setFunctionModule(8, this.size - 15 + i, getBit(bits, i));
      this.setFunctionModule(8, this.size - 8, true);
    };
    QrCode2.prototype.drawVersion = function() {
      if (this.version < 7)
        return;
      var rem = this.version;
      for (var i = 0; i < 12; i++)
        rem = rem << 1 ^ (rem >>> 11) * 7973;
      var bits = this.version << 12 | rem;
      assert(bits >>> 18 == 0);
      for (var i = 0; i < 18; i++) {
        var color = getBit(bits, i);
        var a = this.size - 11 + i % 3;
        var b = Math.floor(i / 3);
        this.setFunctionModule(a, b, color);
        this.setFunctionModule(b, a, color);
      }
    };
    QrCode2.prototype.drawFinderPattern = function(x, y) {
      for (var dy = -4; dy <= 4; dy++) {
        for (var dx = -4; dx <= 4; dx++) {
          var dist = Math.max(Math.abs(dx), Math.abs(dy));
          var xx = x + dx;
          var yy = y + dy;
          if (0 <= xx && xx < this.size && 0 <= yy && yy < this.size)
            this.setFunctionModule(xx, yy, dist != 2 && dist != 4);
        }
      }
    };
    QrCode2.prototype.drawAlignmentPattern = function(x, y) {
      for (var dy = -2; dy <= 2; dy++) {
        for (var dx = -2; dx <= 2; dx++)
          this.setFunctionModule(x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
      }
    };
    QrCode2.prototype.setFunctionModule = function(x, y, isDark) {
      this.modules[y][x] = isDark;
      this.isFunction[y][x] = true;
    };
    QrCode2.prototype.addEccAndInterleave = function(data) {
      var ver = this.version;
      var ecl = this.errorCorrectionLevel;
      if (data.length != QrCode2.getNumDataCodewords(ver, ecl))
        throw new RangeError("Invalid argument");
      var numBlocks = QrCode2.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
      var blockEccLen = QrCode2.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver];
      var rawCodewords = Math.floor(QrCode2.getNumRawDataModules(ver) / 8);
      var numShortBlocks = numBlocks - rawCodewords % numBlocks;
      var shortBlockLen = Math.floor(rawCodewords / numBlocks);
      var blocks = [];
      var rsDiv = QrCode2.reedSolomonComputeDivisor(blockEccLen);
      for (var i = 0, k = 0; i < numBlocks; i++) {
        var dat = data.slice(k, k + shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1));
        k += dat.length;
        var ecc = QrCode2.reedSolomonComputeRemainder(dat, rsDiv);
        if (i < numShortBlocks)
          dat.push(0);
        blocks.push(dat.concat(ecc));
      }
      var result = [];
      var _loop_1 = function(i2) {
        blocks.forEach(function(block, j) {
          if (i2 != shortBlockLen - blockEccLen || j >= numShortBlocks)
            result.push(block[i2]);
        });
      };
      for (var i = 0; i < blocks[0].length; i++) {
        _loop_1(i);
      }
      assert(result.length == rawCodewords);
      return result;
    };
    QrCode2.prototype.drawCodewords = function(data) {
      if (data.length != Math.floor(QrCode2.getNumRawDataModules(this.version) / 8))
        throw new RangeError("Invalid argument");
      var i = 0;
      for (var right = this.size - 1; right >= 1; right -= 2) {
        if (right == 6)
          right = 5;
        for (var vert = 0; vert < this.size; vert++) {
          for (var j = 0; j < 2; j++) {
            var x = right - j;
            var upward = (right + 1 & 2) == 0;
            var y = upward ? this.size - 1 - vert : vert;
            if (!this.isFunction[y][x] && i < data.length * 8) {
              this.modules[y][x] = getBit(data[i >>> 3], 7 - (i & 7));
              i++;
            }
          }
        }
      }
      assert(i == data.length * 8);
    };
    QrCode2.prototype.applyMask = function(mask) {
      if (mask < 0 || mask > 7)
        throw new RangeError("Mask value out of range");
      for (var y = 0; y < this.size; y++) {
        for (var x = 0; x < this.size; x++) {
          var invert = void 0;
          switch (mask) {
            case 0:
              invert = (x + y) % 2 == 0;
              break;
            case 1:
              invert = y % 2 == 0;
              break;
            case 2:
              invert = x % 3 == 0;
              break;
            case 3:
              invert = (x + y) % 3 == 0;
              break;
            case 4:
              invert = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 == 0;
              break;
            case 5:
              invert = x * y % 2 + x * y % 3 == 0;
              break;
            case 6:
              invert = (x * y % 2 + x * y % 3) % 2 == 0;
              break;
            case 7:
              invert = ((x + y) % 2 + x * y % 3) % 2 == 0;
              break;
            default:
              throw new Error("Unreachable");
          }
          if (!this.isFunction[y][x] && invert)
            this.modules[y][x] = !this.modules[y][x];
        }
      }
    };
    QrCode2.prototype.getPenaltyScore = function() {
      var result = 0;
      for (var y = 0; y < this.size; y++) {
        var runColor = false;
        var runX = 0;
        var runHistory = [0, 0, 0, 0, 0, 0, 0];
        for (var x = 0; x < this.size; x++) {
          if (this.modules[y][x] == runColor) {
            runX++;
            if (runX == 5)
              result += QrCode2.PENALTY_N1;
            else if (runX > 5)
              result++;
          } else {
            this.finderPenaltyAddHistory(runX, runHistory);
            if (!runColor)
              result += this.finderPenaltyCountPatterns(runHistory) * QrCode2.PENALTY_N3;
            runColor = this.modules[y][x];
            runX = 1;
          }
        }
        result += this.finderPenaltyTerminateAndCount(runColor, runX, runHistory) * QrCode2.PENALTY_N3;
      }
      for (var x = 0; x < this.size; x++) {
        var runColor = false;
        var runY = 0;
        var runHistory = [0, 0, 0, 0, 0, 0, 0];
        for (var y = 0; y < this.size; y++) {
          if (this.modules[y][x] == runColor) {
            runY++;
            if (runY == 5)
              result += QrCode2.PENALTY_N1;
            else if (runY > 5)
              result++;
          } else {
            this.finderPenaltyAddHistory(runY, runHistory);
            if (!runColor)
              result += this.finderPenaltyCountPatterns(runHistory) * QrCode2.PENALTY_N3;
            runColor = this.modules[y][x];
            runY = 1;
          }
        }
        result += this.finderPenaltyTerminateAndCount(runColor, runY, runHistory) * QrCode2.PENALTY_N3;
      }
      for (var y = 0; y < this.size - 1; y++) {
        for (var x = 0; x < this.size - 1; x++) {
          var color = this.modules[y][x];
          if (color == this.modules[y][x + 1] && color == this.modules[y + 1][x] && color == this.modules[y + 1][x + 1])
            result += QrCode2.PENALTY_N2;
        }
      }
      var dark = 0;
      for (var _i = 0, _a = this.modules; _i < _a.length; _i++) {
        var row = _a[_i];
        dark = row.reduce(function(sum, color2) {
          return sum + (color2 ? 1 : 0);
        }, dark);
      }
      var total = this.size * this.size;
      var k = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
      assert(0 <= k && k <= 9);
      result += k * QrCode2.PENALTY_N4;
      assert(0 <= result && result <= 2568888);
      return result;
    };
    QrCode2.prototype.getAlignmentPatternPositions = function() {
      if (this.version == 1)
        return [];
      else {
        var numAlign = Math.floor(this.version / 7) + 2;
        var step = this.version == 32 ? 26 : Math.ceil((this.version * 4 + 4) / (numAlign * 2 - 2)) * 2;
        var result = [6];
        for (var pos = this.size - 7; result.length < numAlign; pos -= step)
          result.splice(1, 0, pos);
        return result;
      }
    };
    QrCode2.getNumRawDataModules = function(ver) {
      if (ver < QrCode2.MIN_VERSION || ver > QrCode2.MAX_VERSION)
        throw new RangeError("Version number out of range");
      var result = (16 * ver + 128) * ver + 64;
      if (ver >= 2) {
        var numAlign = Math.floor(ver / 7) + 2;
        result -= (25 * numAlign - 10) * numAlign - 55;
        if (ver >= 7)
          result -= 36;
      }
      assert(208 <= result && result <= 29648);
      return result;
    };
    QrCode2.getNumDataCodewords = function(ver, ecl) {
      return Math.floor(QrCode2.getNumRawDataModules(ver) / 8) - QrCode2.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver] * QrCode2.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
    };
    QrCode2.reedSolomonComputeDivisor = function(degree) {
      if (degree < 1 || degree > 255)
        throw new RangeError("Degree out of range");
      var result = [];
      for (var i = 0; i < degree - 1; i++)
        result.push(0);
      result.push(1);
      var root = 1;
      for (var i = 0; i < degree; i++) {
        for (var j = 0; j < result.length; j++) {
          result[j] = QrCode2.reedSolomonMultiply(result[j], root);
          if (j + 1 < result.length)
            result[j] ^= result[j + 1];
        }
        root = QrCode2.reedSolomonMultiply(root, 2);
      }
      return result;
    };
    QrCode2.reedSolomonComputeRemainder = function(data, divisor) {
      var result = divisor.map(function(_) {
        return 0;
      });
      var _loop_2 = function(b2) {
        var factor = b2 ^ result.shift();
        result.push(0);
        divisor.forEach(function(coef, i) {
          return result[i] ^= QrCode2.reedSolomonMultiply(coef, factor);
        });
      };
      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var b = data_1[_i];
        _loop_2(b);
      }
      return result;
    };
    QrCode2.reedSolomonMultiply = function(x, y) {
      if (x >>> 8 != 0 || y >>> 8 != 0)
        throw new RangeError("Byte out of range");
      var z = 0;
      for (var i = 7; i >= 0; i--) {
        z = z << 1 ^ (z >>> 7) * 285;
        z ^= (y >>> i & 1) * x;
      }
      assert(z >>> 8 == 0);
      return z;
    };
    QrCode2.prototype.finderPenaltyCountPatterns = function(runHistory) {
      var n = runHistory[1];
      assert(n <= this.size * 3);
      var core = n > 0 && runHistory[2] == n && runHistory[3] == n * 3 && runHistory[4] == n && runHistory[5] == n;
      return (core && runHistory[0] >= n * 4 && runHistory[6] >= n ? 1 : 0) + (core && runHistory[6] >= n * 4 && runHistory[0] >= n ? 1 : 0);
    };
    QrCode2.prototype.finderPenaltyTerminateAndCount = function(currentRunColor, currentRunLength, runHistory) {
      if (currentRunColor) {
        this.finderPenaltyAddHistory(currentRunLength, runHistory);
        currentRunLength = 0;
      }
      currentRunLength += this.size;
      this.finderPenaltyAddHistory(currentRunLength, runHistory);
      return this.finderPenaltyCountPatterns(runHistory);
    };
    QrCode2.prototype.finderPenaltyAddHistory = function(currentRunLength, runHistory) {
      if (runHistory[0] == 0)
        currentRunLength += this.size;
      runHistory.pop();
      runHistory.unshift(currentRunLength);
    };
    QrCode2.MIN_VERSION = 1;
    QrCode2.MAX_VERSION = 40;
    QrCode2.PENALTY_N1 = 3;
    QrCode2.PENALTY_N2 = 3;
    QrCode2.PENALTY_N3 = 40;
    QrCode2.PENALTY_N4 = 10;
    QrCode2.ECC_CODEWORDS_PER_BLOCK = [
      [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
      [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
      [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
      [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30]
    ];
    QrCode2.NUM_ERROR_CORRECTION_BLOCKS = [
      [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
      [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
      [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
      [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81]
    ];
    return QrCode2;
  }();
  qrcodegen2.QrCode = QrCode;
  function appendBits(val, len, bb) {
    if (len < 0 || len > 31 || val >>> len != 0)
      throw new RangeError("Value out of range");
    for (var i = len - 1; i >= 0; i--)
      bb.push(val >>> i & 1);
  }
  function getBit(x, i) {
    return (x >>> i & 1) != 0;
  }
  function assert(cond) {
    if (!cond)
      throw new Error("Assertion error");
  }
  var QrSegment = function() {
    function QrSegment2(mode, numChars, bitData) {
      this.mode = mode;
      this.numChars = numChars;
      this.bitData = bitData;
      if (numChars < 0)
        throw new RangeError("Invalid argument");
      this.bitData = bitData.slice();
    }
    QrSegment2.makeBytes = function(data) {
      var bb = [];
      for (var _i = 0, data_2 = data; _i < data_2.length; _i++) {
        var b = data_2[_i];
        appendBits(b, 8, bb);
      }
      return new QrSegment2(QrSegment2.Mode.BYTE, data.length, bb);
    };
    QrSegment2.makeNumeric = function(digits) {
      if (!QrSegment2.isNumeric(digits))
        throw new RangeError("String contains non-numeric characters");
      var bb = [];
      for (var i = 0; i < digits.length; ) {
        var n = Math.min(digits.length - i, 3);
        appendBits(parseInt(digits.substring(i, i + n), 10), n * 3 + 1, bb);
        i += n;
      }
      return new QrSegment2(QrSegment2.Mode.NUMERIC, digits.length, bb);
    };
    QrSegment2.makeAlphanumeric = function(text) {
      if (!QrSegment2.isAlphanumeric(text))
        throw new RangeError("String contains unencodable characters in alphanumeric mode");
      var bb = [];
      var i;
      for (i = 0; i + 2 <= text.length; i += 2) {
        var temp = QrSegment2.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)) * 45;
        temp += QrSegment2.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i + 1));
        appendBits(temp, 11, bb);
      }
      if (i < text.length)
        appendBits(QrSegment2.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)), 6, bb);
      return new QrSegment2(QrSegment2.Mode.ALPHANUMERIC, text.length, bb);
    };
    QrSegment2.makeSegments = function(text) {
      if (text == "")
        return [];
      else if (QrSegment2.isNumeric(text))
        return [QrSegment2.makeNumeric(text)];
      else if (QrSegment2.isAlphanumeric(text))
        return [QrSegment2.makeAlphanumeric(text)];
      else
        return [QrSegment2.makeBytes(QrSegment2.toUtf8ByteArray(text))];
    };
    QrSegment2.makeEci = function(assignVal) {
      var bb = [];
      if (assignVal < 0)
        throw new RangeError("ECI assignment value out of range");
      else if (assignVal < 1 << 7)
        appendBits(assignVal, 8, bb);
      else if (assignVal < 1 << 14) {
        appendBits(2, 2, bb);
        appendBits(assignVal, 14, bb);
      } else if (assignVal < 1e6) {
        appendBits(6, 3, bb);
        appendBits(assignVal, 21, bb);
      } else
        throw new RangeError("ECI assignment value out of range");
      return new QrSegment2(QrSegment2.Mode.ECI, 0, bb);
    };
    QrSegment2.isNumeric = function(text) {
      return QrSegment2.NUMERIC_REGEX.test(text);
    };
    QrSegment2.isAlphanumeric = function(text) {
      return QrSegment2.ALPHANUMERIC_REGEX.test(text);
    };
    QrSegment2.prototype.getData = function() {
      return this.bitData.slice();
    };
    QrSegment2.getTotalBits = function(segs, version) {
      var result = 0;
      for (var _i = 0, segs_2 = segs; _i < segs_2.length; _i++) {
        var seg = segs_2[_i];
        var ccbits = seg.mode.numCharCountBits(version);
        if (seg.numChars >= 1 << ccbits)
          return Infinity;
        result += 4 + ccbits + seg.bitData.length;
      }
      return result;
    };
    QrSegment2.toUtf8ByteArray = function(str) {
      str = encodeURI(str);
      var result = [];
      for (var i = 0; i < str.length; i++) {
        if (str.charAt(i) != "%")
          result.push(str.charCodeAt(i));
        else {
          result.push(parseInt(str.substring(i + 1, i + 3), 16));
          i += 2;
        }
      }
      return result;
    };
    QrSegment2.NUMERIC_REGEX = /^[0-9]*$/;
    QrSegment2.ALPHANUMERIC_REGEX = /^[A-Z0-9 $%*+.\/:-]*$/;
    QrSegment2.ALPHANUMERIC_CHARSET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
    return QrSegment2;
  }();
  qrcodegen2.QrSegment = QrSegment;
})(qrcodegen || (qrcodegen = {}));
(function(qrcodegen2) {
  (function(QrCode) {
    var Ecc = function() {
      function Ecc2(ordinal, formatBits) {
        this.ordinal = ordinal;
        this.formatBits = formatBits;
      }
      Ecc2.LOW = new Ecc2(0, 1);
      Ecc2.MEDIUM = new Ecc2(1, 0);
      Ecc2.QUARTILE = new Ecc2(2, 3);
      Ecc2.HIGH = new Ecc2(3, 2);
      return Ecc2;
    }();
    QrCode.Ecc = Ecc;
  })(qrcodegen2.QrCode || (qrcodegen2.QrCode = {}));
})(qrcodegen || (qrcodegen = {}));
(function(qrcodegen2) {
  (function(QrSegment) {
    var Mode = function() {
      function Mode2(modeBits, numBitsCharCount) {
        this.modeBits = modeBits;
        this.numBitsCharCount = numBitsCharCount;
      }
      Mode2.prototype.numCharCountBits = function(ver) {
        return this.numBitsCharCount[Math.floor((ver + 7) / 17)];
      };
      Mode2.NUMERIC = new Mode2(1, [10, 12, 14]);
      Mode2.ALPHANUMERIC = new Mode2(2, [9, 11, 13]);
      Mode2.BYTE = new Mode2(4, [8, 16, 16]);
      Mode2.KANJI = new Mode2(8, [8, 10, 12]);
      Mode2.ECI = new Mode2(7, [0, 0, 0]);
      return Mode2;
    }();
    QrSegment.Mode = Mode;
  })(qrcodegen2.QrSegment || (qrcodegen2.QrSegment = {}));
})(qrcodegen || (qrcodegen = {}));
var QR = qrcodegen;
var defaultErrorCorrectLevel = "H";
var ErrorCorrectLevelMap = {
  L: QR.QrCode.Ecc.LOW,
  M: QR.QrCode.Ecc.MEDIUM,
  Q: QR.QrCode.Ecc.QUARTILE,
  H: QR.QrCode.Ecc.HIGH
};
var SUPPORTS_PATH2D = function() {
  try {
    new Path2D().addPath(new Path2D());
  } catch (e) {
    return false;
  }
  return true;
}();
function validErrorCorrectLevel(level) {
  return level in ErrorCorrectLevelMap;
}
function generatePath(modules, margin) {
  if (margin === void 0) {
    margin = 0;
  }
  var ops = [];
  modules.forEach(function(row, y) {
    var start = null;
    row.forEach(function(cell, x) {
      if (!cell && start !== null) {
        ops.push("M".concat(start + margin, " ").concat(y + margin, "h").concat(x - start, "v1H").concat(start + margin, "z"));
        start = null;
        return;
      }
      if (x === row.length - 1) {
        if (!cell) {
          return;
        }
        if (start === null) {
          ops.push("M".concat(x + margin, ",").concat(y + margin, " h1v1H").concat(x + margin, "z"));
        } else {
          ops.push("M".concat(start + margin, ",").concat(y + margin, " h").concat(x + 1 - start, "v1H").concat(start + margin, "z"));
        }
        return;
      }
      if (cell && start === null) {
        start = x;
      }
    });
  });
  return ops.join("");
}
var QRCodeProps = {
  value: {
    type: String,
    required: true,
    default: ""
  },
  size: {
    type: Number,
    default: 100
  },
  level: {
    type: String,
    default: defaultErrorCorrectLevel,
    validator: function(l) {
      return validErrorCorrectLevel(l);
    }
  },
  background: {
    type: String,
    default: "#fff"
  },
  foreground: {
    type: String,
    default: "#000"
  },
  margin: {
    type: Number,
    required: false,
    default: 0
  }
};
var QRCodeVueProps = __assign(__assign({}, QRCodeProps), { renderAs: {
  type: String,
  required: false,
  default: "canvas",
  validator: function(as) {
    return ["canvas", "svg"].indexOf(as) > -1;
  }
} });
var QRCodeSvg = defineComponent({
  name: "QRCodeSvg",
  props: QRCodeProps,
  setup: function(props) {
    var numCells = ref(0);
    var fgPath = ref("");
    var generate = function() {
      var value = props.value, level = props.level, margin = props.margin;
      var cells = QR.QrCode.encodeText(value, ErrorCorrectLevelMap[level]).getModules();
      numCells.value = cells.length + margin * 2;
      fgPath.value = generatePath(cells, margin);
    };
    generate();
    onUpdated(generate);
    return function() {
      return h("svg", {
        width: props.size,
        height: props.size,
        "shape-rendering": "crispEdges",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 ".concat(numCells.value, " ").concat(numCells.value)
      }, [
        h("path", {
          fill: props.background,
          d: "M0,0 h".concat(numCells.value, "v").concat(numCells.value, "H0z")
        }),
        h("path", { fill: props.foreground, d: fgPath.value })
      ]);
    };
  }
});
var QRCodeCanvas = defineComponent({
  name: "QRCodeCanvas",
  props: QRCodeProps,
  setup: function(props) {
    var canvasEl = ref(null);
    var generate = function() {
      var value = props.value, level = props.level, size = props.size, margin = props.margin, background = props.background, foreground = props.foreground;
      var canvas = canvasEl.value;
      if (!canvas) {
        return;
      }
      var ctx = canvas.getContext("2d");
      if (!ctx) {
        return;
      }
      var cells = QR.QrCode.encodeText(value, ErrorCorrectLevelMap[level]).getModules();
      var numCells = cells.length + margin * 2;
      var devicePixelRatio = window.devicePixelRatio || 1;
      var scale = size / numCells * devicePixelRatio;
      canvas.height = canvas.width = size * devicePixelRatio;
      ctx.scale(scale, scale);
      ctx.fillStyle = background;
      ctx.fillRect(0, 0, numCells, numCells);
      ctx.fillStyle = foreground;
      if (SUPPORTS_PATH2D) {
        ctx.fill(new Path2D(generatePath(cells, margin)));
      } else {
        cells.forEach(function(row, rdx) {
          row.forEach(function(cell, cdx) {
            if (cell) {
              ctx.fillRect(cdx + margin, rdx + margin, 1, 1);
            }
          });
        });
      }
    };
    onMounted(generate);
    onUpdated(generate);
    return function() {
      return h("canvas", {
        ref: canvasEl,
        style: { width: "".concat(props.size, "px"), height: "".concat(props.size, "px") }
      });
    };
  }
});
var QrcodeVue = defineComponent({
  name: "Qrcode",
  render: function() {
    var _a = this.$props, renderAs = _a.renderAs, value = _a.value, _size = _a.size, _margin = _a.margin, _level = _a.level, background = _a.background, foreground = _a.foreground;
    var size = _size >>> 0;
    var margin = _margin >>> 0;
    var level = validErrorCorrectLevel(_level) ? _level : defaultErrorCorrectLevel;
    return h(renderAs === "svg" ? QRCodeSvg : QRCodeCanvas, { value, size, margin, level, background, foreground });
  },
  props: QRCodeVueProps
});
var AccountDetailAvatarView_vue_vue_type_style_index_0_scope_true_lang = "";
const _hoisted_1$K = { class: "row" };
const _hoisted_2$H = { class: "selector-margin-x-left account-avatar" };
const _hoisted_3$D = {
  key: 0,
  class: "row"
};
const _hoisted_4$z = {
  key: 1,
  class: "row"
};
const _hoisted_5$u = { class: "text-bold text-grey-9" };
const _hoisted_6$n = { class: "text-grey-8 selector-item-currency-sub" };
const _sfc_main$V = defineComponent({
  __name: "AccountDetailAvatarView",
  props: {
    owner: {},
    editable: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const owner = toRef(props, "owner");
    const editable = toRef(props, "editable");
    const editing = ref(false);
    const ownerBridge = ref();
    const dbTokenBridge = ref();
    const tokenBalance = ref(0);
    const usdBalance = ref(0);
    const nativeTokenId = ref(0);
    const onEditClick = () => {
      editing.value = true;
    };
    const onSaveClick = async () => {
      await Owner.update(owner.value);
      editing.value = false;
    };
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$K, [
          createVNode(QSpace),
          createVNode(QAvatar, null, {
            default: withCtx(() => [
              createVNode(QImg, {
                src: unref(dbModel).ownerAvatar(owner.value)
              }, null, 8, ["src"])
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_2$H, [
            editing.value ? (openBlock(), createElementBlock("div", _hoisted_3$D, [
              createVNode(QInput, {
                outlined: "",
                dense: "",
                modelValue: owner.value.name,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => owner.value.name = $event)
              }, null, 8, ["modelValue"]),
              createVNode(QIcon, {
                name: "bi-check2",
                class: "page-item-x-margin-left cursor-pointer",
                size: "18px",
                style: { marginTop: "3px" },
                onClick: onSaveClick
              })
            ])) : (openBlock(), createElementBlock("div", _hoisted_4$z, [
              createBaseVNode("span", _hoisted_5$u, toDisplayString(owner.value.name), 1),
              editable.value ? (openBlock(), createBlock(QIcon, {
                key: 0,
                name: "bi-pencil-square",
                class: "page-item-x-margin-left cursor-pointer",
                size: "15px",
                style: { marginTop: "3px" },
                onClick: onEditClick
              })) : createCommentVNode("", true)
            ])),
            createBaseVNode("div", _hoisted_6$n, " $ " + toDisplayString(usdBalance.value.toFixed(4)) + " USD ", 1)
          ]),
          createVNode(QSpace)
        ]),
        createVNode(_sfc_main$Y, {
          ref_key: "ownerBridge",
          ref: ownerBridge
        }, null, 512),
        createVNode(_sfc_main$Z, {
          "token-balance": tokenBalance.value,
          "onUpdate:tokenBalance": _cache[1] || (_cache[1] = ($event) => tokenBalance.value = $event),
          "usd-balance": usdBalance.value,
          "onUpdate:usdBalance": _cache[2] || (_cache[2] = ($event) => usdBalance.value = $event),
          "token-id": nativeTokenId.value
        }, null, 8, ["token-balance", "usd-balance", "token-id"]),
        createVNode(_sfc_main$_, {
          ref_key: "dbTokenBridge",
          ref: dbTokenBridge
        }, null, 512)
      ], 64);
    };
  }
});
const _hoisted_1$J = { class: "page-x-padding" };
const _hoisted_2$G = { class: "text-center vertical-sections-margin" };
const _hoisted_3$C = { class: "row bg-red-1 tip vertical-sections-margin flex justify-center items-center cursor-pointer" };
const _hoisted_4$y = {
  class: "word-break-all",
  style: { width: "calc(100% - 16px)" }
};
const _sfc_main$U = defineComponent({
  __name: "AccountDetailInnerView",
  props: {
    owner: {}
  },
  emits: ["showPrivateKey"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const owner = toRef(props, "owner");
    const tokenBalance = ref(0);
    const usdBalance = ref(0);
    const nativeTokenId = ref(0);
    const emit = __emit;
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    const onShowPrivateKeyClick = () => {
      emit("showPrivateKey");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, { class: "selector-card" }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$J, [
              owner.value ? (openBlock(), createBlock(_sfc_main$V, {
                key: 0,
                owner: owner.value,
                editable: true
              }, null, 8, ["owner"])) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_2$G, [
                createVNode(QrcodeVue, {
                  value: owner.value.address,
                  size: 160
                }, null, 8, ["value"])
              ]),
              createBaseVNode("div", _hoisted_3$C, [
                createBaseVNode("div", _hoisted_4$y, " 0x" + toDisplayString(owner.value.address), 1),
                createVNode(QIcon, {
                  name: "bi-copy",
                  size: "16px",
                  onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(owner.value.address, evt), ["stop"]))
                })
              ]),
              createVNode(QBtn, {
                flat: "",
                "no-caps": "",
                class: "btn btn-alt full-width vertical-sections-margin",
                label: "Show private key",
                onClick: onShowPrivateKeyClick
              })
            ])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$Z, {
          "token-balance": tokenBalance.value,
          "onUpdate:tokenBalance": _cache[1] || (_cache[1] = ($event) => tokenBalance.value = $event),
          "usd-balance": usdBalance.value,
          "onUpdate:usdBalance": _cache[2] || (_cache[2] = ($event) => usdBalance.value = $event),
          "token-id": nativeTokenId.value
        }, null, 8, ["token-balance", "usd-balance", "token-id"])
      ], 64);
    };
  }
});
const _hoisted_1$I = { class: "row page-x-padding" };
const _hoisted_2$F = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_3$B = { class: "page-x-padding vertical-menus-margin" };
const _hoisted_4$x = { class: "row vertical-menus-margin" };
const _hoisted_5$t = { class: "row bg-red-1 tip cursor-pointer label-radius" };
const _hoisted_6$m = { class: "page-item-x-margin-left" };
const _hoisted_7$j = { class: "password vertical-sections-margin" };
const _hoisted_8$j = { class: "text-grey-9" };
const _hoisted_9$g = { class: "vertical-items-margin" };
const _hoisted_10$d = { class: "row warn vertical-sections-margin private-key-warn" };
const _hoisted_11$c = ["innerHTML"];
const _sfc_main$T = defineComponent({
  __name: "ShowPrivateKeyConfirmView",
  props: {
    owner: {}
  },
  emits: ["canceled", "back", "confirmed"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const owner = toRef(props, "owner");
    const tokenBalance = ref(0);
    const usdBalance = ref(0);
    const nativeTokenId = ref(0);
    const _password = ref("");
    const password = ref("");
    const emit = __emit;
    const onCloseClick = () => {
      emit("canceled");
    };
    const onBackClick = () => {
      emit("back");
    };
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    const onConfirmClick = () => {
      emit("confirmed");
    };
    const onCancelClick = () => {
      emit("back");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, { class: "selector-card" }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$I, [
              createVNode(QIcon, {
                name: "bi-arrow-left-short",
                size: "24px",
                class: "cursor-pointer",
                onClick: onBackClick
              }),
              createVNode(QSpace),
              createBaseVNode("p", _hoisted_2$F, toDisplayString(_ctx.$t("MSG_SHOW_PRIVATE_KEY")), 1),
              createVNode(QSpace),
              createVNode(QIcon, {
                name: "bi-x",
                size: "24px",
                class: "cursor-pointer",
                onClick: onCloseClick
              })
            ]),
            createBaseVNode("div", _hoisted_3$B, [
              owner.value ? (openBlock(), createBlock(_sfc_main$V, {
                key: 0,
                owner: owner.value,
                editable: false
              }, null, 8, ["owner"])) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_4$x, [
                createVNode(QSpace),
                createBaseVNode("div", _hoisted_5$t, [
                  createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(owner.value.owner, 10)), 1),
                  createBaseVNode("div", _hoisted_6$m, [
                    createVNode(QIcon, {
                      name: "bi-copy",
                      size: "16px",
                      style: { marginTop: "-3px" },
                      onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(owner.value.address, evt), ["stop"]))
                    })
                  ])
                ]),
                createVNode(QSpace)
              ]),
              createBaseVNode("div", _hoisted_7$j, [
                createBaseVNode("div", _hoisted_8$j, toDisplayString(_ctx.$t("MSG_VERIFY_PASSWORD")), 1),
                createBaseVNode("div", _hoisted_9$g, [
                  createVNode(QInput, {
                    outlined: "",
                    dense: "",
                    modelValue: _password.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => _password.value = $event),
                    type: "password"
                  }, null, 8, ["modelValue"])
                ])
              ]),
              createBaseVNode("div", _hoisted_10$d, [
                createVNode(QIcon, {
                  name: "bi-exclamation-triangle-fill",
                  color: "red-8",
                  size: "24px"
                }),
                createBaseVNode("div", {
                  style: { width: "calc(100% - 24px - 12px)" },
                  class: "selector-margin-x-left",
                  innerHTML: _ctx.$t("MSG_WARNING_DO_NOT_LEAK_THIS_PRIVATE_KEY")
                }, null, 8, _hoisted_11$c)
              ]),
              createVNode(QBtn, {
                flat: "",
                "no-caps": "",
                class: "btn full-width vertical-sections-margin",
                label: "Confirm",
                onClick: onConfirmClick,
                disable: _password.value.length === 0 || !password.value?.length || _password.value !== password.value
              }, null, 8, ["disable"]),
              createVNode(QBtn, {
                flat: "",
                "no-caps": "",
                class: "btn btn-alt full-width vertical-items-margin",
                label: "Cancel",
                onClick: onCancelClick
              })
            ])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$Z, {
          "token-balance": tokenBalance.value,
          "onUpdate:tokenBalance": _cache[2] || (_cache[2] = ($event) => tokenBalance.value = $event),
          "usd-balance": usdBalance.value,
          "onUpdate:usdBalance": _cache[3] || (_cache[3] = ($event) => usdBalance.value = $event),
          "token-id": nativeTokenId.value
        }, null, 8, ["token-balance", "usd-balance", "token-id"]),
        createVNode(_sfc_main$$, {
          password: password.value,
          "onUpdate:password": _cache[4] || (_cache[4] = ($event) => password.value = $event)
        }, null, 8, ["password"])
      ], 64);
    };
  }
});
const _hoisted_1$H = { class: "page-x-padding" };
const _hoisted_2$E = { class: "row" };
const _hoisted_3$A = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_4$w = { class: "vertical-menus-margin" };
const _hoisted_5$s = ["innerHTML"];
const _hoisted_6$l = ["innerHTML"];
const _hoisted_7$i = ["innerHTML"];
const _hoisted_8$i = { class: "vertical-sections-margin" };
const _sfc_main$S = defineComponent({
  __name: "ShowPrivateKeySecurityConfirmView",
  emits: ["canceled", "confirmed"],
  setup(__props, { emit: __emit }) {
    const confirmSeconds = ref(10);
    const confirmedSeconds = ref(0);
    const emit = __emit;
    const onCloseClick = () => {
      emit("canceled");
    };
    const onConfirmClick = () => {
      confirmedSeconds.value++;
      if (confirmSeconds.value === confirmedSeconds.value) {
        emit("confirmed");
      }
    };
    const onConfirmCanceled = () => {
      confirmedSeconds.value = 0;
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, { class: "selector-card" }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$H, [
            createBaseVNode("div", _hoisted_2$E, [
              createVNode(QSpace),
              createBaseVNode("p", _hoisted_3$A, toDisplayString(_ctx.$t("MSG_PROTECT_PRIVATE_KEY")), 1),
              createVNode(QSpace),
              createVNode(QIcon, {
                name: "bi-x",
                size: "24px",
                class: "cursor-pointer",
                onClick: onCloseClick
              })
            ]),
            createBaseVNode("div", _hoisted_4$w, [
              createBaseVNode("p", {
                innerHTML: _ctx.$t("MSG_PRIVATE_KEY_PROVIDE_FULL_PERMISSIONS")
              }, null, 8, _hoisted_5$s),
              createBaseVNode("p", {
                innerHTML: _ctx.$t("MSG_NEVER_SHARE_PRIVATE_KEY_TO_ANYONE_ELSE")
              }, null, 8, _hoisted_6$l),
              createBaseVNode("p", {
                innerHTML: _ctx.$t("MSG_PHISHING_USER_USE_IT_TO_STEAL_ASSETS")
              }, null, 8, _hoisted_7$i)
            ]),
            createBaseVNode("div", _hoisted_8$i, [
              withDirectives((openBlock(), createBlock(QBtn, {
                loading: confirmedSeconds.value > 0 && confirmedSeconds.value < confirmSeconds.value,
                percentage: confirmedSeconds.value * 100 / confirmSeconds.value,
                flat: "",
                class: "btn full-width",
                label: "Long press to show private key",
                "no-caps": "",
                onMouseup: onConfirmCanceled
              }, {
                loading: withCtx(() => [
                  createVNode(QSpinnerGears, { class: "on-left" }),
                  createTextVNode(" " + toDisplayString(_ctx.$t("MSG_CONFIRMING")), 1)
                ]),
                _: 1
              }, 8, ["loading", "percentage"])), [
                [
                  TouchRepeat,
                  onConfirmClick,
                  void 0,
                  { mouse: true }
                ]
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
const _hoisted_1$G = { class: "row page-x-padding" };
const _hoisted_2$D = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_3$z = { class: "page-x-padding vertical-items-margin" };
const _hoisted_4$v = {
  key: 1,
  class: "row bg-red-1 tip vertical-sections-margin flex justify-center items-center cursor-pointer"
};
const _hoisted_5$r = {
  class: "word-break-all",
  style: { width: "calc(100% - 16px)", padding: "8px" }
};
const _hoisted_6$k = { class: "row warn vertical-sections-margin private-key-warn" };
const _hoisted_7$h = ["innerHTML"];
const _hoisted_8$h = { class: "vertical-sections-margin" };
const _sfc_main$R = defineComponent({
  __name: "ShowPrivateKeyView",
  props: {
    owner: {}
  },
  emits: ["done", "canceled"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const owner = toRef(props, "owner");
    const confirmSeconds = ref(10);
    const confirmedSeconds = ref(0);
    const password = ref("");
    const emit = __emit;
    const onCloseClick = () => {
      emit("canceled");
    };
    const onDoneClick = () => {
      emit("done");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QCard, { class: "selector-card" }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$G, [
              createVNode(QSpace),
              createBaseVNode("p", _hoisted_2$D, toDisplayString(_ctx.$t("MSG_SHOW_PRIVATE_KEY")), 1),
              createVNode(QSpace),
              createVNode(QIcon, {
                name: "bi-x",
                size: "24px",
                class: "cursor-pointer",
                onClick: onCloseClick
              })
            ]),
            createBaseVNode("div", _hoisted_3$z, [
              owner.value ? (openBlock(), createBlock(_sfc_main$V, {
                key: 0,
                owner: owner.value,
                editable: false
              }, null, 8, ["owner"])) : createCommentVNode("", true),
              password.value?.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_4$v, [
                createBaseVNode("div", _hoisted_5$r, toDisplayString(unref(dbModel).privateKey(owner.value, password.value)), 1),
                createVNode(QIcon, {
                  name: "bi-copy",
                  size: "16px",
                  onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(unref(dbModel).privateKey(owner.value, password.value), evt), ["stop"]))
                })
              ])) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_6$k, [
                createVNode(QIcon, {
                  name: "bi-exclamation-triangle-fill",
                  color: "red-8",
                  size: "24px"
                }),
                createBaseVNode("div", {
                  style: { width: "calc(100% - 24px - 12px)" },
                  class: "selector-margin-x-left",
                  innerHTML: _ctx.$t("MSG_WARNING_DO_NOT_LEAK_THIS_PRIVATE_KEY")
                }, null, 8, _hoisted_7$h)
              ]),
              createBaseVNode("div", _hoisted_8$h, [
                createVNode(QBtn, {
                  loading: confirmedSeconds.value > 0 && confirmedSeconds.value < confirmSeconds.value,
                  percentage: confirmedSeconds.value * 100 / confirmSeconds.value,
                  flat: "",
                  class: "btn full-width",
                  label: "Done",
                  "no-caps": "",
                  onClick: onDoneClick
                }, null, 8, ["loading", "percentage"])
              ])
            ])
          ]),
          _: 1
        }),
        createVNode(_sfc_main$$, {
          password: password.value,
          "onUpdate:password": _cache[1] || (_cache[1] = ($event) => password.value = $event)
        }, null, 8, ["password"])
      ], 64);
    };
  }
});
const _hoisted_1$F = { key: 0 };
const _hoisted_2$C = { key: 1 };
const _hoisted_3$y = { key: 2 };
const _hoisted_4$u = { key: 3 };
const _sfc_main$Q = defineComponent({
  __name: "AccountDetailView",
  props: {
    owner: {}
  },
  emits: ["canceled", "done"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const owner = toRef(props, "owner");
    const step = ref(1);
    const emit = __emit;
    const onShowPrivateKey = () => {
      step.value++;
    };
    const onShowPrivateKeyConfirmCanceled = () => {
      step.value--;
    };
    const onShowPrivateKeyConfirmBack = () => {
      step.value--;
    };
    const onShowPrivateKeyConfirmed = () => {
      step.value++;
    };
    const onShowPrivateKeySecurityCanceled = () => {
      emit("canceled");
    };
    const onShowPrivateKeySecurityConfirmed = () => {
      step.value++;
    };
    const onShowPrivateKeyDone = () => {
      emit("done");
    };
    const onShowPrivateKeyCanceled = () => {
      emit("canceled");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_1$F, [
          owner.value ? (openBlock(), createBlock(_sfc_main$U, {
            key: 0,
            owner: owner.value,
            onShowPrivateKey
          }, null, 8, ["owner"])) : createCommentVNode("", true)
        ])) : createCommentVNode("", true),
        step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_2$C, [
          owner.value ? (openBlock(), createBlock(_sfc_main$T, {
            key: 0,
            owner: owner.value,
            onCanceled: onShowPrivateKeyConfirmCanceled,
            onBack: onShowPrivateKeyConfirmBack,
            onConfirmed: onShowPrivateKeyConfirmed
          }, null, 8, ["owner"])) : createCommentVNode("", true)
        ])) : createCommentVNode("", true),
        step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_3$y, [
          createVNode(_sfc_main$S, {
            onCanceled: onShowPrivateKeySecurityCanceled,
            onConfirmed: onShowPrivateKeySecurityConfirmed
          })
        ])) : createCommentVNode("", true),
        step.value === 4 ? (openBlock(), createElementBlock("div", _hoisted_4$u, [
          createVNode(_sfc_main$R, {
            owner: owner.value,
            onDone: onShowPrivateKeyDone,
            onCanceled: onShowPrivateKeyCanceled
          }, null, 8, ["owner"])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _sfc_main$P = defineComponent({
  __name: "MicrochainsImporter",
  setup(__props) {
    const selectedNetwork = ref(void 0);
    const networkId = computed(() => selectedNetwork.value?.id);
    watch(networkId, async (newValue) => {
      if (newValue === networkId.value)
        return;
      localStore.setting.MicrochainsImportState = localStore.settingDef.MicrochainsImportState.MicrochainsImporting;
      const password = await Password.password();
      if (!password)
        return Promise.reject(new Error("Invalid password"));
      const microchains = await Microchain$1.microchains(0, 1e3, false);
      for (const microchain of microchains) {
        const owners = await MicrochainOwner.microchainOwners(microchain.microchain);
        for (const owner of owners) {
          const privateKeyHex = privateKey(owner, password);
          try {
            await Microchain.initMicrochainStore(owner.owner, privateKeyHex, microchain.microchain, microchain.creatorChainId);
            microchain.imported = true;
          } catch {
            microchain.imported = false;
          }
          await Microchain$1.update(microchain);
        }
      }
      localStore.setting.MicrochainsImportState = localStore.settingDef.MicrochainsImportState.MicrochainsImported;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$X, {
        "selected-network": selectedNetwork.value,
        "onUpdate:selectedNetwork": _cache[0] || (_cache[0] = ($event) => selectedNetwork.value = $event)
      }, null, 8, ["selected-network"]);
    };
  }
});
const _hoisted_1$E = { class: "row full-width page-header shadow-1" };
const _hoisted_2$B = { class: "page-header-left-right page-header-network-btn" };
const _hoisted_3$x = { class: "row" };
const _hoisted_4$t = {
  key: 0,
  class: "header-items-margin-x-left page-header-network"
};
const _hoisted_5$q = { class: "header-account text-center" };
const _hoisted_6$j = { class: "account-icon" };
const _hoisted_7$g = { class: "header-items-margin-x-left" };
const _hoisted_8$g = { class: "header-items-margin-x-left" };
const _hoisted_9$f = { class: "header-text text-center row cursor-pointer" };
const _hoisted_10$c = { class: "header-items-margin-x-left cursor-pointer" };
const _hoisted_11$b = { class: "page-header-left-right row" };
const _sfc_main$O = defineComponent({
  __name: "PageHeaderView",
  setup(__props) {
    const networks = ref([]);
    const selectedNetwork = ref(void 0);
    const owners = ref([]);
    const selectedOwner = ref(void 0);
    const selectingNetwork = ref(false);
    const selectingOwner = ref(false);
    const displayingOwnerDetail = ref(false);
    const dbMicrochainBridge = ref();
    const onNetworkClick = () => {
      selectingNetwork.value = true;
    };
    const onAccountClick = () => {
      selectingOwner.value = true;
    };
    const onNetworkSelected = (network) => {
      selectingNetwork.value = false;
      selectedNetwork.value = network;
    };
    const onAddNetwork = () => {
      selectingNetwork.value = false;
    };
    const onOwnerSelected = (owner) => {
      selectingOwner.value = false;
      if (owner) {
        selectedOwner.value = owner;
      }
    };
    const onSettingsClick = () => {
      localStore.setting.ShowSettingMenu = true;
    };
    const onAccountDetailClick = () => {
      displayingOwnerDetail.value = true;
    };
    const onAccountDetailCanceled = () => {
      displayingOwnerDetail.value = false;
    };
    const onAccountDetailDone = () => {
      displayingOwnerDetail.value = false;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$E, [
          createBaseVNode("div", _hoisted_2$B, [
            createVNode(QBtnDropdown, {
              rounded: "",
              flat: "",
              filled: "",
              class: "btn-alt",
              "no-caps": "",
              dense: "",
              "dropdown-icon": "bi-chevron-down",
              "menu-anchor": "bottom left",
              "menu-self": "top left",
              onClick: onNetworkClick
            }, {
              label: withCtx(() => [
                createBaseVNode("div", _hoisted_3$x, [
                  createVNode(QImg, {
                    src: selectedNetwork.value?.icon,
                    width: "20px",
                    height: "20px"
                  }, null, 8, ["src"]),
                  !unref(localStore).setting.extensionMode ? (openBlock(), createElementBlock("div", _hoisted_4$t, toDisplayString(selectedNetwork.value?.name), 1)) : createCommentVNode("", true)
                ])
              ]),
              _: 1
            })
          ]),
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_5$q, [
            createBaseVNode("div", {
              class: "header-text text-center text-bold row cursor-pointer",
              onClick: onAccountClick
            }, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_6$j, [
                selectedOwner.value ? (openBlock(), createBlock(QImg, {
                  key: 0,
                  src: unref(dbModel).ownerAvatar(selectedOwner.value),
                  height: "14px",
                  width: "14px"
                }, null, 8, ["src"])) : createCommentVNode("", true)
              ]),
              createBaseVNode("div", _hoisted_7$g, toDisplayString(selectedOwner.value?.name), 1),
              createBaseVNode("div", _hoisted_8$g, [
                createVNode(QIcon, {
                  name: "bi-chevron-down",
                  size: "12px"
                })
              ]),
              createVNode(QSpace)
            ]),
            createBaseVNode("div", _hoisted_9$f, [
              createVNode(QSpace),
              createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(selectedOwner.value?.address, 6)), 1),
              createBaseVNode("div", _hoisted_10$c, [
                createVNode(QIcon, {
                  name: "bi-copy",
                  size: "12px",
                  onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(selectedOwner.value?.address, evt), ["stop"]))
                })
              ]),
              createVNode(QSpace)
            ])
          ]),
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_11$b, [
            createVNode(QSpace),
            createVNode(QIcon, {
              class: "header-icon cursor-pointer",
              name: "bi-three-dots-vertical",
              size: "12x"
            }, {
              default: withCtx(() => [
                createVNode(QMenu, {
                  anchor: "bottom end",
                  self: "top end",
                  offset: [0, 8]
                }, {
                  default: withCtx(() => [
                    createVNode(QCard, null, {
                      default: withCtx(() => [
                        withDirectives((openBlock(), createBlock(QItem, {
                          clickable: "",
                          disabled: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(QItemSection, { avatar: "" }, {
                              default: withCtx(() => [
                                createVNode(QIcon, {
                                  name: "bi-bell-fill",
                                  size: "12px"
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(QItemSection, null, {
                              default: withCtx(() => [
                                createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_NOTIFICATION")), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })), [
                          [ClosePopup]
                        ]),
                        createVNode(QSeparator),
                        withDirectives((openBlock(), createBlock(QItem, {
                          clickable: "",
                          onClick: onAccountDetailClick
                        }, {
                          default: withCtx(() => [
                            createVNode(QItemSection, { avatar: "" }, {
                              default: withCtx(() => [
                                createVNode(QIcon, {
                                  name: "bi-person-bounding-box",
                                  size: "12px"
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(QItemSection, null, {
                              default: withCtx(() => [
                                createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_ACCOUNT_DETAILS")), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })), [
                          [ClosePopup]
                        ]),
                        withDirectives((openBlock(), createBlock(QItem, {
                          clickable: "",
                          disabled: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(QItemSection, { avatar: "" }, {
                              default: withCtx(() => [
                                createVNode(QIcon, {
                                  name: "bi-box-arrow-up-right",
                                  size: "12px"
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(QItemSection, null, {
                              default: withCtx(() => [
                                createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_VIEW_ON_EXPLORER")), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })), [
                          [ClosePopup]
                        ]),
                        createVNode(QSeparator),
                        withDirectives((openBlock(), createBlock(QItem, {
                          clickable: "",
                          disabled: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(QItemSection, { avatar: "" }, {
                              default: withCtx(() => [
                                createVNode(QIcon, {
                                  name: "bi-box-arrow-in-right",
                                  size: "12px"
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(QItemSection, null, {
                              default: withCtx(() => [
                                createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_ALL_PERMISSIONS")), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })), [
                          [ClosePopup]
                        ]),
                        withDirectives((openBlock(), createBlock(QItem, {
                          clickable: "",
                          onClick: onSettingsClick
                        }, {
                          default: withCtx(() => [
                            createVNode(QItemSection, { avatar: "" }, {
                              default: withCtx(() => [
                                createVNode(QIcon, {
                                  name: "bi-gear-fill",
                                  size: "12px"
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(QItemSection, null, {
                              default: withCtx(() => [
                                createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_SETTINGS")), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })), [
                          [ClosePopup]
                        ]),
                        withDirectives((openBlock(), createBlock(QItem, {
                          clickable: "",
                          disabled: ""
                        }, {
                          default: withCtx(() => [
                            createVNode(QItemSection, { avatar: "" }, {
                              default: withCtx(() => [
                                createVNode(QIcon, {
                                  name: "bi-shield-lock-fill",
                                  size: "12px"
                                })
                              ]),
                              _: 1
                            }),
                            createVNode(QItemSection, null, {
                              default: withCtx(() => [
                                createBaseVNode("span", null, toDisplayString(_ctx.$t("MSG_LOCK_WALLET")), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })), [
                          [ClosePopup]
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ])
        ]),
        createVNode(_sfc_main$X, {
          networks: networks.value,
          "onUpdate:networks": _cache[1] || (_cache[1] = ($event) => networks.value = $event),
          "selected-network": selectedNetwork.value,
          "onUpdate:selectedNetwork": _cache[2] || (_cache[2] = ($event) => selectedNetwork.value = $event)
        }, null, 8, ["networks", "selected-network"]),
        createVNode(_sfc_main$Y, {
          owners: owners.value,
          "onUpdate:owners": _cache[3] || (_cache[3] = ($event) => owners.value = $event),
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[4] || (_cache[4] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["owners", "selected-owner"]),
        createVNode(_sfc_main$10, {
          ref_key: "dbMicrochainBridge",
          ref: dbMicrochainBridge
        }, null, 512),
        createVNode(_sfc_main$P),
        createVNode(QDialog, {
          modelValue: selectingNetwork.value,
          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => selectingNetwork.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$W, {
              modelValue: selectedNetwork.value,
              "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => selectedNetwork.value = $event),
              onSelected: onNetworkSelected,
              onAdd: onAddNetwork
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: selectingOwner.value,
          "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => selectingOwner.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(OwnerSelector, {
              modelValue: selectedOwner.value,
              "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => selectedOwner.value = $event),
              onSelected: onOwnerSelected,
              persistent: true
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: displayingOwnerDetail.value,
          "onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => displayingOwnerDetail.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$Q, {
              owner: selectedOwner.value,
              onCanceled: onAccountDetailCanceled,
              onDone: onAccountDetailDone
            }, null, 8, ["owner"])
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 64);
    };
  }
});
const _hoisted_1$D = { class: "page-padding full-width text-center home-token-balance" };
const _hoisted_2$A = { class: "item-currency-sub text-grey-8" };
const _hoisted_3$w = { class: "row home-token-action text-center page-y-padding" };
const _hoisted_4$s = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_5$p = { class: "page-item-y-margin-top" };
const _hoisted_6$i = { class: "page-item-y-margin-top" };
const _hoisted_7$f = { class: "page-item-y-margin-top" };
const _hoisted_8$f = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_9$e = { class: "page-item-y-margin-top" };
const _hoisted_10$b = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_11$a = { class: "page-item-y-margin-top" };
const _sfc_main$N = defineComponent({
  __name: "TokenBalanceView",
  setup(__props) {
    const tokenBalance = ref(0);
    const usdBalance = ref(0);
    const selectedOwner = ref(void 0);
    const microchainCount = ref(0);
    const router = useRouter();
    const onTransferClick = () => {
      void router.push({ path: localStore.setting.formalizePath("/transfer") });
    };
    const onSwapClick = () => {
      window.open("http://testnet-conway.lineraswap.fun");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$D, [
        createBaseVNode("div", null, toDisplayString(tokenBalance.value.toFixed(4)) + " " + toDisplayString(_ctx.$t("MSG_TEST_LINERA_TOKEN_SYMBOL")), 1),
        createBaseVNode("div", _hoisted_2$A, " $ " + toDisplayString(usdBalance.value.toFixed(4)) + " " + toDisplayString(_ctx.$t("MSG_USD")), 1),
        createBaseVNode("div", _hoisted_3$w, [
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_4$s, [
            createVNode(QAvatar, {
              color: "red-2",
              size: "36px"
            }, {
              default: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-currency-exchange",
                  size: "24px"
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_5$p, toDisplayString(_ctx.$t("MSG_EXCHANGE")), 1)
          ]),
          createBaseVNode("div", {
            class: "home-token-action-btn cursor-pointer",
            onClick: onTransferClick
          }, [
            createVNode(QAvatar, {
              color: "red-2",
              size: "36px"
            }, {
              default: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-arrow-up-right",
                  size: "24px"
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_6$i, toDisplayString(_ctx.$t("MSG_TRANSFER")), 1)
          ]),
          createBaseVNode("div", {
            class: "home-token-action-btn cursor-pointer",
            onClick: onSwapClick
          }, [
            createVNode(QAvatar, {
              color: "red-2",
              size: "36px"
            }, {
              default: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-arrow-repeat",
                  size: "24px"
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_7$f, toDisplayString(_ctx.$t("MSG_SWAP")), 1)
          ]),
          createBaseVNode("div", _hoisted_8$f, [
            createVNode(QAvatar, {
              color: "red-2",
              size: "36px"
            }, {
              default: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-arrow-left-right",
                  size: "24px"
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_9$e, toDisplayString(_ctx.$t("MSG_BRIDGE")), 1)
          ]),
          createBaseVNode("div", _hoisted_10$b, [
            createVNode(QAvatar, {
              color: "red-2",
              size: "36px"
            }, {
              default: withCtx(() => [
                createVNode(QIcon, {
                  name: "bi-clock",
                  size: "24px"
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_11$a, toDisplayString(_ctx.$t("MSG_STAKE")), 1)
          ]),
          createVNode(QSpace)
        ]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[0] || (_cache[0] = ($event) => selectedOwner.value = $event),
          "native-token-balance": tokenBalance.value,
          "onUpdate:nativeTokenBalance": _cache[1] || (_cache[1] = ($event) => tokenBalance.value = $event),
          "native-usd-balance": usdBalance.value,
          "onUpdate:nativeUsdBalance": _cache[2] || (_cache[2] = ($event) => usdBalance.value = $event)
        }, null, 8, ["selected-owner", "native-token-balance", "native-usd-balance"]),
        createVNode(_sfc_main$10, {
          count: microchainCount.value,
          "onUpdate:count": _cache[3] || (_cache[3] = ($event) => microchainCount.value = $event)
        }, null, 8, ["count"])
      ]);
    };
  }
});
let id = 0;
const useTabEmits = ["click", "keydown"];
const useTabProps = {
  icon: String,
  label: [Number, String],
  alert: [Boolean, String],
  alertIcon: String,
  name: {
    type: [Number, String],
    default: () => `t_${id++}`
  },
  noCaps: Boolean,
  tabindex: [String, Number],
  disable: Boolean,
  contentClass: String,
  ripple: {
    type: [Boolean, Object],
    default: true
  }
};
function useTab(props, slots, emit, routeData) {
  const $tabs = inject(tabsKey, emptyRenderFn);
  if ($tabs === emptyRenderFn) {
    console.error("QTab/QRouteTab component needs to be child of QTabs");
    return emptyRenderFn;
  }
  const { proxy } = getCurrentInstance();
  const blurTargetRef = ref(null);
  const rootRef = ref(null);
  const tabIndicatorRef = ref(null);
  const ripple = computed(() => props.disable === true || props.ripple === false ? false : Object.assign(
    { keyCodes: [13, 32], early: true },
    props.ripple === true ? {} : props.ripple
  ));
  const isActive = computed(() => $tabs.currentModel.value === props.name);
  const classes = computed(
    () => "q-tab relative-position self-stretch flex flex-center text-center" + (isActive.value === true ? " q-tab--active" + ($tabs.tabProps.value.activeClass ? " " + $tabs.tabProps.value.activeClass : "") + ($tabs.tabProps.value.activeColor ? ` text-${$tabs.tabProps.value.activeColor}` : "") + ($tabs.tabProps.value.activeBgColor ? ` bg-${$tabs.tabProps.value.activeBgColor}` : "") : " q-tab--inactive") + (props.icon && props.label && $tabs.tabProps.value.inlineLabel === false ? " q-tab--full" : "") + (props.noCaps === true || $tabs.tabProps.value.noCaps === true ? " q-tab--no-caps" : "") + (props.disable === true ? " disabled" : " q-focusable q-hoverable cursor-pointer") + (routeData !== void 0 ? routeData.linkClass.value : "")
  );
  const innerClass = computed(
    () => "q-tab__content self-stretch flex-center relative-position q-anchor--skip non-selectable " + ($tabs.tabProps.value.inlineLabel === true ? "row no-wrap q-tab__content--inline" : "column") + (props.contentClass !== void 0 ? ` ${props.contentClass}` : "")
  );
  const tabIndex = computed(() => props.disable === true || $tabs.hasFocus.value === true || isActive.value === false && $tabs.hasActiveTab.value === true ? -1 : props.tabindex || 0);
  function onClick(e, keyboard) {
    if (keyboard !== true && blurTargetRef.value !== null) {
      blurTargetRef.value.focus();
    }
    if (props.disable === true) {
      if (routeData !== void 0 && routeData.hasRouterLink.value === true) {
        stopAndPrevent(e);
      }
      return;
    }
    if (routeData === void 0) {
      $tabs.updateModel({ name: props.name });
      emit("click", e);
      return;
    }
    if (routeData.hasRouterLink.value === true) {
      const go = (opts = {}) => {
        let hardError;
        const reqId = opts.to === void 0 || isDeepEqual(opts.to, props.to) === true ? $tabs.avoidRouteWatcher = uid() : null;
        return routeData.navigateToRouterLink(e, { ...opts, returnRouterError: true }).catch((err) => {
          hardError = err;
        }).then((softError) => {
          if (reqId === $tabs.avoidRouteWatcher) {
            $tabs.avoidRouteWatcher = false;
            if (hardError === void 0 && (softError === void 0 || softError.message !== void 0 && softError.message.startsWith("Avoided redundant navigation") === true)) {
              $tabs.updateModel({ name: props.name });
            }
          }
          if (opts.returnRouterError === true) {
            return hardError !== void 0 ? Promise.reject(hardError) : softError;
          }
        });
      };
      emit("click", e, go);
      e.defaultPrevented !== true && go();
      return;
    }
    emit("click", e);
  }
  function onKeydown(e) {
    if (isKeyCode(e, [13, 32])) {
      onClick(e, true);
    } else if (shouldIgnoreKey(e) !== true && e.keyCode >= 35 && e.keyCode <= 40 && e.altKey !== true && e.metaKey !== true) {
      $tabs.onKbdNavigate(e.keyCode, proxy.$el) === true && stopAndPrevent(e);
    }
    emit("keydown", e);
  }
  function getContent() {
    const narrow = $tabs.tabProps.value.narrowIndicator, content = [], indicator = h("div", {
      ref: tabIndicatorRef,
      class: [
        "q-tab__indicator",
        $tabs.tabProps.value.indicatorClass
      ]
    });
    props.icon !== void 0 && content.push(
      h(QIcon, {
        class: "q-tab__icon",
        name: props.icon
      })
    );
    props.label !== void 0 && content.push(
      h("div", { class: "q-tab__label" }, props.label)
    );
    props.alert !== false && content.push(
      props.alertIcon !== void 0 ? h(QIcon, {
        class: "q-tab__alert-icon",
        color: props.alert !== true ? props.alert : void 0,
        name: props.alertIcon
      }) : h("div", {
        class: "q-tab__alert" + (props.alert !== true ? ` text-${props.alert}` : "")
      })
    );
    narrow === true && content.push(indicator);
    const node = [
      h("div", { class: "q-focus-helper", tabindex: -1, ref: blurTargetRef }),
      h("div", { class: innerClass.value }, hMergeSlot(slots.default, content))
    ];
    narrow === false && node.push(indicator);
    return node;
  }
  const tabData = {
    name: computed(() => props.name),
    rootRef,
    tabIndicatorRef,
    routeData
  };
  onBeforeUnmount(() => {
    $tabs.unregisterTab(tabData);
  });
  onMounted(() => {
    $tabs.registerTab(tabData);
  });
  function renderTab(tag, customData) {
    const data = {
      ref: rootRef,
      class: classes.value,
      tabindex: tabIndex.value,
      role: "tab",
      "aria-selected": isActive.value === true ? "true" : "false",
      "aria-disabled": props.disable === true ? "true" : void 0,
      onClick,
      onKeydown,
      ...customData
    };
    return withDirectives(
      h(tag, data, getContent()),
      [[Ripple, ripple.value]]
    );
  }
  return { renderTab, $tabs };
}
var QTab = createComponent({
  name: "QTab",
  props: useTabProps,
  emits: useTabEmits,
  setup(props, { slots, emit }) {
    const { renderTab } = useTab(props, slots, emit);
    return () => renderTab("div");
  }
});
let rtlHasScrollBug = false;
{
  const scroller = document.createElement("div");
  scroller.setAttribute("dir", "rtl");
  Object.assign(scroller.style, {
    width: "1px",
    height: "1px",
    overflow: "auto"
  });
  const spacer = document.createElement("div");
  Object.assign(spacer.style, {
    width: "1000px",
    height: "1px"
  });
  document.body.appendChild(scroller);
  scroller.appendChild(spacer);
  scroller.scrollLeft = -1e3;
  rtlHasScrollBug = scroller.scrollLeft >= 0;
  scroller.remove();
}
function getIndicatorClass(color, top, vertical) {
  const pos = vertical === true ? ["left", "right"] : ["top", "bottom"];
  return `absolute-${top === true ? pos[0] : pos[1]}${color ? ` text-${color}` : ""}`;
}
const alignValues = ["left", "center", "right", "justify"];
var QTabs = createComponent({
  name: "QTabs",
  props: {
    modelValue: [Number, String],
    align: {
      type: String,
      default: "center",
      validator: (v) => alignValues.includes(v)
    },
    breakpoint: {
      type: [String, Number],
      default: 600
    },
    vertical: Boolean,
    shrink: Boolean,
    stretch: Boolean,
    activeClass: String,
    activeColor: String,
    activeBgColor: String,
    indicatorColor: String,
    leftIcon: String,
    rightIcon: String,
    outsideArrows: Boolean,
    mobileArrows: Boolean,
    switchIndicator: Boolean,
    narrowIndicator: Boolean,
    inlineLabel: Boolean,
    noCaps: Boolean,
    dense: Boolean,
    contentClass: String,
    "onUpdate:modelValue": [Function, Array]
  },
  setup(props, { slots, emit }) {
    const { proxy } = getCurrentInstance();
    const { $q } = proxy;
    const { registerTick: registerScrollTick } = useTick();
    const { registerTick: registerUpdateArrowsTick } = useTick();
    const { registerTick: registerAnimateTick } = useTick();
    const { registerTimeout: registerFocusTimeout, removeTimeout: removeFocusTimeout } = useTimeout();
    const { registerTimeout: registerScrollToTabTimeout, removeTimeout: removeScrollToTabTimeout } = useTimeout();
    const rootRef = ref(null);
    const contentRef = ref(null);
    const currentModel = ref(props.modelValue);
    const scrollable = ref(false);
    const leftArrow = ref(true);
    const rightArrow = ref(false);
    const justify = ref(false);
    const tabDataList = [];
    const tabDataListLen = ref(0);
    const hasFocus = ref(false);
    let animateTimer = null, scrollTimer = null, unwatchRoute;
    const tabProps = computed(() => ({
      activeClass: props.activeClass,
      activeColor: props.activeColor,
      activeBgColor: props.activeBgColor,
      indicatorClass: getIndicatorClass(
        props.indicatorColor,
        props.switchIndicator,
        props.vertical
      ),
      narrowIndicator: props.narrowIndicator,
      inlineLabel: props.inlineLabel,
      noCaps: props.noCaps
    }));
    const hasActiveTab = computed(() => {
      const len = tabDataListLen.value;
      const val = currentModel.value;
      for (let i = 0; i < len; i++) {
        if (tabDataList[i].name.value === val) {
          return true;
        }
      }
      return false;
    });
    const alignClass = computed(() => {
      const align = scrollable.value === true ? "left" : justify.value === true ? "justify" : props.align;
      return `q-tabs__content--align-${align}`;
    });
    const classes = computed(
      () => `q-tabs row no-wrap items-center q-tabs--${scrollable.value === true ? "" : "not-"}scrollable q-tabs--${props.vertical === true ? "vertical" : "horizontal"} q-tabs__arrows--${props.outsideArrows === true ? "outside" : "inside"} q-tabs--mobile-with${props.mobileArrows === true ? "" : "out"}-arrows` + (props.dense === true ? " q-tabs--dense" : "") + (props.shrink === true ? " col-shrink" : "") + (props.stretch === true ? " self-stretch" : "")
    );
    const innerClass = computed(
      () => "q-tabs__content scroll--mobile row no-wrap items-center self-stretch hide-scrollbar relative-position " + alignClass.value + (props.contentClass !== void 0 ? ` ${props.contentClass}` : "")
    );
    const domProps = computed(() => props.vertical === true ? { container: "height", content: "offsetHeight", scroll: "scrollHeight" } : { container: "width", content: "offsetWidth", scroll: "scrollWidth" });
    const isRTL = computed(() => props.vertical !== true && $q.lang.rtl === true);
    const rtlPosCorrection = computed(() => rtlHasScrollBug === false && isRTL.value === true);
    watch(isRTL, updateArrows);
    watch(() => props.modelValue, (name) => {
      updateModel({ name, setCurrent: true, skipEmit: true });
    });
    watch(() => props.outsideArrows, recalculateScroll);
    function updateModel({ name, setCurrent, skipEmit }) {
      if (currentModel.value === name)
        return;
      if (skipEmit !== true && props["onUpdate:modelValue"] !== void 0) {
        emit("update:modelValue", name);
      }
      if (setCurrent === true || props["onUpdate:modelValue"] === void 0) {
        animate(currentModel.value, name);
        currentModel.value = name;
      }
    }
    function recalculateScroll() {
      registerScrollTick(() => {
        updateContainer({
          width: rootRef.value.offsetWidth,
          height: rootRef.value.offsetHeight
        });
      });
    }
    function updateContainer(domSize) {
      if (domProps.value === void 0 || contentRef.value === null)
        return;
      const size = domSize[domProps.value.container], scrollSize = Math.min(
        contentRef.value[domProps.value.scroll],
        Array.prototype.reduce.call(
          contentRef.value.children,
          (acc, el) => acc + (el[domProps.value.content] || 0),
          0
        )
      ), scroll = size > 0 && scrollSize > size;
      scrollable.value = scroll;
      scroll === true && registerUpdateArrowsTick(updateArrows);
      justify.value = size < parseInt(props.breakpoint, 10);
    }
    function animate(oldName, newName) {
      const oldTab = oldName !== void 0 && oldName !== null && oldName !== "" ? tabDataList.find((tab) => tab.name.value === oldName) : null, newTab = newName !== void 0 && newName !== null && newName !== "" ? tabDataList.find((tab) => tab.name.value === newName) : null;
      if (hadActivated === true) {
        hadActivated = false;
      } else if (oldTab && newTab) {
        const oldEl = oldTab.tabIndicatorRef.value, newEl = newTab.tabIndicatorRef.value;
        if (animateTimer !== null) {
          clearTimeout(animateTimer);
          animateTimer = null;
        }
        oldEl.style.transition = "none";
        oldEl.style.transform = "none";
        newEl.style.transition = "none";
        newEl.style.transform = "none";
        const oldPos = oldEl.getBoundingClientRect(), newPos = newEl.getBoundingClientRect();
        newEl.style.transform = props.vertical === true ? `translate3d(0,${oldPos.top - newPos.top}px,0) scale3d(1,${newPos.height ? oldPos.height / newPos.height : 1},1)` : `translate3d(${oldPos.left - newPos.left}px,0,0) scale3d(${newPos.width ? oldPos.width / newPos.width : 1},1,1)`;
        registerAnimateTick(() => {
          animateTimer = setTimeout(() => {
            animateTimer = null;
            newEl.style.transition = "transform .25s cubic-bezier(.4, 0, .2, 1)";
            newEl.style.transform = "none";
          }, 70);
        });
      }
      if (newTab && scrollable.value === true) {
        scrollToTabEl(newTab.rootRef.value);
      }
    }
    function scrollToTabEl(el) {
      const { left, width, top, height } = contentRef.value.getBoundingClientRect(), newPos = el.getBoundingClientRect();
      let offset = props.vertical === true ? newPos.top - top : newPos.left - left;
      if (offset < 0) {
        contentRef.value[props.vertical === true ? "scrollTop" : "scrollLeft"] += Math.floor(offset);
        updateArrows();
        return;
      }
      offset += props.vertical === true ? newPos.height - height : newPos.width - width;
      if (offset > 0) {
        contentRef.value[props.vertical === true ? "scrollTop" : "scrollLeft"] += Math.ceil(offset);
        updateArrows();
      }
    }
    function updateArrows() {
      const content = contentRef.value;
      if (content === null)
        return;
      const rect = content.getBoundingClientRect(), pos = props.vertical === true ? content.scrollTop : Math.abs(content.scrollLeft);
      if (isRTL.value === true) {
        leftArrow.value = Math.ceil(pos + rect.width) < content.scrollWidth - 1;
        rightArrow.value = pos > 0;
      } else {
        leftArrow.value = pos > 0;
        rightArrow.value = props.vertical === true ? Math.ceil(pos + rect.height) < content.scrollHeight : Math.ceil(pos + rect.width) < content.scrollWidth;
      }
    }
    function animScrollTo(value) {
      scrollTimer !== null && clearInterval(scrollTimer);
      scrollTimer = setInterval(() => {
        if (scrollTowards(value) === true) {
          stopAnimScroll();
        }
      }, 5);
    }
    function scrollToStart() {
      animScrollTo(rtlPosCorrection.value === true ? Number.MAX_SAFE_INTEGER : 0);
    }
    function scrollToEnd() {
      animScrollTo(rtlPosCorrection.value === true ? 0 : Number.MAX_SAFE_INTEGER);
    }
    function stopAnimScroll() {
      if (scrollTimer !== null) {
        clearInterval(scrollTimer);
        scrollTimer = null;
      }
    }
    function onKbdNavigate(keyCode, fromEl) {
      const tabs = Array.prototype.filter.call(
        contentRef.value.children,
        (el) => el === fromEl || el.matches && el.matches(".q-tab.q-focusable") === true
      );
      const len = tabs.length;
      if (len === 0)
        return;
      if (keyCode === 36) {
        scrollToTabEl(tabs[0]);
        tabs[0].focus();
        return true;
      }
      if (keyCode === 35) {
        scrollToTabEl(tabs[len - 1]);
        tabs[len - 1].focus();
        return true;
      }
      const dirPrev = keyCode === (props.vertical === true ? 38 : 37);
      const dirNext = keyCode === (props.vertical === true ? 40 : 39);
      const dir = dirPrev === true ? -1 : dirNext === true ? 1 : void 0;
      if (dir !== void 0) {
        const rtlDir = isRTL.value === true ? -1 : 1;
        const index = tabs.indexOf(fromEl) + dir * rtlDir;
        if (index >= 0 && index < len) {
          scrollToTabEl(tabs[index]);
          tabs[index].focus({ preventScroll: true });
        }
        return true;
      }
    }
    const posFn = computed(() => rtlPosCorrection.value === true ? { get: (content) => Math.abs(content.scrollLeft), set: (content, pos) => {
      content.scrollLeft = -pos;
    } } : props.vertical === true ? { get: (content) => content.scrollTop, set: (content, pos) => {
      content.scrollTop = pos;
    } } : { get: (content) => content.scrollLeft, set: (content, pos) => {
      content.scrollLeft = pos;
    } });
    function scrollTowards(value) {
      const content = contentRef.value, { get, set } = posFn.value;
      let done = false, pos = get(content);
      const direction = value < pos ? -1 : 1;
      pos += direction * 5;
      if (pos < 0) {
        done = true;
        pos = 0;
      } else if (direction === -1 && pos <= value || direction === 1 && pos >= value) {
        done = true;
        pos = value;
      }
      set(content, pos);
      updateArrows();
      return done;
    }
    function hasQueryIncluded(targetQuery, matchingQuery) {
      for (const key in targetQuery) {
        if (targetQuery[key] !== matchingQuery[key]) {
          return false;
        }
      }
      return true;
    }
    function updateActiveRoute() {
      let name = null, bestScore = { matchedLen: 0, queryDiff: 9999, hrefLen: 0 };
      const list = tabDataList.filter((tab) => tab.routeData !== void 0 && tab.routeData.hasRouterLink.value === true);
      const { hash: currentHash, query: currentQuery } = proxy.$route;
      const currentQueryLen = Object.keys(currentQuery).length;
      for (const tab of list) {
        const exact = tab.routeData.exact.value === true;
        if (tab.routeData[exact === true ? "linkIsExactActive" : "linkIsActive"].value !== true) {
          continue;
        }
        const { hash, query, matched, href } = tab.routeData.resolvedLink.value;
        const queryLen = Object.keys(query).length;
        if (exact === true) {
          if (hash !== currentHash) {
            continue;
          }
          if (queryLen !== currentQueryLen || hasQueryIncluded(currentQuery, query) === false) {
            continue;
          }
          name = tab.name.value;
          break;
        }
        if (hash !== "" && hash !== currentHash) {
          continue;
        }
        if (queryLen !== 0 && hasQueryIncluded(query, currentQuery) === false) {
          continue;
        }
        const newScore = {
          matchedLen: matched.length,
          queryDiff: currentQueryLen - queryLen,
          hrefLen: href.length - hash.length
        };
        if (newScore.matchedLen > bestScore.matchedLen) {
          name = tab.name.value;
          bestScore = newScore;
          continue;
        } else if (newScore.matchedLen !== bestScore.matchedLen) {
          continue;
        }
        if (newScore.queryDiff < bestScore.queryDiff) {
          name = tab.name.value;
          bestScore = newScore;
        } else if (newScore.queryDiff !== bestScore.queryDiff) {
          continue;
        }
        if (newScore.hrefLen > bestScore.hrefLen) {
          name = tab.name.value;
          bestScore = newScore;
        }
      }
      if (name === null && tabDataList.some((tab) => tab.routeData === void 0 && tab.name.value === currentModel.value) === true) {
        hadActivated = false;
        return;
      }
      updateModel({ name, setCurrent: true });
    }
    function onFocusin(e) {
      removeFocusTimeout();
      if (hasFocus.value !== true && rootRef.value !== null && e.target && typeof e.target.closest === "function") {
        const tab = e.target.closest(".q-tab");
        if (tab && rootRef.value.contains(tab) === true) {
          hasFocus.value = true;
          scrollable.value === true && scrollToTabEl(tab);
        }
      }
    }
    function onFocusout() {
      registerFocusTimeout(() => {
        hasFocus.value = false;
      }, 30);
    }
    function verifyRouteModel() {
      if ($tabs.avoidRouteWatcher === false) {
        registerScrollToTabTimeout(updateActiveRoute);
      } else {
        removeScrollToTabTimeout();
      }
    }
    function watchRoute() {
      if (unwatchRoute === void 0) {
        const unwatch = watch(() => proxy.$route.fullPath, verifyRouteModel);
        unwatchRoute = () => {
          unwatch();
          unwatchRoute = void 0;
        };
      }
    }
    function registerTab(tabData) {
      tabDataList.push(tabData);
      tabDataListLen.value++;
      recalculateScroll();
      if (tabData.routeData === void 0 || proxy.$route === void 0) {
        registerScrollToTabTimeout(() => {
          if (scrollable.value === true) {
            const value = currentModel.value;
            const newTab = value !== void 0 && value !== null && value !== "" ? tabDataList.find((tab) => tab.name.value === value) : null;
            newTab && scrollToTabEl(newTab.rootRef.value);
          }
        });
      } else {
        watchRoute();
        if (tabData.routeData.hasRouterLink.value === true) {
          verifyRouteModel();
        }
      }
    }
    function unregisterTab(tabData) {
      tabDataList.splice(tabDataList.indexOf(tabData), 1);
      tabDataListLen.value--;
      recalculateScroll();
      if (unwatchRoute !== void 0 && tabData.routeData !== void 0) {
        if (tabDataList.every((tab) => tab.routeData === void 0) === true) {
          unwatchRoute();
        }
        verifyRouteModel();
      }
    }
    const $tabs = {
      currentModel,
      tabProps,
      hasFocus,
      hasActiveTab,
      registerTab,
      unregisterTab,
      verifyRouteModel,
      updateModel,
      onKbdNavigate,
      avoidRouteWatcher: false
    };
    provide(tabsKey, $tabs);
    function cleanup() {
      animateTimer !== null && clearTimeout(animateTimer);
      stopAnimScroll();
      unwatchRoute !== void 0 && unwatchRoute();
    }
    let hadRouteWatcher, hadActivated;
    onBeforeUnmount(cleanup);
    onDeactivated(() => {
      hadRouteWatcher = unwatchRoute !== void 0;
      cleanup();
    });
    onActivated(() => {
      if (hadRouteWatcher === true) {
        watchRoute();
        hadActivated = true;
        verifyRouteModel();
      }
      recalculateScroll();
    });
    return () => {
      return h("div", {
        ref: rootRef,
        class: classes.value,
        role: "tablist",
        onFocusin,
        onFocusout
      }, [
        h(QResizeObserver, { onResize: updateContainer }),
        h("div", {
          ref: contentRef,
          class: innerClass.value,
          onScroll: updateArrows
        }, hSlot(slots.default)),
        h(QIcon, {
          class: "q-tabs__arrow q-tabs__arrow--left absolute q-tab__icon" + (leftArrow.value === true ? "" : " q-tabs__arrow--faded"),
          name: props.leftIcon || $q.iconSet.tabs[props.vertical === true ? "up" : "left"],
          onMousedownPassive: scrollToStart,
          onTouchstartPassive: scrollToStart,
          onMouseupPassive: stopAnimScroll,
          onMouseleavePassive: stopAnimScroll,
          onTouchendPassive: stopAnimScroll
        }),
        h(QIcon, {
          class: "q-tabs__arrow q-tabs__arrow--right absolute q-tab__icon" + (rightArrow.value === true ? "" : " q-tabs__arrow--faded"),
          name: props.rightIcon || $q.iconSet.tabs[props.vertical === true ? "down" : "right"],
          onMousedownPassive: scrollToEnd,
          onTouchstartPassive: scrollToEnd,
          onMouseupPassive: stopAnimScroll,
          onMouseleavePassive: stopAnimScroll,
          onTouchendPassive: stopAnimScroll
        })
      ]);
    };
  }
});
var QTabPanel = createComponent({
  name: "QTabPanel",
  props: usePanelChildProps,
  setup(_, { slots }) {
    return () => h("div", { class: "q-tab-panel", role: "tabpanel" }, hSlot(slots.default));
  }
});
var QTabPanels = createComponent({
  name: "QTabPanels",
  props: {
    ...usePanelProps,
    ...useDarkProps
  },
  emits: usePanelEmits,
  setup(props, { slots }) {
    const vm = getCurrentInstance();
    const isDark = useDark(props, vm.proxy.$q);
    const { updatePanelsList, getPanelContent, panelDirectives } = usePanel();
    const classes = computed(
      () => "q-tab-panels q-panel-parent" + (isDark.value === true ? " q-tab-panels--dark q-dark" : "")
    );
    return () => {
      updatePanelsList(slots);
      return hDir(
        "div",
        { class: classes.value },
        getPanelContent(),
        "pan",
        props.swipeable,
        () => panelDirectives.value
      );
    };
  }
});
const _hoisted_1$C = { class: "page-x-padding" };
const _hoisted_2$z = { class: "text-bold vertical-sections-margin" };
const _hoisted_3$v = { class: "vertical-sections-margin tip warn-bg warn row" };
const _hoisted_4$r = { class: "tip-text page-item-x-margin-left" };
const _sfc_main$M = defineComponent({
  __name: "ImportTokenView",
  emits: ["imported", "error", "canceled"],
  setup(__props, { emit: __emit }) {
    const applicationId = ref("");
    const applicationIdError = ref(false);
    const importing = ref(false);
    const canImport = computed(() => {
      return applicationId.value.length > 0;
    });
    const emit = __emit;
    const onImportClick = async () => {
      applicationIdError.value = applicationId.value.length === 0;
      if (applicationIdError.value)
        return;
      importing.value = true;
      localStore.setting.TokensImportState = localStore.settingDef.TokensImportState.TokensImporting;
      try {
        await MemeApplicationOperation.persistApplication(applicationId.value);
      } catch (e) {
        console.log(`Failed import erc20 application: ${e}`);
      }
      importing.value = false;
      localStore.setting.TokensImportState = localStore.settingDef.TokensImportState.TokensImported;
      emit("imported");
    };
    const onCancelClick = () => {
      emit("canceled");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$C, [
        createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_CAN_IMPORT_ERC20_COMPATIBLE_TOKEN")), 1),
        createBaseVNode("div", _hoisted_2$z, toDisplayString(_ctx.$t("MSG_APPLICATION_ID")), 1),
        createVNode(QInput, {
          outlined: "",
          modelValue: applicationId.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => applicationId.value = $event),
          type: "textarea",
          error: applicationIdError.value,
          autogrow: "",
          "hide-bottom-space": "",
          class: "vertical-items-margin"
        }, null, 8, ["modelValue", "error"]),
        createBaseVNode("div", _hoisted_3$v, [
          createVNode(QIcon, {
            name: "bi-exclamation-triangle-fill",
            color: "red-8",
            size: "24px"
          }),
          createBaseVNode("div", _hoisted_4$r, toDisplayString(_ctx.$t("MSG_SHOULD_CONFIRM_IMPORT_RIGHT_APPLICATION")), 1)
        ]),
        createVNode(QBtn, {
          class: "btn vertical-sections-margin full-width",
          flat: "",
          "no-caps": "",
          onClick: onImportClick,
          disabled: !canImport.value,
          loading: importing.value
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_IMPORT")), 1)
          ]),
          _: 1
        }, 8, ["disabled", "loading"]),
        createVNode(QBtn, {
          class: "btn btn-alt vertical-items-margin extra-margin-bottom full-width",
          flat: "",
          "no-caps": "",
          onClick: onCancelClick
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_CANCEL")), 1)
          ]),
          _: 1
        })
      ]);
    };
  }
});
const _hoisted_1$B = { class: "fill-parent text-center" };
const _hoisted_2$y = { key: 0 };
const _hoisted_3$u = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_4$q = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_5$o = { class: "onboarding-page-title text-center page-title" };
const _sfc_main$L = defineComponent({
  __name: "TokensView",
  setup(__props) {
    const tokens = ref([]);
    const count = ref(0);
    const selectedOwner = ref(void 0);
    const displayingAccount = ref(false);
    const importingToken = ref(false);
    const onTokenImported = () => {
      importingToken.value = false;
    };
    const onImportTokenError = () => {
      importingToken.value = false;
    };
    const onImportTokenCanceled = () => {
      importingToken.value = false;
    };
    const onImportTokenClick = () => {
      importingToken.value = true;
    };
    const onReceiveTokensClick = () => {
      displayingAccount.value = true;
    };
    const onDisplayAccountCanceled = () => {
      displayingAccount.value = false;
    };
    const onDisplayAccountDone = () => {
      displayingAccount.value = false;
    };
    const onTokenClick = (token2) => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_TOKEN;
      localStore.setting.HomeActionParams = token2;
    };
    const loadTokensRecursive = async (total, offset, limit, _tokens) => {
      if (offset >= total) {
        tokens.value = _tokens;
        return;
      }
      _tokens.push(...await Token.tokens(offset, limit));
      void loadTokensRecursive(total, offset + limit, limit, _tokens);
    };
    const loadTokens = async () => {
      const count2 = await Token.count();
      await loadTokensRecursive(count2, 0, 10, []);
    };
    watch(count, async () => {
      await loadTokens();
    });
    onMounted(() => {
      void loadTokens();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$B, [
          createVNode(QSpace),
          createBaseVNode("div", null, [
            tokens.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_2$y, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(tokens.value, (token2) => {
                return openBlock(), createBlock(_sfc_main$11, {
                  key: token2.id,
                  token: token2,
                  onClick: ($event) => onTokenClick(token2)
                }, null, 8, ["token", "onClick"]);
              }), 128))
            ])) : createCommentVNode("", true),
            createBaseVNode("div", {
              class: "row vertical-sections-margin selector-margin-x-left cursor-pointer",
              onClick: onReceiveTokensClick
            }, [
              createVNode(QIcon, {
                name: "bi-plus-lg",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_3$u, toDisplayString(_ctx.$t("MSG_RECEIVE_TOKENS")), 1)
            ]),
            createBaseVNode("div", {
              class: "row vertical-items-margin selector-margin-x-left cursor-pointer",
              onClick: onImportTokenClick
            }, [
              createVNode(QIcon, {
                name: "bi-plus-lg",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_4$q, toDisplayString(_ctx.$t("MSG_IMPORT_TOKEN")), 1)
            ])
          ]),
          createVNode(QSpace)
        ]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[0] || (_cache[0] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        createVNode(_sfc_main$_, {
          count: count.value,
          "onUpdate:count": _cache[1] || (_cache[1] = ($event) => count.value = $event)
        }, null, 8, ["count"]),
        createVNode(QDialog, {
          modelValue: importingToken.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => importingToken.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(QCard, { class: "dialog page-y-padding" }, {
              default: withCtx(() => [
                createBaseVNode("h5", _hoisted_5$o, toDisplayString(_ctx.$t("MSG_IMPORT_ERC20_COMPATIBLE_TOKEN")), 1),
                createVNode(_sfc_main$M, {
                  onImported: onTokenImported,
                  onError: onImportTokenError,
                  onCanceled: onImportTokenCanceled
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: displayingAccount.value,
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => displayingAccount.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$Q, {
              owner: selectedOwner.value,
              onCanceled: onDisplayAccountCanceled,
              onDone: onDisplayAccountDone
            }, null, 8, ["owner"])
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 64);
    };
  }
});
const _hoisted_1$A = ["innerHTML"];
const _hoisted_2$x = { class: "text-bold vertical-sections-margin decorate-underline" };
const _hoisted_3$t = { class: "word-break-all vertical-items-margin cursor-pointer" };
const _hoisted_4$p = { class: "cursor-pointer" };
const _hoisted_5$n = { class: "text-bold vertical-sections-margin decorate-underline" };
const _hoisted_6$h = { class: "word-break-all vertical-items-margin cursor-pointer" };
const _hoisted_7$e = { class: "cursor-pointer" };
const _hoisted_8$e = { class: "row vertical-sections-margin tip warn" };
const _hoisted_9$d = {
  style: { width: "calc(100% - 20px)" },
  class: "page-item-x-margin-left"
};
const _hoisted_10$a = ["innerHTML"];
const _sfc_main$K = defineComponent({
  __name: "MicrochainCreationView",
  props: {
    microchain: {}
  },
  emits: ["backuped"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const { t } = useI18n({ useScope: "global" });
    const emit = __emit;
    const onValidateClick = () => {
      emit("backuped");
    };
    const onBackupClick = () => {
      copyToClipboard(JSON.stringify(microchain.value)).then(() => {
        localStore.notification.pushNotification({
          Title: t("MSG_COPY_MICROCHAIN"),
          Message: t("MSG_SUCCESS_COPY_MICROCHAIN_CREATION_INFORMATION"),
          Popup: true,
          Type: localStore.notify.NotifyType.Info
        });
      }).catch((e) => {
        console.log("Fail copy microchain creation information", e);
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          innerHTML: _ctx.$t("MSG_PLEASE_BACKUP_MICROCHAIN_CREATION_MATERIALS")
        }, null, 8, _hoisted_1$A),
        createBaseVNode("div", _hoisted_2$x, toDisplayString(_ctx.$t("MSG_MICROCHAIN_ID")), 1),
        createBaseVNode("div", _hoisted_3$t, [
          createTextVNode(toDisplayString(microchain.value.microchain) + " ", 1),
          createBaseVNode("span", _hoisted_4$p, [
            createVNode(QIcon, {
              name: "bi-copy",
              size: "12px",
              onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(microchain.value.microchain, evt), ["stop"]))
            })
          ])
        ]),
        createBaseVNode("div", _hoisted_5$n, toDisplayString(_ctx.$t("MSG_CREATOR_CHAIN_ID")), 1),
        createBaseVNode("div", _hoisted_6$h, [
          createTextVNode(toDisplayString(microchain.value.creatorChainId) + " ", 1),
          createBaseVNode("span", _hoisted_7$e, [
            createVNode(QIcon, {
              name: "bi-copy",
              size: "12px",
              onClick: _cache[1] || (_cache[1] = withModifiers((evt) => unref(_copyToClipboard)(microchain.value.creatorChainId, evt), ["stop"]))
            })
          ])
        ]),
        createBaseVNode("div", _hoisted_8$e, [
          createVNode(QIcon, {
            name: "bi-exclamation-circle",
            color: "red-6",
            style: { marginTop: "4px" }
          }),
          createBaseVNode("div", _hoisted_9$d, [
            createBaseVNode("span", {
              innerHTML: _ctx.$t("MSG_YOU_MUST_BACKUP_MICROCHAIN_MATERIALS")
            }, null, 8, _hoisted_10$a),
            createBaseVNode("span", {
              class: "text-blue-8 cursor-pointer page-item-x-margin-left",
              onClick: onBackupClick
            }, toDisplayString(_ctx.$t("MSG_BACKUP")), 1)
          ])
        ]),
        createVNode(QBtn, {
          class: "btn vertical-sections-margin extra-margin-bottom full-width",
          flat: "",
          "no-caps": "",
          onClick: onValidateClick
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_VALIDATE_MICROCHAIN")), 1)
          ]),
          _: 1
        })
      ]);
    };
  }
});
const _hoisted_1$z = { class: "full-width" };
const _hoisted_2$w = ["innerHTML"];
const _hoisted_3$s = { class: "vertical-sections-margin tip info" };
const _hoisted_4$o = { class: "text-bold vertical-sections-margin" };
const _sfc_main$J = defineComponent({
  __name: "ValidateMicrochainView",
  props: {
    microchain: {}
  },
  emits: ["validated"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const microchainId = ref("");
    const microchainIdError = ref(false);
    const emit = __emit;
    const canValidate = computed(() => {
      return microchainId.value === microchain.value.microchain;
    });
    const onValidateClick = () => {
      microchainIdError.value = microchainId.value !== microchain.value.microchain;
      if (microchainIdError.value)
        return;
      emit("validated");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$z, [
        createBaseVNode("div", {
          innerHTML: _ctx.$t("MSG_CHECKO_NEEDS_TO_KNOW_MICROCHAIN_CREATION_MATERIAL_FOR_RECOVERY")
        }, null, 8, _hoisted_2$w),
        createBaseVNode("div", _hoisted_3$s, [
          createVNode(QIcon, {
            name: "bi-check-circle",
            color: "green-6",
            style: { marginBottom: "4px" }
          }),
          createTextVNode(" " + toDisplayString(_ctx.$t("MSG_PASTE_MICROCHAIN_CREATION_INFORMATION_TO_VERIFY")), 1)
        ]),
        createBaseVNode("div", _hoisted_4$o, toDisplayString(_ctx.$t("MSG_MICROCHAIN_ID")), 1),
        createVNode(QInput, {
          outlined: "",
          modelValue: microchainId.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => microchainId.value = $event),
          type: "textarea",
          error: microchainIdError.value,
          autogrow: "",
          "hide-bottom-space": "",
          class: "vertical-items-margin"
        }, null, 8, ["modelValue", "error"]),
        createVNode(QBtn, {
          class: "btn vertical-sections-margin extra-margin-bottom full-width",
          flat: "",
          "no-caps": "",
          onClick: onValidateClick,
          disabled: !canValidate.value
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_LETS_GO")), 1)
          ]),
          _: 1
        }, 8, ["disabled"])
      ]);
    };
  }
});
const _hoisted_1$y = { class: "full-width" };
const _sfc_main$I = defineComponent({
  __name: "CreateMicrochainView",
  emits: ["created", "error"],
  setup(__props, { emit: __emit }) {
    const { t } = useI18n({ useScope: "global" });
    const createdMicrochain = ref(void 0);
    const step = ref(1);
    const emit = __emit;
    const createMicrochain = async () => {
      return new Promise((resolve, reject) => {
        Microchain.openMicrochain().then((microchain) => {
          localStore.notification.pushNotification({
            Title: t("MSG_OPEN_CHAIN"),
            Message: t("MSG_SUCCESS_OPEN_MICROCHAIN"),
            Popup: true,
            Type: localStore.notify.NotifyType.Info
          });
          resolve(microchain);
        }).catch((error) => {
          localStore.notification.pushNotification({
            Title: t("MSG_OPEN_CHAIN"),
            Message: t("MSG_FAILED_OPEN_MICROCHAIN", { ERROR: error }),
            Popup: true,
            Type: localStore.notify.NotifyType.Error
          });
          reject(error);
        });
      });
    };
    onMounted(() => {
      createMicrochain().then((microchain) => {
        createdMicrochain.value = microchain;
        step.value++;
      }).catch((e) => {
        console.log("Failed create microchain", e);
        emit("error");
      });
    });
    const onMicrochainBackuped = () => {
      step.value++;
    };
    const onMicrochainValidated = () => {
      emit("created", createdMicrochain.value);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$y, [
        createVNode(QStepper, {
          flat: "",
          modelValue: step.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => step.value = $event),
          animated: "",
          "alternative-labels": "",
          "header-class": "hide",
          style: { marginTop: "-16px" }
        }, {
          default: withCtx(() => [
            createVNode(QStep, {
              name: 1,
              done: step.value > 1,
              title: "Creating",
              class: "flex items-center justify-center"
            }, {
              default: withCtx(() => [
                createVNode(QCard, {
                  flat: "",
                  class: "loading-card"
                }, {
                  default: withCtx(() => [
                    createVNode(QInnerLoading, {
                      showing: createdMicrochain.value === void 0,
                      class: "text-red-4"
                    }, {
                      default: withCtx(() => [
                        createVNode(QSpinnerFacebook, { size: "80px" })
                      ]),
                      _: 1
                    }, 8, ["showing"])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 8, ["done"]),
            createVNode(QStep, {
              name: 2,
              done: step.value > 2,
              title: "Backup"
            }, {
              default: withCtx(() => [
                createVNode(_sfc_main$K, {
                  microchain: createdMicrochain.value,
                  onBackuped: onMicrochainBackuped
                }, null, 8, ["microchain"])
              ]),
              _: 1
            }, 8, ["done"]),
            createVNode(QStep, {
              name: 3,
              done: step.value > 3,
              title: "Validate"
            }, {
              default: withCtx(() => [
                createVNode(_sfc_main$J, {
                  microchain: createdMicrochain.value,
                  onValidated: onMicrochainValidated
                }, null, 8, ["microchain"])
              ]),
              _: 1
            }, 8, ["done"])
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
});
const _hoisted_1$x = { class: "full-width" };
const _hoisted_2$v = ["innerHTML"];
const _hoisted_3$r = { class: "vertical-sections-margin tip info" };
const _hoisted_4$n = { class: "text-bold vertical-sections-margin" };
const _hoisted_5$m = { class: "text-bold vertical-menus-margin" };
const _hoisted_6$g = { class: "text-bold vertical-menus-margin" };
const _sfc_main$H = defineComponent({
  __name: "ImportMicrochainView",
  emits: ["imported", "error", "canceled"],
  setup(__props, { emit: __emit }) {
    const { t } = useI18n({ useScope: "global" });
    const microchainId = ref("");
    const messageId = ref("");
    const certificateHash = ref("");
    const importing = ref(false);
    const microchainIdError = ref(false);
    const messageIdError = ref(false);
    const certificateHashError = ref(false);
    const emit = __emit;
    const canImport = computed(() => {
      return microchainId.value.length > 0 && messageId.value.length > 0 && certificateHash.value.length > 0;
    });
    const onImportClick = () => {
      microchainIdError.value = microchainId.value.length === 0;
      messageIdError.value = messageId.value.length === 0;
      certificateHashError.value = certificateHash.value.length === 0;
      if (microchainIdError.value || messageIdError.value || certificateHashError.value)
        return;
      importing.value = true;
      Microchain.importMicrochain(microchainId.value, messageId.value, certificateHash.value).then(() => {
        importing.value = false;
        localStore.notification.pushNotification({
          Title: t("MSG_IMPORT_MICROCHAIN"),
          Message: t("MSG_SUCCESS_IMPORT_MICROCHAIN"),
          Popup: true,
          Type: localStore.notify.NotifyType.Info
        });
        emit("imported", microchainId.value);
      }).catch((error) => {
        importing.value = false;
        localStore.notification.pushNotification({
          Title: t("MSG_IMPORT_MICROCHAIN"),
          Message: t("MSG_FAILED_IMPORT_MICROCHAIN", { ERROR: error }),
          Popup: true,
          Type: localStore.notify.NotifyType.Error
        });
        emit("error");
      });
    };
    const onCancelClick = () => {
      emit("canceled");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$x, [
        createBaseVNode("div", {
          innerHTML: _ctx.$t("MSG_CHECKO_NEEDS_TO_KNOW_MICROCHAIN_CREATION_MATERIAL_FOR_RECOVERY")
        }, null, 8, _hoisted_2$v),
        createBaseVNode("div", _hoisted_3$r, [
          createVNode(QIcon, {
            name: "bi-check-circle",
            color: "green-6",
            style: { marginBottom: "4px" }
          }),
          createTextVNode(" " + toDisplayString(_ctx.$t("MSG_PASTE_MICROCHAIN_CREATION_INFORMATION_TO_INPUT_BOX")), 1)
        ]),
        createBaseVNode("div", _hoisted_4$n, toDisplayString(_ctx.$t("MSG_MICROCHAIN_ID")), 1),
        createVNode(QInput, {
          outlined: "",
          modelValue: microchainId.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => microchainId.value = $event),
          type: "textarea",
          error: microchainIdError.value,
          autogrow: "",
          "hide-bottom-space": "",
          class: "vertical-items-margin"
        }, null, 8, ["modelValue", "error"]),
        createBaseVNode("div", _hoisted_5$m, toDisplayString(_ctx.$t("MSG_CREATOR_CHAIN_ID")), 1),
        createVNode(QInput, {
          outlined: "",
          modelValue: messageId.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => messageId.value = $event),
          type: "textarea",
          error: messageIdError.value,
          autogrow: "",
          "hide-bottom-space": "",
          class: "vertical-items-margin"
        }, null, 8, ["modelValue", "error"]),
        createBaseVNode("div", _hoisted_6$g, toDisplayString(_ctx.$t("MSG_CREATION_CERTIFICATE")), 1),
        createVNode(QInput, {
          outlined: "",
          modelValue: certificateHash.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => certificateHash.value = $event),
          type: "textarea",
          error: certificateHashError.value,
          autogrow: "",
          "hide-bottom-space": "",
          class: "vertical-items-margin"
        }, null, 8, ["modelValue", "error"]),
        createVNode(QBtn, {
          class: "btn vertical-sections-margin full-width",
          flat: "",
          "no-caps": "",
          onClick: onImportClick,
          disabled: !canImport.value,
          loading: importing.value
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_IMPORT")), 1)
          ]),
          _: 1
        }, 8, ["disabled", "loading"]),
        createVNode(QBtn, {
          class: "btn btn-alt vertical-items-margin extra-margin-bottom full-width",
          flat: "",
          "no-caps": "",
          onClick: onCancelClick
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_CANCEL")), 1)
          ]),
          _: 1
        })
      ]);
    };
  }
});
const _hoisted_1$w = { class: "fill-parent text-center" };
const _hoisted_2$u = { key: 0 };
const _hoisted_3$q = ["onClick"];
const _hoisted_4$m = {
  key: 1,
  class: "page-item-placeholder"
};
const _hoisted_5$l = { class: "page-item-y-margin-top" };
const _hoisted_6$f = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_7$d = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_8$d = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _sfc_main$G = defineComponent({
  __name: "MicrochainsView",
  setup(__props) {
    const { t } = useI18n({ useScope: "global" });
    const microchainOwners = ref([]);
    const microchains = ref([]);
    const selectedOwner = ref(void 0);
    const count = ref(0);
    const displayCount = ref(4);
    const displayMicrochains = computed(() => microchains.value.slice(0, displayCount.value));
    const creatingMicrochain = ref(false);
    const importingMicrochain = ref(false);
    const microchainsImportState = computed(() => localStore.setting.MicrochainsImportState);
    const onMicrochainCreated = async () => {
      creatingMicrochain.value = false;
      await loadMicrochains();
    };
    const onCreateMicrochainError = () => {
      creatingMicrochain.value = false;
    };
    const onCreateMicrochainClick = () => {
      creatingMicrochain.value = true;
    };
    const onImportMicrochainClick = () => {
      importingMicrochain.value = true;
    };
    const onMicrochainImported = async () => {
      importingMicrochain.value = false;
      await loadMicrochains();
    };
    const onImportMicrochainError = () => {
      importingMicrochain.value = false;
    };
    const onImportMicrochainCanceled = () => {
      importingMicrochain.value = false;
    };
    const onViewMoreClick = () => {
      displayCount.value += 4;
      displayCount.value = Math.min(displayCount.value, microchains.value.length);
    };
    const onSynchronizeMicrochainsClick = () => {
      if (!selectedOwner.value)
        return;
      Microchain.chains(selectedOwner.value?.owner).then(async (chains) => {
        for (const microchain of chains?.list || []) {
          await Microchain$1.create(selectedOwner.value.owner, microchain, void 0, void 0, chains?.default === microchain);
        }
        await loadMicrochains();
        localStore.notification.pushNotification({
          Title: t("MSG_SYNCHRONIZE_MICROCHAINS"),
          Message: t("MSG_SUCCESS_SYNCHRONIZE_MICROCHAINS"),
          Popup: true,
          Type: localStore.notify.NotifyType.Info
        });
      }).catch((error) => {
        localStore.notification.pushNotification({
          Title: t("MSG_SYNCHRONIZE_MICROCHAINS"),
          Message: t("MSG_FAILED_SYNCHRONIZE_MICROCHAINS", { ERROR: error }),
          Popup: true,
          Type: localStore.notify.NotifyType.Error
        });
      });
    };
    const loadMicrochainsRecursive = async (total, offset, limit, _microchains) => {
      if (offset >= total) {
        microchains.value = _microchains;
        return;
      }
      _microchains.push(...await Microchain$1.microchains(offset, limit, true, void 0, selectedOwner.value?.owner));
      void loadMicrochainsRecursive(total, offset + limit, limit, _microchains);
    };
    const loadMicrochains = async () => {
      if (!selectedOwner.value)
        return;
      const count2 = await Microchain$1.count();
      await loadMicrochainsRecursive(count2, 0, 10, []);
    };
    watch(count, async () => {
      await loadMicrochains();
    });
    onMounted(async () => {
      await loadMicrochains();
    });
    const onMicrochainClick = (microchain) => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MICROCHAIN;
      localStore.setting.HomeActionParams = microchain;
    };
    watch(microchainsImportState, async () => {
      switch (microchainsImportState.value) {
        case localStore.settingDef.MicrochainsImportState.MicrochainsImported:
          await loadMicrochains();
      }
    });
    watch(selectedOwner, async () => {
      await loadMicrochains();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$w, [
          createVNode(QSpace),
          createBaseVNode("div", null, [
            microchains.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_2$u, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(displayMicrochains.value, (microchain) => {
                return openBlock(), createElementBlock("div", {
                  key: microchain.microchain,
                  onClick: ($event) => onMicrochainClick(microchain),
                  class: "cursor-pointer"
                }, [
                  createVNode(_sfc_main$13, { microchain }, null, 8, ["microchain"])
                ], 8, _hoisted_3$q);
              }), 128)),
              displayCount.value < microchains.value.length ? (openBlock(), createBlock(QBtn, {
                key: 0,
                rounded: "",
                flat: "",
                "no-caps": "",
                class: "full-width bg-grey-1",
                onClick: onViewMoreClick,
                color: "grey-6",
                label: _ctx.$t("MSG_VIEW_MORE_THREE_DOTS")
              }, null, 8, ["label"])) : createCommentVNode("", true)
            ])) : (openBlock(), createElementBlock("div", _hoisted_4$m, [
              createBaseVNode("div", {
                class: "cursor-pointer",
                onClick: onCreateMicrochainClick
              }, [
                createVNode(QIcon, {
                  name: "bi-plus-circle",
                  size: "48px",
                  color: "grey-4"
                })
              ]),
              createBaseVNode("div", _hoisted_5$l, [
                createTextVNode(toDisplayString(_ctx.$t("MSG_NO_USABLE_MICROCHAIN")) + " ", 1),
                createBaseVNode("span", {
                  class: "cursor-pointer like-link",
                  onClick: onCreateMicrochainClick
                }, toDisplayString(_ctx.$t("MSG_CREATE")), 1),
                createTextVNode(" " + toDisplayString(_ctx.$t("MSG_OR_LOWER_CASE")) + " ", 1),
                createBaseVNode("span", {
                  class: "cursor-pointer like-link",
                  onClick: onImportMicrochainClick
                }, toDisplayString(_ctx.$t("MSG_IMPORT")), 1),
                _cache[5] || (_cache[5] = createTextVNode(". "))
              ])
            ])),
            createBaseVNode("div", {
              class: "row vertical-sections-margin selector-margin-x-left cursor-pointer",
              onClick: onCreateMicrochainClick
            }, [
              createVNode(QIcon, {
                name: "bi-plus-lg",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_6$f, toDisplayString(_ctx.$t("MSG_CREATE_MICROCHAIN")), 1)
            ]),
            createBaseVNode("div", {
              class: "row vertical-items-margin selector-margin-x-left cursor-pointer",
              onClick: onImportMicrochainClick
            }, [
              createVNode(QIcon, {
                name: "bi-plus-lg",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_7$d, toDisplayString(_ctx.$t("MSG_IMPORT_MICROCHAIN")), 1)
            ]),
            createBaseVNode("div", {
              class: "row vertical-items-margin selector-margin-x-left cursor-pointer",
              onClick: onSynchronizeMicrochainsClick
            }, [
              createVNode(QIcon, {
                name: "bi-arrow-repeat",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_8$d, toDisplayString(_ctx.$t("MSG_SYNCHRONIZE_MICROCHAINS")), 1)
            ])
          ]),
          createVNode(QSpace)
        ]),
        createVNode(_sfc_main$12, {
          "microchain-owners": microchainOwners.value,
          "onUpdate:microchainOwners": _cache[0] || (_cache[0] = ($event) => microchainOwners.value = $event)
        }, null, 8, ["microchain-owners"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[1] || (_cache[1] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        createVNode(_sfc_main$10, {
          count: count.value,
          "onUpdate:count": _cache[2] || (_cache[2] = ($event) => count.value = $event)
        }, null, 8, ["count"]),
        createVNode(QDialog, {
          modelValue: creatingMicrochain.value,
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => creatingMicrochain.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(QCard, { class: "dialog" }, {
              default: withCtx(() => [
                _cache[6] || (_cache[6] = createBaseVNode("h5", { class: "onboarding-page-title text-center page-title" }, " Create microchain ", -1)),
                createVNode(_sfc_main$I, {
                  onCreated: onMicrochainCreated,
                  onError: onCreateMicrochainError
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QDialog, {
          modelValue: importingMicrochain.value,
          "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => importingMicrochain.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(QCard, { class: "dialog page-x-padding page-y-padding" }, {
              default: withCtx(() => [
                _cache[7] || (_cache[7] = createBaseVNode("h5", { class: "onboarding-page-title text-center page-title" }, " Import microchain ", -1)),
                createVNode(_sfc_main$H, {
                  onImported: onMicrochainImported,
                  onError: onImportMicrochainError,
                  onCanceled: onImportMicrochainCanceled
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 64);
    };
  }
});
const _sfc_main$F = defineComponent({
  __name: "ApplicationCardView",
  props: {
    application: {}
  },
  setup(__props) {
    const props = __props;
    const application = toRef(props, "application");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, toDisplayString(application.value), 1);
    };
  }
});
const _hoisted_1$v = { class: "fill-parent text-center" };
const _hoisted_2$t = { key: 0 };
const _hoisted_3$p = {
  key: 1,
  class: "page-item-placeholder"
};
const _hoisted_4$l = { class: "cursor-pointer" };
const _hoisted_5$k = ["innerHTML"];
const _sfc_main$E = defineComponent({
  __name: "ApplicationsView",
  setup(__props) {
    const applications = ref([]);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$v, [
        createVNode(QSpace),
        createBaseVNode("div", null, [
          applications.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_2$t, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(applications.value, (application) => {
              return openBlock(), createBlock(_sfc_main$F, {
                key: application.applicationId,
                application
              }, null, 8, ["application"]);
            }), 128))
          ])) : (openBlock(), createElementBlock("div", _hoisted_3$p, [
            createBaseVNode("div", _hoisted_4$l, [
              createVNode(QIcon, {
                name: "bi-plus-circle",
                size: "48px",
                color: "grey-4"
              })
            ]),
            createBaseVNode("div", {
              class: "page-item-y-margin-top",
              innerHTML: _ctx.$t("MSG_NO_APPLICATIONS_CREATE_NEW")
            }, null, 8, _hoisted_5$k)
          ]))
        ]),
        createVNode(QSpace)
      ]);
    };
  }
});
const _sfc_main$D = defineComponent({
  __name: "ActivityBridge",
  props: /* @__PURE__ */ mergeModels({
    publicKey: {},
    microchain: {}
  }, {
    "activities": {},
    "activitiesModifiers": {}
  }),
  emits: ["update:activities"],
  setup(__props) {
    const props = __props;
    const publicKey = toRef(props, "publicKey");
    const microchain = toRef(props, "microchain");
    const activities = useModel(__props, "activities");
    const _activities = useObservable(
      liveQuery(async () => {
        const acts = [];
        if (publicKey.value) {
          acts.push(...await dbWallet.activities.where("targetAddress").equalsIgnoreCase(publicKey.value).toArray());
          acts.push(...await dbWallet.activities.where("sourceAddress").equalsIgnoreCase(publicKey.value).toArray());
        } else if (microchain.value) {
          acts.push(...await dbWallet.activities.where("targetChain").equalsIgnoreCase(microchain.value).toArray());
          acts.push(...await dbWallet.activities.where("sourceChain").equalsIgnoreCase(microchain.value).toArray());
        } else {
          acts.push(...await dbWallet.activities.toArray());
        }
        return acts;
      })
    );
    watch(_activities, () => {
      activities.value = _activities.value;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div");
    };
  }
});
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
function pad(v, length = 2, char = "0") {
  if (v === void 0 || v === null) {
    return v;
  }
  const val = "" + v;
  return val.length >= length ? val : new Array(length - val.length + 1).join(char) + val;
}
const breaks = [
  -61,
  9,
  38,
  199,
  426,
  686,
  756,
  818,
  1111,
  1181,
  1210,
  1635,
  2060,
  2097,
  2192,
  2262,
  2324,
  2394,
  2456,
  3178
];
function isLeapJalaaliYear(jy) {
  return jalCalLeap(jy) === 0;
}
function jalaaliMonthLength(jy, jm) {
  if (jm <= 6)
    return 31;
  if (jm <= 11)
    return 30;
  if (isLeapJalaaliYear(jy))
    return 30;
  return 29;
}
function jalCalLeap(jy) {
  const bl = breaks.length;
  let jp = breaks[0], jm, jump, leap, n, i;
  if (jy < jp || jy >= breaks[bl - 1]) {
    throw new Error("Invalid Jalaali year " + jy);
  }
  for (i = 1; i < bl; i += 1) {
    jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) {
      break;
    }
    jp = jm;
  }
  n = jy - jp;
  if (jump - n < 6) {
    n = n - jump + div(jump + 4, 33) * 33;
  }
  leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) {
    leap = 4;
  }
  return leap;
}
function div(a, b) {
  return ~~(a / b);
}
function mod(a, b) {
  return a - ~~(a / b) * b;
}
const MILLISECONDS_IN_DAY = 864e5, MILLISECONDS_IN_HOUR = 36e5, MILLISECONDS_IN_MINUTE = 6e4, defaultMask = "YYYY-MM-DDTHH:mm:ss.SSSZ", token = /\[((?:[^\]\\]|\\]|\\)*)\]|do|d{1,4}|Mo|M{1,4}|m{1,2}|wo|w{1,2}|Qo|Do|DDDo|D{1,4}|YY(?:YY)?|H{1,2}|h{1,2}|s{1,2}|S{1,3}|Z{1,2}|a{1,2}|[AQExX]/g, reverseToken = /(\[[^\]]*\])|do|d{1,4}|Mo|M{1,4}|m{1,2}|wo|w{1,2}|Qo|Do|DDDo|D{1,4}|YY(?:YY)?|H{1,2}|h{1,2}|s{1,2}|S{1,3}|Z{1,2}|a{1,2}|[AQExX]|([.*+:?^,\s${}()|\\]+)/g, regexStore = {};
function getRegexData(mask, dateLocale) {
  const days = "(" + dateLocale.days.join("|") + ")", key = mask + days;
  if (regexStore[key] !== void 0) {
    return regexStore[key];
  }
  const daysShort = "(" + dateLocale.daysShort.join("|") + ")", months = "(" + dateLocale.months.join("|") + ")", monthsShort = "(" + dateLocale.monthsShort.join("|") + ")";
  const map = {};
  let index = 0;
  const regexText = mask.replace(reverseToken, (match) => {
    index++;
    switch (match) {
      case "YY":
        map.YY = index;
        return "(-?\\d{1,2})";
      case "YYYY":
        map.YYYY = index;
        return "(-?\\d{1,4})";
      case "M":
        map.M = index;
        return "(\\d{1,2})";
      case "Mo":
        map.M = index++;
        return "(\\d{1,2}(st|nd|rd|th))";
      case "MM":
        map.M = index;
        return "(\\d{2})";
      case "MMM":
        map.MMM = index;
        return monthsShort;
      case "MMMM":
        map.MMMM = index;
        return months;
      case "D":
        map.D = index;
        return "(\\d{1,2})";
      case "Do":
        map.D = index++;
        return "(\\d{1,2}(st|nd|rd|th))";
      case "DD":
        map.D = index;
        return "(\\d{2})";
      case "H":
        map.H = index;
        return "(\\d{1,2})";
      case "HH":
        map.H = index;
        return "(\\d{2})";
      case "h":
        map.h = index;
        return "(\\d{1,2})";
      case "hh":
        map.h = index;
        return "(\\d{2})";
      case "m":
        map.m = index;
        return "(\\d{1,2})";
      case "mm":
        map.m = index;
        return "(\\d{2})";
      case "s":
        map.s = index;
        return "(\\d{1,2})";
      case "ss":
        map.s = index;
        return "(\\d{2})";
      case "S":
        map.S = index;
        return "(\\d{1})";
      case "SS":
        map.S = index;
        return "(\\d{2})";
      case "SSS":
        map.S = index;
        return "(\\d{3})";
      case "A":
        map.A = index;
        return "(AM|PM)";
      case "a":
        map.a = index;
        return "(am|pm)";
      case "aa":
        map.aa = index;
        return "(a\\.m\\.|p\\.m\\.)";
      case "ddd":
        return daysShort;
      case "dddd":
        return days;
      case "Q":
      case "d":
      case "E":
        return "(\\d{1})";
      case "do":
        index++;
        return "(\\d{1}(st|nd|rd|th))";
      case "Qo":
        return "(1st|2nd|3rd|4th)";
      case "DDD":
      case "DDDD":
        return "(\\d{1,3})";
      case "DDDo":
        index++;
        return "(\\d{1,3}(st|nd|rd|th))";
      case "w":
        return "(\\d{1,2})";
      case "wo":
        index++;
        return "(\\d{1,2}(st|nd|rd|th))";
      case "ww":
        return "(\\d{2})";
      case "Z":
        map.Z = index;
        return "(Z|[+-]\\d{2}:\\d{2})";
      case "ZZ":
        map.ZZ = index;
        return "(Z|[+-]\\d{2}\\d{2})";
      case "X":
        map.X = index;
        return "(-?\\d+)";
      case "x":
        map.x = index;
        return "(-?\\d{4,})";
      default:
        index--;
        if (match[0] === "[") {
          match = match.substring(1, match.length - 1);
        }
        return match.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
  });
  const res = { map, regex: new RegExp("^" + regexText) };
  regexStore[key] = res;
  return res;
}
function getDateLocale(paramDateLocale, langProps) {
  return paramDateLocale !== void 0 ? paramDateLocale : langProps !== void 0 ? langProps.date : defaultLang.date;
}
function formatTimezone(offset, delimeter = "") {
  const sign = offset > 0 ? "-" : "+", absOffset = Math.abs(offset), hours = Math.floor(absOffset / 60), minutes = absOffset % 60;
  return sign + pad(hours) + delimeter + pad(minutes);
}
function applyYearMonthDayChange(date2, mod2, sign) {
  let year = date2.getFullYear(), month = date2.getMonth();
  const day = date2.getDate();
  if (mod2.year !== void 0) {
    year += sign * mod2.year;
    delete mod2.year;
  }
  if (mod2.month !== void 0) {
    month += sign * mod2.month;
    delete mod2.month;
  }
  date2.setDate(1);
  date2.setMonth(2);
  date2.setFullYear(year);
  date2.setMonth(month);
  date2.setDate(Math.min(day, daysInMonth(date2)));
  if (mod2.date !== void 0) {
    date2.setDate(date2.getDate() + sign * mod2.date);
    delete mod2.date;
  }
  return date2;
}
function applyYearMonthDay(date2, mod2, middle) {
  const year = mod2.year !== void 0 ? mod2.year : date2[`get${middle}FullYear`](), month = mod2.month !== void 0 ? mod2.month - 1 : date2[`get${middle}Month`](), maxDay = new Date(year, month + 1, 0).getDate(), day = Math.min(maxDay, mod2.date !== void 0 ? mod2.date : date2[`get${middle}Date`]());
  date2[`set${middle}Date`](1);
  date2[`set${middle}Month`](2);
  date2[`set${middle}FullYear`](year);
  date2[`set${middle}Month`](month);
  date2[`set${middle}Date`](day);
  delete mod2.year;
  delete mod2.month;
  delete mod2.date;
  return date2;
}
function getChange(date2, rawMod, sign) {
  const mod2 = normalizeMod(rawMod), d = new Date(date2), t = mod2.year !== void 0 || mod2.month !== void 0 || mod2.date !== void 0 ? applyYearMonthDayChange(d, mod2, sign) : d;
  for (const key in mod2) {
    const op = capitalize(key);
    t[`set${op}`](t[`get${op}`]() + sign * mod2[key]);
  }
  return t;
}
function normalizeMod(mod2) {
  const acc = { ...mod2 };
  if (mod2.years !== void 0) {
    acc.year = mod2.years;
    delete acc.years;
  }
  if (mod2.months !== void 0) {
    acc.month = mod2.months;
    delete acc.months;
  }
  if (mod2.days !== void 0) {
    acc.date = mod2.days;
    delete acc.days;
  }
  if (mod2.day !== void 0) {
    acc.date = mod2.day;
    delete acc.day;
  }
  if (mod2.hour !== void 0) {
    acc.hours = mod2.hour;
    delete acc.hour;
  }
  if (mod2.minute !== void 0) {
    acc.minutes = mod2.minute;
    delete acc.minute;
  }
  if (mod2.second !== void 0) {
    acc.seconds = mod2.second;
    delete acc.second;
  }
  if (mod2.millisecond !== void 0) {
    acc.milliseconds = mod2.millisecond;
    delete acc.millisecond;
  }
  return acc;
}
function adjustDate(date2, rawMod, utc) {
  const mod2 = normalizeMod(rawMod), middle = utc === true ? "UTC" : "", d = new Date(date2), t = mod2.year !== void 0 || mod2.month !== void 0 || mod2.date !== void 0 ? applyYearMonthDay(d, mod2, middle) : d;
  for (const key in mod2) {
    const op = key.charAt(0).toUpperCase() + key.slice(1);
    t[`set${middle}${op}`](mod2[key]);
  }
  return t;
}
function extractDate(str, mask, dateLocale) {
  const d = __splitDate(str, mask, dateLocale);
  const date2 = new Date(
    d.year,
    d.month === null ? null : d.month - 1,
    d.day === null ? 1 : d.day,
    d.hour,
    d.minute,
    d.second,
    d.millisecond
  );
  const tzOffset = date2.getTimezoneOffset();
  return d.timezoneOffset === null || d.timezoneOffset === tzOffset ? date2 : getChange(date2, { minutes: d.timezoneOffset - tzOffset }, 1);
}
function __splitDate(str, mask, dateLocale, calendar, defaultModel) {
  const date2 = {
    year: null,
    month: null,
    day: null,
    hour: null,
    minute: null,
    second: null,
    millisecond: null,
    timezoneOffset: null,
    dateHash: null,
    timeHash: null
  };
  defaultModel !== void 0 && Object.assign(date2, defaultModel);
  if (str === void 0 || str === null || str === "" || typeof str !== "string") {
    return date2;
  }
  if (mask === void 0) {
    mask = defaultMask;
  }
  const langOpts = getDateLocale(dateLocale, Plugin.props), months = langOpts.months, monthsShort = langOpts.monthsShort;
  const { regex, map } = getRegexData(mask, langOpts);
  const match = str.match(regex);
  if (match === null) {
    return date2;
  }
  let tzString = "";
  if (map.X !== void 0 || map.x !== void 0) {
    const stamp = parseInt(match[map.X !== void 0 ? map.X : map.x], 10);
    if (isNaN(stamp) === true || stamp < 0) {
      return date2;
    }
    const d = new Date(stamp * (map.X !== void 0 ? 1e3 : 1));
    date2.year = d.getFullYear();
    date2.month = d.getMonth() + 1;
    date2.day = d.getDate();
    date2.hour = d.getHours();
    date2.minute = d.getMinutes();
    date2.second = d.getSeconds();
    date2.millisecond = d.getMilliseconds();
  } else {
    if (map.YYYY !== void 0) {
      date2.year = parseInt(match[map.YYYY], 10);
    } else if (map.YY !== void 0) {
      const y = parseInt(match[map.YY], 10);
      date2.year = y < 0 ? y : 2e3 + y;
    }
    if (map.M !== void 0) {
      date2.month = parseInt(match[map.M], 10);
      if (date2.month < 1 || date2.month > 12) {
        return date2;
      }
    } else if (map.MMM !== void 0) {
      date2.month = monthsShort.indexOf(match[map.MMM]) + 1;
    } else if (map.MMMM !== void 0) {
      date2.month = months.indexOf(match[map.MMMM]) + 1;
    }
    if (map.D !== void 0) {
      date2.day = parseInt(match[map.D], 10);
      if (date2.year === null || date2.month === null || date2.day < 1) {
        return date2;
      }
      const maxDay = calendar !== "persian" ? new Date(date2.year, date2.month, 0).getDate() : jalaaliMonthLength(date2.year, date2.month);
      if (date2.day > maxDay) {
        return date2;
      }
    }
    if (map.H !== void 0) {
      date2.hour = parseInt(match[map.H], 10) % 24;
    } else if (map.h !== void 0) {
      date2.hour = parseInt(match[map.h], 10) % 12;
      if (map.A && match[map.A] === "PM" || map.a && match[map.a] === "pm" || map.aa && match[map.aa] === "p.m.") {
        date2.hour += 12;
      }
      date2.hour = date2.hour % 24;
    }
    if (map.m !== void 0) {
      date2.minute = parseInt(match[map.m], 10) % 60;
    }
    if (map.s !== void 0) {
      date2.second = parseInt(match[map.s], 10) % 60;
    }
    if (map.S !== void 0) {
      date2.millisecond = parseInt(match[map.S], 10) * 10 ** (3 - match[map.S].length);
    }
    if (map.Z !== void 0 || map.ZZ !== void 0) {
      tzString = map.Z !== void 0 ? match[map.Z].replace(":", "") : match[map.ZZ];
      date2.timezoneOffset = (tzString[0] === "+" ? -1 : 1) * (60 * tzString.slice(1, 3) + 1 * tzString.slice(3, 5));
    }
  }
  date2.dateHash = pad(date2.year, 6) + "/" + pad(date2.month) + "/" + pad(date2.day);
  date2.timeHash = pad(date2.hour) + ":" + pad(date2.minute) + ":" + pad(date2.second) + tzString;
  return date2;
}
function isValid(date2) {
  return typeof date2 === "number" ? true : isNaN(Date.parse(date2)) === false;
}
function buildDate(mod2, utc) {
  return adjustDate(new Date(), mod2, utc);
}
function getDayOfWeek(date2) {
  const dow = new Date(date2).getDay();
  return dow === 0 ? 7 : dow;
}
function getWeekOfYear(date2) {
  const thursday = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
  thursday.setDate(thursday.getDate() - (thursday.getDay() + 6) % 7 + 3);
  const firstThursday = new Date(thursday.getFullYear(), 0, 4);
  firstThursday.setDate(firstThursday.getDate() - (firstThursday.getDay() + 6) % 7 + 3);
  const ds = thursday.getTimezoneOffset() - firstThursday.getTimezoneOffset();
  thursday.setHours(thursday.getHours() - ds);
  const weekDiff = (thursday - firstThursday) / (MILLISECONDS_IN_DAY * 7);
  return 1 + Math.floor(weekDiff);
}
function getDayIdentifier(date2) {
  return date2.getFullYear() * 1e4 + date2.getMonth() * 100 + date2.getDate();
}
function getDateIdentifier(date2, onlyDate) {
  const d = new Date(date2);
  return onlyDate === true ? getDayIdentifier(d) : d.getTime();
}
function isBetweenDates(date2, from, to, opts = {}) {
  const d1 = getDateIdentifier(from, opts.onlyDate), d2 = getDateIdentifier(to, opts.onlyDate), cur = getDateIdentifier(date2, opts.onlyDate);
  return (cur > d1 || opts.inclusiveFrom === true && cur === d1) && (cur < d2 || opts.inclusiveTo === true && cur === d2);
}
function addToDate(date2, mod2) {
  return getChange(date2, mod2, 1);
}
function subtractFromDate(date2, mod2) {
  return getChange(date2, mod2, -1);
}
function startOfDate(date2, unit, utc) {
  const t = new Date(date2), prefix = `set${utc === true ? "UTC" : ""}`;
  switch (unit) {
    case "year":
    case "years":
      t[`${prefix}Month`](0);
    case "month":
    case "months":
      t[`${prefix}Date`](1);
    case "day":
    case "days":
    case "date":
      t[`${prefix}Hours`](0);
    case "hour":
    case "hours":
      t[`${prefix}Minutes`](0);
    case "minute":
    case "minutes":
      t[`${prefix}Seconds`](0);
    case "second":
    case "seconds":
      t[`${prefix}Milliseconds`](0);
  }
  return t;
}
function endOfDate(date2, unit, utc) {
  const t = new Date(date2), prefix = `set${utc === true ? "UTC" : ""}`;
  switch (unit) {
    case "year":
    case "years":
      t[`${prefix}Month`](11);
    case "month":
    case "months":
      t[`${prefix}Date`](daysInMonth(t));
    case "day":
    case "days":
    case "date":
      t[`${prefix}Hours`](23);
    case "hour":
    case "hours":
      t[`${prefix}Minutes`](59);
    case "minute":
    case "minutes":
      t[`${prefix}Seconds`](59);
    case "second":
    case "seconds":
      t[`${prefix}Milliseconds`](999);
  }
  return t;
}
function getMaxDate(date2) {
  let t = new Date(date2);
  Array.prototype.slice.call(arguments, 1).forEach((d) => {
    t = Math.max(t, new Date(d));
  });
  return t;
}
function getMinDate(date2) {
  let t = new Date(date2);
  Array.prototype.slice.call(arguments, 1).forEach((d) => {
    t = Math.min(t, new Date(d));
  });
  return t;
}
function getDiff(t, sub, interval) {
  return (t.getTime() - t.getTimezoneOffset() * MILLISECONDS_IN_MINUTE - (sub.getTime() - sub.getTimezoneOffset() * MILLISECONDS_IN_MINUTE)) / interval;
}
function getDateDiff(date2, subtract, unit = "days") {
  const t = new Date(date2), sub = new Date(subtract);
  switch (unit) {
    case "years":
    case "year":
      return t.getFullYear() - sub.getFullYear();
    case "months":
    case "month":
      return (t.getFullYear() - sub.getFullYear()) * 12 + t.getMonth() - sub.getMonth();
    case "days":
    case "day":
    case "date":
      return getDiff(startOfDate(t, "day"), startOfDate(sub, "day"), MILLISECONDS_IN_DAY);
    case "hours":
    case "hour":
      return getDiff(startOfDate(t, "hour"), startOfDate(sub, "hour"), MILLISECONDS_IN_HOUR);
    case "minutes":
    case "minute":
      return getDiff(startOfDate(t, "minute"), startOfDate(sub, "minute"), MILLISECONDS_IN_MINUTE);
    case "seconds":
    case "second":
      return getDiff(startOfDate(t, "second"), startOfDate(sub, "second"), 1e3);
  }
}
function getDayOfYear(date2) {
  return getDateDiff(date2, startOfDate(date2, "year"), "days") + 1;
}
function inferDateFormat(date2) {
  return isDate(date2) === true ? "date" : typeof date2 === "number" ? "number" : "string";
}
function getDateBetween(date2, min, max) {
  const t = new Date(date2);
  if (min) {
    const low = new Date(min);
    if (t < low) {
      return low;
    }
  }
  if (max) {
    const high = new Date(max);
    if (t > high) {
      return high;
    }
  }
  return t;
}
function isSameDate(date2, date22, unit) {
  const t = new Date(date2), d = new Date(date22);
  if (unit === void 0) {
    return t.getTime() === d.getTime();
  }
  switch (unit) {
    case "second":
    case "seconds":
      if (t.getSeconds() !== d.getSeconds()) {
        return false;
      }
    case "minute":
    case "minutes":
      if (t.getMinutes() !== d.getMinutes()) {
        return false;
      }
    case "hour":
    case "hours":
      if (t.getHours() !== d.getHours()) {
        return false;
      }
    case "day":
    case "days":
    case "date":
      if (t.getDate() !== d.getDate()) {
        return false;
      }
    case "month":
    case "months":
      if (t.getMonth() !== d.getMonth()) {
        return false;
      }
    case "year":
    case "years":
      if (t.getFullYear() !== d.getFullYear()) {
        return false;
      }
      break;
    default:
      throw new Error(`date isSameDate unknown unit ${unit}`);
  }
  return true;
}
function daysInMonth(date2) {
  return new Date(date2.getFullYear(), date2.getMonth() + 1, 0).getDate();
}
function getOrdinal(n) {
  if (n >= 11 && n <= 13) {
    return `${n}th`;
  }
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
  }
  return `${n}th`;
}
const formatter = {
  YY(date2, dateLocale, forcedYear) {
    const y = this.YYYY(date2, dateLocale, forcedYear) % 100;
    return y >= 0 ? pad(y) : "-" + pad(Math.abs(y));
  },
  YYYY(date2, _dateLocale, forcedYear) {
    return forcedYear !== void 0 && forcedYear !== null ? forcedYear : date2.getFullYear();
  },
  M(date2) {
    return date2.getMonth() + 1;
  },
  Mo(date2) {
    return getOrdinal(date2.getMonth() + 1);
  },
  MM(date2) {
    return pad(date2.getMonth() + 1);
  },
  MMM(date2, dateLocale) {
    return dateLocale.monthsShort[date2.getMonth()];
  },
  MMMM(date2, dateLocale) {
    return dateLocale.months[date2.getMonth()];
  },
  Q(date2) {
    return Math.ceil((date2.getMonth() + 1) / 3);
  },
  Qo(date2) {
    return getOrdinal(this.Q(date2));
  },
  D(date2) {
    return date2.getDate();
  },
  Do(date2) {
    return getOrdinal(date2.getDate());
  },
  DD(date2) {
    return pad(date2.getDate());
  },
  DDD(date2) {
    return getDayOfYear(date2);
  },
  DDDo(date2) {
    return getOrdinal(getDayOfYear(date2));
  },
  DDDD(date2) {
    return pad(getDayOfYear(date2), 3);
  },
  d(date2) {
    return date2.getDay();
  },
  do(date2) {
    return getOrdinal(date2.getDay());
  },
  dd(date2, dateLocale) {
    return dateLocale.days[date2.getDay()].slice(0, 2);
  },
  ddd(date2, dateLocale) {
    return dateLocale.daysShort[date2.getDay()];
  },
  dddd(date2, dateLocale) {
    return dateLocale.days[date2.getDay()];
  },
  E(date2) {
    return date2.getDay() || 7;
  },
  w(date2) {
    return getWeekOfYear(date2);
  },
  wo(date2) {
    return getOrdinal(getWeekOfYear(date2));
  },
  ww(date2) {
    return pad(getWeekOfYear(date2));
  },
  H(date2) {
    return date2.getHours();
  },
  HH(date2) {
    return pad(date2.getHours());
  },
  h(date2) {
    const hours = date2.getHours();
    return hours === 0 ? 12 : hours > 12 ? hours % 12 : hours;
  },
  hh(date2) {
    return pad(this.h(date2));
  },
  m(date2) {
    return date2.getMinutes();
  },
  mm(date2) {
    return pad(date2.getMinutes());
  },
  s(date2) {
    return date2.getSeconds();
  },
  ss(date2) {
    return pad(date2.getSeconds());
  },
  S(date2) {
    return Math.floor(date2.getMilliseconds() / 100);
  },
  SS(date2) {
    return pad(Math.floor(date2.getMilliseconds() / 10));
  },
  SSS(date2) {
    return pad(date2.getMilliseconds(), 3);
  },
  A(date2) {
    return date2.getHours() < 12 ? "AM" : "PM";
  },
  a(date2) {
    return date2.getHours() < 12 ? "am" : "pm";
  },
  aa(date2) {
    return date2.getHours() < 12 ? "a.m." : "p.m.";
  },
  Z(date2, _dateLocale, _forcedYear, forcedTimezoneOffset) {
    const tzOffset = forcedTimezoneOffset === void 0 || forcedTimezoneOffset === null ? date2.getTimezoneOffset() : forcedTimezoneOffset;
    return formatTimezone(tzOffset, ":");
  },
  ZZ(date2, _dateLocale, _forcedYear, forcedTimezoneOffset) {
    const tzOffset = forcedTimezoneOffset === void 0 || forcedTimezoneOffset === null ? date2.getTimezoneOffset() : forcedTimezoneOffset;
    return formatTimezone(tzOffset);
  },
  X(date2) {
    return Math.floor(date2.getTime() / 1e3);
  },
  x(date2) {
    return date2.getTime();
  }
};
function formatDate(val, mask, dateLocale, __forcedYear, __forcedTimezoneOffset) {
  if (val !== 0 && !val || val === Infinity || val === -Infinity) {
    return;
  }
  const date2 = new Date(val);
  if (isNaN(date2)) {
    return;
  }
  if (mask === void 0) {
    mask = defaultMask;
  }
  const locale = getDateLocale(dateLocale, Plugin.props);
  return mask.replace(
    token,
    (match, text) => match in formatter ? formatter[match](date2, locale, __forcedYear, __forcedTimezoneOffset) : text === void 0 ? match : text.split("\\]").join("]")
  );
}
function clone(date2) {
  return isDate(date2) === true ? new Date(date2.getTime()) : date2;
}
var date = {
  isValid,
  extractDate,
  buildDate,
  getDayOfWeek,
  getWeekOfYear,
  isBetweenDates,
  addToDate,
  subtractFromDate,
  adjustDate,
  startOfDate,
  endOfDate,
  getMaxDate,
  getMinDate,
  getDateDiff,
  getDayOfYear,
  inferDateFormat,
  getDateBetween,
  isSameDate,
  daysInMonth,
  formatDate,
  clone
};
var ActivityCardView_vue_vue_type_style_index_0_scope_true_lang = "";
const _hoisted_1$u = { class: "text-bold text-left" };
const _hoisted_2$s = { class: "text-grey-9 row flex items-center justify-center" };
const _hoisted_3$o = { class: "page-item-x-margin-left cursor-pointer" };
const _hoisted_4$k = { class: "text-left label-text-small text-grey-6" };
const _hoisted_5$j = { class: "row text-bold" };
const _hoisted_6$e = { class: "page-item-x-margin-left" };
const _sfc_main$C = defineComponent({
  __name: "ActivityCardView",
  props: {
    activity: {},
    xPadding: {}
  },
  setup(__props) {
    const props = __props;
    const activity = toRef(props, "activity");
    const xPadding = toRef(props, "xPadding");
    const owner = ref(void 0);
    const microchainOwners = ref([]);
    const token2 = ref(void 0);
    const action = computed(() => {
      if (activity.value.sourceAddress === activity.value.targetAddress) {
        return "Move";
      }
      if (activity.value.microchain === activity.value.sourceChain) {
        return "Send";
      }
      if (activity.value.microchain === activity.value.targetChain) {
        return "Receive";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0 && microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "Move";
      }
      if (owner.value?.owner === activity.value.sourceAddress) {
        return "Send";
      }
      if (owner.value?.owner === activity.value.targetAddress) {
        return "Receive";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0) {
        return "Send";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "Receive";
      }
      return "Unknown";
    });
    const address = computed(() => {
      if (activity.value.sourceAddress === activity.value.targetAddress && activity.value.targetAddress?.length) {
        return activity.value.sourceChain;
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0 && microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return activity.value.sourceAddress || activity.value.sourceChain;
      }
      if (owner.value?.owner === activity.value.sourceAddress) {
        return activity.value.targetAddress || activity.value.targetChain;
      }
      if (owner.value?.owner === activity.value.targetAddress) {
        return activity.value.sourceAddress || activity.value.sourceChain;
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0) {
        return activity.value.targetAddress || activity.value.targetChain;
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return activity.value.sourceAddress || activity.value.sourceChain;
      }
      return "Unknown";
    });
    const direction = computed(() => {
      if (activity.value.sourceAddress === activity.value.targetAddress && activity.value.targetAddress?.length) {
        return "bi-arrows";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0 && microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "bi-arrows";
      }
      if (owner.value?.owner === activity.value.sourceAddress) {
        return "bi-dash-lg";
      }
      if (owner.value?.owner === activity.value.targetAddress) {
        return "bi-plus-lg";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0) {
        return "bi-dash-lg";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "bi-plus-lg";
      }
      return "bi-question-circle-fill";
    });
    const icon = computed(() => {
      if (activity.value.sourceAddress === activity.value.targetAddress && activity.value.targetAddress?.length) {
        return "bi-arrow-right-square";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0 && microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "bi-arrow-right-square";
      }
      if (activity.value.sourceAddress === owner.value?.address) {
        return "bi-box-arrow-right";
      }
      if (activity.value.targetAddress === owner.value?.address) {
        return "bi-box-arrow-in-right";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0) {
        return "bi-box-arrow-right";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "bi-box-arrow-in-right";
      }
      return "bi-question-circle-fill";
    });
    onMounted(async () => {
      token2.value = await Token.tokenWithId(activity.value.tokenId);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(QItem, {
          class: "row full-width tab-panel-item",
          clickable: "",
          style: normalizeStyle({ paddingLeft: xPadding.value, paddingRight: xPadding.value })
        }, {
          default: withCtx(() => [
            createVNode(QAvatar, { size: "32px" }, {
              default: withCtx(() => [
                createVNode(QIcon, {
                  name: icon.value,
                  size: "24px"
                }, null, 8, ["name"]),
                createVNode(QBadge, {
                  color: "transparent",
                  rounded: "",
                  transparent: "",
                  floating: ""
                }, {
                  default: withCtx(() => [
                    createVNode(QImg, {
                      src: unref(lineraLogo),
                      width: "14px",
                      height: "14px"
                    }, null, 8, ["src"])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createBaseVNode("div", {
              class: "selector-margin-x-left row",
              style: normalizeStyle({ width: "calc(100% - 32px - " + xPadding.value + " - " + xPadding.value + ")" })
            }, [
              createBaseVNode("div", null, [
                createBaseVNode("div", _hoisted_1$u, toDisplayString(action.value), 1),
                createBaseVNode("div", _hoisted_2$s, [
                  createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(address.value, 6)), 1),
                  createBaseVNode("div", _hoisted_3$o, [
                    createVNode(QIcon, {
                      name: "bi-copy",
                      size: "12px",
                      style: { marginBottom: "3px" },
                      onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(address.value, evt), ["stop"]))
                    })
                  ])
                ]),
                createBaseVNode("div", _hoisted_4$k, toDisplayString(unref(date).formatDate(activity.value.timestamp / 1e3, "YYYY/MM/DD HH:mm:ss")), 1)
              ]),
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_5$j, [
                createVNode(QIcon, {
                  name: direction.value,
                  color: "black",
                  size: "12px",
                  style: { marginTop: "5px" }
                }, null, 8, ["name"]),
                createBaseVNode("div", _hoisted_6$e, toDisplayString(Number(activity.value.amount).toFixed(4)) + " " + toDisplayString(token2.value?.ticker), 1)
              ])
            ], 4)
          ]),
          _: 1
        }, 8, ["style"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": owner.value,
          "onUpdate:selectedOwner": _cache[1] || (_cache[1] = ($event) => owner.value = $event)
        }, null, 8, ["selected-owner"]),
        createVNode(_sfc_main$12, {
          owner: owner.value?.owner,
          "microchain-owners": microchainOwners.value,
          "onUpdate:microchainOwners": _cache[2] || (_cache[2] = ($event) => microchainOwners.value = $event)
        }, null, 8, ["owner", "microchain-owners"])
      ], 64);
    };
  }
});
const _hoisted_1$t = { class: "fill-parent text-center" };
const _hoisted_2$r = { key: 0 };
const _hoisted_3$n = ["onClick"];
const _hoisted_4$j = {
  key: 1,
  class: "page-item-placeholder"
};
const _hoisted_5$i = ["innerHTML"];
const _sfc_main$B = defineComponent({
  __name: "ActivitiesView",
  props: {
    xPadding: {}
  },
  setup(__props) {
    const props = __props;
    const xPadding = toRef(props, "xPadding");
    const selectedOwner = ref(void 0);
    const dbActivityBridge = ref();
    const activities = ref([]);
    const displayCount = ref(5);
    const displayActivities = computed(() => {
      return [...activities.value].sort((a, b) => b.timestamp - a.timestamp).slice(0, displayCount.value);
    });
    const loadActivitiesRecursive = async (total, offset, limit, _activities) => {
      if (offset >= total) {
        activities.value = _activities;
        return;
      }
      _activities.push(...await Activity.ownerActivities(offset, limit, selectedOwner.value));
      void loadActivitiesRecursive(total, offset + limit, limit, _activities);
    };
    const loadActivities = async () => {
      if (!selectedOwner.value)
        return;
      activities.value = [];
      const count = await Activity.count();
      await loadActivitiesRecursive(count, 0, 10, []);
    };
    onMounted(() => {
      void loadActivities();
    });
    watch(selectedOwner, () => {
      void loadActivities();
    });
    const onActivityClick = (activity) => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_ACTIVITY;
      localStore.setting.HomeActionParams = activity;
    };
    const onViewMoreClick = () => {
      displayCount.value += 4;
      displayCount.value = Math.min(displayCount.value, activities.value.length);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$t, [
          createVNode(QSpace),
          activities.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_2$r, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(displayActivities.value, (activity) => {
              return openBlock(), createElementBlock("div", {
                key: activity.id,
                onClick: ($event) => onActivityClick(activity)
              }, [
                createVNode(_sfc_main$C, {
                  activity,
                  "x-padding": xPadding.value
                }, null, 8, ["activity", "x-padding"])
              ], 8, _hoisted_3$n);
            }), 128)),
            displayCount.value < activities.value.length ? (openBlock(), createBlock(QBtn, {
              key: 0,
              rounded: "",
              flat: "",
              "no-caps": "",
              class: "full-width bg-grey-1",
              onClick: onViewMoreClick,
              color: "grey-6",
              label: _ctx.$t("MSG_VIEW_MORE_THREE_DOTS")
            }, null, 8, ["label"])) : createCommentVNode("", true)
          ])) : (openBlock(), createElementBlock("div", _hoisted_4$j, [
            createBaseVNode("div", null, [
              createVNode(QIcon, {
                name: "bi-plus-circle",
                size: "48px",
                color: "grey-4"
              })
            ]),
            createBaseVNode("div", {
              class: "page-item-y-margin-top",
              innerHTML: _ctx.$t("MSG_NEW_TO_LINERA_TRANSFER_TOKENS")
            }, null, 8, _hoisted_5$i)
          ])),
          createVNode(QSpace)
        ]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[0] || (_cache[0] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        createVNode(_sfc_main$D, {
          ref_key: "dbActivityBridge",
          ref: dbActivityBridge
        }, null, 512)
      ], 64);
    };
  }
});
var block0 = ".extension-tab {\n  padding: 0 4px;\n}";
const _hoisted_1$s = { class: "page-padding full-width text-center home-tabs" };
const _sfc_main$A = defineComponent({
  __name: "TabsView",
  setup(__props) {
    const tab = computed({
      get: () => localStore.setting.homeTab || "microchains",
      set: (v) => {
        localStore.setting.HomeTab = v;
      }
    });
    onMounted(async () => {
      await Token.initialize(lineraLogo);
      await Network.initialize();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$s, [
        createVNode(QTabs, {
          modelValue: tab.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => tab.value = $event),
          "no-caps": "",
          "indicator-color": "red-6",
          dense: ""
        }, {
          default: withCtx(() => [
            createVNode(QTab, {
              name: "microchains",
              class: normalizeClass([unref(localStore).setting.extensionMode ? "extension-tab" : ""])
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("MSG_MICROCHAINS")), 1)
              ]),
              _: 1
            }, 8, ["class"]),
            createVNode(QTab, {
              name: "tokens",
              class: normalizeClass([unref(localStore).setting.extensionMode ? "extension-tab" : ""])
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("MSG_TOKENS")), 1)
              ]),
              _: 1
            }, 8, ["class"]),
            createVNode(QTab, {
              name: "applications",
              class: normalizeClass([unref(localStore).setting.extensionMode ? "extension-tab" : ""])
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("MSG_APPLICATIONS")), 1)
              ]),
              _: 1
            }, 8, ["class"]),
            createVNode(QTab, {
              name: "activities",
              class: normalizeClass([unref(localStore).setting.extensionMode ? "extension-tab" : ""])
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("MSG_ACTIVITIES")), 1)
              ]),
              _: 1
            }, 8, ["class"])
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(QTabPanels, {
          modelValue: tab.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => tab.value = $event),
          swipeable: "",
          animated: ""
        }, {
          default: withCtx(() => [
            createVNode(QTabPanel, { name: "tokens" }, {
              default: withCtx(() => [
                createVNode(_sfc_main$L)
              ]),
              _: 1
            }),
            createVNode(QTabPanel, { name: "microchains" }, {
              default: withCtx(() => [
                createVNode(_sfc_main$G)
              ]),
              _: 1
            }),
            createVNode(QTabPanel, { name: "applications" }, {
              default: withCtx(() => [
                createVNode(_sfc_main$E)
              ]),
              _: 1
            }),
            createVNode(QTabPanel, { name: "activities" }, {
              default: withCtx(() => [
                createVNode(_sfc_main$B, { "x-padding": "6px" })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
});
const _hoisted_1$r = { class: "full-width" };
const _hoisted_2$q = { key: 0 };
const _hoisted_3$m = {
  key: 1,
  class: "home-create-account"
};
const _hoisted_4$i = { class: "page-item-placeholder text-center" };
const _hoisted_5$h = ["innerHTML"];
const _sfc_main$z = defineComponent({
  __name: "MainInnerView",
  setup(__props) {
    const owners = ref([]);
    const onCreateAccountClick = () => {
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$r, [
        owners.value.length ? (openBlock(), createElementBlock("div", _hoisted_2$q, [
          createVNode(_sfc_main$N)
        ])) : (openBlock(), createElementBlock("div", _hoisted_3$m, [
          createBaseVNode("div", _hoisted_4$i, [
            createBaseVNode("div", {
              class: "cursor-pointer",
              onClick: onCreateAccountClick
            }, [
              createVNode(QIcon, {
                name: "bi-plus-circle",
                size: "48px",
                color: "grey-4"
              })
            ]),
            createBaseVNode("div", {
              class: "page-item-y-margin-top",
              innerHTML: _ctx.$t("MSG_NO_ACCOUNT_CREATE_NEW")
            }, null, 8, _hoisted_5$h)
          ]),
          _cache[1] || (_cache[1] = createBaseVNode("div", { style: { height: "24px" } }, null, -1))
        ])),
        createVNode(_sfc_main$A),
        createVNode(_sfc_main$Y, {
          owners: owners.value,
          "onUpdate:owners": _cache[0] || (_cache[0] = ($event) => owners.value = $event)
        }, null, 8, ["owners"])
      ]);
    };
  }
});
const _hoisted_1$q = { class: "text-bold text-left" };
const _hoisted_2$p = { class: "text-grey-9 row flex items-center" };
const _hoisted_3$l = { class: "page-item-x-margin-left cursor-pointer" };
const _hoisted_4$h = { class: "text-left label-text-small text-grey-6" };
const _hoisted_5$g = {
  key: 0,
  class: "page-item-x-margin-left text-bold"
};
const _hoisted_6$d = { class: "row" };
const _sfc_main$y = defineComponent({
  __name: "ChainOperationCardView",
  props: {
    operation: {},
    xPadding: {}
  },
  setup(__props) {
    const props = __props;
    const operation = toRef(props, "operation");
    const xPadding = toRef(props, "xPadding");
    const operationType = computed(() => {
      if (operation.value.operationType && operation.value.operationType !== OperationType.ANONYMOUS) {
        return operation.value.operationType[0].toUpperCase() + operation.value.operationType.slice(1);
      }
      const _operation = JSON.parse(operation.value.operation);
      if (_operation.System) {
        return "System:" + Object.keys(_operation.System)[0];
      }
      if (_operation.User) {
        return "User:" + (lineraGraphqlMutationQueryWithQuery(operation.value.graphqlQuery || "") || "Unknown");
      }
      return "Unknown";
    });
    const transferAmount = ref(0);
    const token2 = ref(void 0);
    onMounted(async () => {
      if (operation.value.operationType === OperationType.TRANSFER) {
        const _operation = JSON.parse(operation.value.operation);
        transferAmount.value = Number(_operation.System?.Transfer?.amount);
        token2.value = await Token.native();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QItem, {
        class: "row full-width tab-panel-item",
        clickable: "",
        style: normalizeStyle({ paddingLeft: xPadding.value, paddingRight: xPadding.value })
      }, {
        default: withCtx(() => [
          createVNode(QAvatar, { size: "32px" }, {
            default: withCtx(() => [
              createVNode(QIcon, {
                name: "bi-arrow-right-square",
                size: "24px"
              }),
              createVNode(QBadge, {
                color: "transparent",
                rounded: "",
                transparent: "",
                floating: ""
              }, {
                default: withCtx(() => [
                  createVNode(QImg, {
                    src: unref(lineraLogo),
                    width: "14px",
                    height: "14px"
                  }, null, 8, ["src"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createBaseVNode("div", {
            class: "selector-margin-x-left row",
            style: normalizeStyle({ width: "calc(100% - 32px - " + xPadding.value + " - " + xPadding.value + ")" })
          }, [
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_1$q, toDisplayString(operationType.value), 1),
              createBaseVNode("div", _hoisted_2$p, [
                createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(operation.value.certificateHash || "", 8)), 1),
                createBaseVNode("div", _hoisted_3$l, [
                  createVNode(QIcon, {
                    name: "bi-copy",
                    size: "12px",
                    style: { marginBottom: "3px" },
                    onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(operation.value.certificateHash, evt), ["stop"]))
                  })
                ])
              ]),
              createBaseVNode("div", _hoisted_4$h, toDisplayString(unref(date).formatDate(operation.value.createdAt, "YYYY/MM/DD HH:mm:ss")), 1)
            ]),
            createVNode(QSpace),
            createBaseVNode("div", null, [
              operation.value.operationType === unref(dbModel).OperationType.TRANSFER ? (openBlock(), createElementBlock("div", _hoisted_5$g, toDisplayString(transferAmount.value.toFixed(4)) + " " + toDisplayString(token2.value?.ticker), 1)) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_6$d, [
                createVNode(QSpace),
                createBaseVNode("div", {
                  class: normalizeClass([operation.value.state === unref(dbModel).OperationState.FAILED ? "text-red-6" : "text-green"])
                }, toDisplayString(unref(dbModel).OperationState[operation.value.state]), 3)
              ])
            ])
          ], 4)
        ]),
        _: 1
      }, 8, ["style"]);
    };
  }
});
const _hoisted_1$p = { class: "fill-parent text-center" };
const _hoisted_2$o = { key: 0 };
const _hoisted_3$k = ["onClick"];
const _hoisted_4$g = {
  key: 1,
  class: "page-item-placeholder"
};
const _hoisted_5$f = ["innerHTML"];
const _sfc_main$x = defineComponent({
  __name: "ChainOperationsView",
  props: {
    microchain: {},
    xPadding: {}
  },
  setup(__props) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const xPadding = toRef(props, "xPadding");
    const chainOperations = ref([]);
    const displayCount = ref(4);
    const displayChainOperations = computed(() => {
      return [...chainOperations.value].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, displayCount.value);
    });
    const loadChainOperationsRecursive = async (total, offset, limit) => {
      if (offset >= total)
        return;
      chainOperations.value.push(...await ChainOperation.chainOperations(offset, limit, microchain.value) || []);
      void loadChainOperationsRecursive(total, offset + limit, limit);
    };
    const loadChainOperations = async () => {
      chainOperations.value = [];
      const count = await ChainOperation.count();
      await loadChainOperationsRecursive(count, 0, 10);
    };
    onMounted(() => {
      void loadChainOperations();
    });
    const onChainOperationClick = (operation) => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_OPERATION;
      localStore.setting.HomeActionParams = operation;
    };
    const onViewMoreClick = () => {
      displayCount.value += 4;
      displayCount.value = Math.min(displayCount.value, chainOperations.value.length);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$p, [
        createVNode(QSpace),
        chainOperations.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_2$o, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(displayChainOperations.value, (chainOperation) => {
            return openBlock(), createElementBlock("div", {
              key: chainOperation.id,
              onClick: ($event) => onChainOperationClick(chainOperation)
            }, [
              createVNode(_sfc_main$y, {
                operation: chainOperation,
                "x-padding": xPadding.value
              }, null, 8, ["operation", "x-padding"])
            ], 8, _hoisted_3$k);
          }), 128)),
          displayCount.value < chainOperations.value.length ? (openBlock(), createBlock(QBtn, {
            key: 0,
            rounded: "",
            flat: "",
            "no-caps": "",
            class: "full-width bg-grey-1",
            onClick: onViewMoreClick,
            color: "grey-6",
            label: _ctx.$t("MSG_VIEW_MORE_THREE_DOTS")
          }, null, 8, ["label"])) : createCommentVNode("", true)
        ])) : (openBlock(), createElementBlock("div", _hoisted_4$g, [
          createBaseVNode("div", null, [
            createVNode(QIcon, {
              name: "bi-plus-circle",
              size: "48px",
              color: "grey-4"
            })
          ]),
          createBaseVNode("div", {
            class: "page-item-y-margin-top",
            innerHTML: _ctx.$t("MSG_NEW_TO_LINERA_TRANSFER_TOKENS")
          }, null, 8, _hoisted_5$f)
        ])),
        createVNode(QSpace)
      ]);
    };
  }
});
const _hoisted_1$o = { class: "vertical-items-margin" };
const _hoisted_2$n = { class: "vertical-items-margin" };
const _hoisted_3$j = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_4$f = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_5$e = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_6$c = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_7$c = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_8$c = { class: "microchain-detail-value-text text-right" };
const _hoisted_9$c = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_10$9 = { class: "word-break-all row microchain-detail-value" };
const _hoisted_11$9 = { class: "full-width text-right" };
const _hoisted_12$7 = { class: "extra-large-bottom-margin" };
const _hoisted_13$5 = { class: "extra-large-bottom-margin" };
const _sfc_main$w = defineComponent({
  __name: "MicrochainDetailInnerView",
  props: {
    microchain: {}
  },
  setup(__props) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const chainTokenBalance = ref(0);
    const chainUsdBalance = ref(0);
    const accountTokenBalance = ref(0);
    const accountUsdBalance = ref(0);
    const activities = ref([]);
    const selectedOwner = ref(void 0);
    const nativeTokenId = ref(void 0);
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", null, [
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_CHAIN_BALANCE")), 3),
          createBaseVNode("div", _hoisted_1$o, [
            createVNode(_sfc_main$13, {
              microchain: microchain.value,
              "show-account-balance": false,
              "integrated-mode": false,
              clickable: false,
              "show-indicator": false,
              "x-padding": unref(localStore).setting.extensionMode ? "8px" : "0"
            }, null, 8, ["microchain", "x-padding"])
          ]),
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_ACCOUNT_BALANCE")), 3),
          createBaseVNode("div", _hoisted_2$n, [
            createVNode(_sfc_main$13, {
              microchain: microchain.value,
              "show-account-balance": true,
              "integrated-mode": false,
              clickable: false,
              "show-indicator": false,
              "x-padding": unref(localStore).setting.extensionMode ? "8px" : "0"
            }, null, 8, ["microchain", "x-padding"])
          ]),
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_CHAIN_DETAILS")), 3),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_3$j, toDisplayString(_ctx.$t("MSG_MICROCHAIN_ID")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_4$f, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_5$e, toDisplayString(microchain.value.microchain), 1),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(microchain.value.microchain, evt), ["stop"]))
              })
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_6$c, toDisplayString(_ctx.$t("MSG_CREATOR_CHAIN_ID")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_7$c, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_8$c, toDisplayString(microchain.value.creatorChainId), 1),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[1] || (_cache[1] = withModifiers((evt) => unref(_copyToClipboard)(microchain.value.creatorChainId, evt), ["stop"]))
              })
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_9$c, toDisplayString(_ctx.$t("MSG_DEFAULT_CHAIN")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_10$9, [
              createBaseVNode("div", _hoisted_11$9, toDisplayString(microchain.value.default ? "YES" : "NO"), 1)
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_CHAIN_OPERATIONS")), 3),
          createBaseVNode("div", _hoisted_12$7, [
            createVNode(_sfc_main$x, { "x-padding": "8px" })
          ]),
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_CHAIN_ACTIVITIES")), 3),
          createBaseVNode("div", _hoisted_13$5, [
            createVNode(_sfc_main$B, { "x-padding": "8px" })
          ])
        ]),
        createVNode(_sfc_main$14, {
          "token-id": nativeTokenId.value,
          "token-balance": chainTokenBalance.value,
          "onUpdate:tokenBalance": _cache[2] || (_cache[2] = ($event) => chainTokenBalance.value = $event),
          "usd-balance": chainUsdBalance.value,
          "onUpdate:usdBalance": _cache[3] || (_cache[3] = ($event) => chainUsdBalance.value = $event)
        }, null, 8, ["token-id", "token-balance", "usd-balance"]),
        createVNode(_sfc_main$15, {
          "token-id": nativeTokenId.value,
          "token-balance": accountTokenBalance.value,
          "onUpdate:tokenBalance": _cache[4] || (_cache[4] = ($event) => accountTokenBalance.value = $event),
          "usd-balance": accountUsdBalance.value,
          "onUpdate:usdBalance": _cache[5] || (_cache[5] = ($event) => accountUsdBalance.value = $event),
          owner: selectedOwner.value?.owner,
          "microchain-id": microchain.value.microchain
        }, null, 8, ["token-id", "token-balance", "usd-balance", "owner", "microchain-id"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[6] || (_cache[6] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        createVNode(_sfc_main$D, {
          activities: activities.value,
          "onUpdate:activities": _cache[7] || (_cache[7] = ($event) => activities.value = $event),
          microchain: microchain.value.microchain
        }, null, 8, ["activities", "microchain"])
      ], 64);
    };
  }
});
const _hoisted_1$n = { class: "row" };
const _hoisted_2$m = { class: "text-center text-grey-6 selector-title page-item-x-margin-left setting-action" };
const _hoisted_3$i = { class: "row vertical-sections-margin" };
const _hoisted_4$e = { class: "row bg-red-1 tip cursor-pointer label-radius" };
const _hoisted_5$d = { class: "page-item-x-margin-left" };
const _hoisted_6$b = { class: "home-token-balance text-center microchain-token-balance" };
const _hoisted_7$b = { class: "row home-token-action text-center page-y-padding" };
const _hoisted_8$b = { class: "page-item-y-margin-top" };
const _hoisted_9$b = { class: "page-item-y-margin-top" };
const _hoisted_10$8 = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_11$8 = { class: "page-item-y-margin-top" };
const _hoisted_12$6 = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_13$4 = { class: "page-item-y-margin-top" };
const _sfc_main$v = defineComponent({
  __name: "MicrochainDetailView",
  props: {
    microchain: {}
  },
  emits: ["back", "close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const chainTokenBalance = ref(0);
    const chainUsdBalance = ref(0);
    const accountTokenBalance = ref(0);
    const accountUsdBalance = ref(0);
    const selectedOwner = ref(void 0);
    const emit = __emit;
    const onBackClick = () => {
      emit("back");
    };
    const onCloseClick = () => {
      emit("close");
    };
    const nativeTokenId = ref(void 0);
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    const router = useRouter();
    const onTransferClick = () => {
      void router.push({
        path: localStore.setting.formalizePath("/transfer"),
        query: {
          fromMicrochainId: microchain.value.microchain
        }
      });
    };
    const onSwapClick = () => {
      window.open("http://testnet-conway.lineraswap.fun");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", null, [
          createBaseVNode("div", _hoisted_1$n, [
            createVNode(QIcon, {
              name: "bi-arrow-left-short",
              size: "24px",
              class: "cursor-pointer text-grey-6",
              onClick: onBackClick
            }),
            createBaseVNode("p", _hoisted_2$m, toDisplayString(microchain.value.name || "Microchain information"), 1),
            createVNode(QSpace),
            createVNode(QIcon, {
              name: "bi-x",
              size: "24px",
              class: "cursor-pointer",
              onClick: onCloseClick
            })
          ]),
          createBaseVNode("div", _hoisted_3$i, [
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_4$e, [
              createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(microchain.value.microchain, 10)), 1),
              createBaseVNode("div", _hoisted_5$d, [
                createVNode(QIcon, {
                  name: "bi-copy",
                  size: "16px",
                  style: { marginTop: "-3px" },
                  onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(microchain.value.microchain, evt), ["stop"]))
                })
              ])
            ]),
            createVNode(QSpace)
          ]),
          createBaseVNode("div", _hoisted_6$b, [
            createTextVNode(" $ " + toDisplayString((chainUsdBalance.value + accountUsdBalance.value).toFixed(4)) + " ", 1),
            createBaseVNode("div", _hoisted_7$b, [
              createVNode(QSpace),
              createBaseVNode("div", {
                class: "home-token-action-btn cursor-pointer",
                onClick: onTransferClick
              }, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-arrow-up-right",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_8$b, toDisplayString(_ctx.$t("MSG_TRANSFER")), 1)
              ]),
              createBaseVNode("div", {
                class: "home-token-action-btn cursor-pointer",
                onClick: onSwapClick
              }, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-arrow-repeat",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_9$b, toDisplayString(_ctx.$t("MSG_SWAP")), 1)
              ]),
              createBaseVNode("div", _hoisted_10$8, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-arrow-left-right",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_11$8, toDisplayString(_ctx.$t("MSG_BRIDGE")), 1)
              ]),
              createBaseVNode("div", _hoisted_12$6, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-clock",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_13$4, toDisplayString(_ctx.$t("MSG_STAKE")), 1)
              ]),
              createVNode(QSpace)
            ])
          ]),
          createVNode(_sfc_main$w, { microchain: microchain.value }, null, 8, ["microchain"])
        ]),
        createVNode(_sfc_main$14, {
          "token-id": nativeTokenId.value,
          "token-balance": chainTokenBalance.value,
          "onUpdate:tokenBalance": _cache[1] || (_cache[1] = ($event) => chainTokenBalance.value = $event),
          "usd-balance": chainUsdBalance.value,
          "onUpdate:usdBalance": _cache[2] || (_cache[2] = ($event) => chainUsdBalance.value = $event)
        }, null, 8, ["token-id", "token-balance", "usd-balance"]),
        createVNode(_sfc_main$15, {
          "token-id": nativeTokenId.value,
          "token-balance": accountTokenBalance.value,
          "onUpdate:tokenBalance": _cache[3] || (_cache[3] = ($event) => accountTokenBalance.value = $event),
          "usd-balance": accountUsdBalance.value,
          "onUpdate:usdBalance": _cache[4] || (_cache[4] = ($event) => accountUsdBalance.value = $event),
          owner: selectedOwner.value?.owner,
          "microchain-id": microchain.value.microchain
        }, null, 8, ["token-id", "token-balance", "usd-balance", "owner", "microchain-id"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[5] || (_cache[5] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"])
      ], 64);
    };
  }
});
const _hoisted_1$m = { class: "full-width tab-panel-item" };
const _hoisted_2$l = {
  key: 0,
  class: "row decorate-underline-dashed"
};
const _hoisted_3$h = { class: "row" };
const _hoisted_4$d = {
  class: "word-break-all page-item-x-margin-left",
  style: { width: "calc(100% - 52px)" }
};
const _hoisted_5$c = {
  key: 1,
  class: "vertical-items-margin row decorate-underline-dashed"
};
const _hoisted_6$a = { class: "row" };
const _hoisted_7$a = {
  class: "word-break-all page-item-x-margin-left",
  style: { width: "calc(100% - 52px)" }
};
const _hoisted_8$a = { class: "row vertical-items-margin" };
const _hoisted_9$a = { class: "text-bold text-grey-9" };
const _hoisted_10$7 = { class: "selector-item-currency-sub" };
const _hoisted_11$7 = { class: "page-item-x-margin-left" };
const _hoisted_12$5 = { class: "text-grey-6 selector-item-currency-sub" };
const _sfc_main$u = defineComponent({
  __name: "TokenBalanceCardView",
  props: {
    token: {},
    chainBalance: { default: void 0 },
    ownerBalance: { default: void 0 },
    xPadding: { default: "0" }
  },
  setup(__props) {
    const props = __props;
    const token2 = toRef(props, "token");
    const chainBalance = toRef(props, "chainBalance");
    const ownerBalance = toRef(props, "ownerBalance");
    const xPadding = toRef(props, "xPadding");
    const tokenBalance = computed(() => chainBalance.value?.balance || ownerBalance.value?.balance || 0);
    const usdBalance = computed(() => tokenBalance.value * token2.value.usdCurrency || 0);
    const microchain = computed(() => chainBalance.value?.microchain || ownerBalance.value?.microchain);
    const owner = computed(() => ownerBalance.value?.owner);
    const selectedOwner = ref(void 0);
    const _microchain = ref(void 0);
    onMounted(async () => {
      _microchain.value = await Microchain$1.microchain(microchain.value);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        style: normalizeStyle({ paddingLeft: xPadding.value, paddingRight: xPadding.value })
      }, [
        createBaseVNode("div", _hoisted_1$m, [
          createBaseVNode("div", null, [
            _microchain.value ? (openBlock(), createElementBlock("div", _hoisted_2$l, [
              createBaseVNode("div", _hoisted_3$h, [
                createVNode(QImg, {
                  src: unref(microchainLogo),
                  width: "20px",
                  height: "20px"
                }, null, 8, ["src"]),
                createVNode(QAvatar, {
                  size: "20px",
                  class: "page-item-x-margin-left"
                }, {
                  default: withCtx(() => [
                    createVNode(QImg, {
                      src: unref(dbModel).microchainAvatar(_microchain.value),
                      width: "20px",
                      height: "20px"
                    }, null, 8, ["src"])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("div", _hoisted_4$d, toDisplayString(_microchain.value.microchain), 1)
            ])) : createCommentVNode("", true),
            owner.value && selectedOwner.value ? (openBlock(), createElementBlock("div", _hoisted_5$c, [
              createBaseVNode("div", _hoisted_6$a, [
                createVNode(QAvatar, { size: "20px" }, {
                  default: withCtx(() => [
                    owner.value && selectedOwner.value ? (openBlock(), createBlock(QImg, {
                      key: 0,
                      src: unref(dbModel).ownerAvatar(selectedOwner.value),
                      width: "20px",
                      height: "20px"
                    }, null, 8, ["src"])) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                _cache[1] || (_cache[1] = createBaseVNode("div", { style: { marginLeft: "20px" } }, null, -1))
              ]),
              createBaseVNode("div", _hoisted_7$a, toDisplayString(selectedOwner.value.owner), 1)
            ])) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_8$a, [
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_9$a, [
              createTextVNode(toDisplayString(parseFloat(tokenBalance.value.toFixed(4))) + " ", 1),
              createBaseVNode("span", _hoisted_10$7, toDisplayString(token2.value.ticker), 1)
            ]),
            _cache[2] || (_cache[2] = createBaseVNode("div", { class: "page-item-x-margin-left" }, " \u2248 ", -1)),
            createBaseVNode("div", _hoisted_11$7, [
              createTextVNode(" $ " + toDisplayString(parseFloat(usdBalance.value.toFixed(4))) + " ", 1),
              createBaseVNode("span", _hoisted_12$5, toDisplayString(_ctx.$t("MSG_USD")), 1)
            ])
          ]),
          createVNode(_sfc_main$Y, {
            "selected-owner": selectedOwner.value,
            "onUpdate:selectedOwner": _cache[0] || (_cache[0] = ($event) => selectedOwner.value = $event)
          }, null, 8, ["selected-owner"])
        ]),
        createVNode(QSeparator)
      ], 4);
    };
  }
});
const _hoisted_1$l = { class: "row vertical-items-margin" };
const _hoisted_2$k = {
  class: "page-x-padding selector-y-padding selector-margin-x-left",
  style: { width: "calc(100% - 128px - 12px - 12px)" }
};
const _hoisted_3$g = ["innerHTML"];
const _hoisted_4$c = { class: "row vertical-sections-margin" };
const _hoisted_5$b = { key: 2 };
const _hoisted_6$9 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_7$9 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_8$9 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_9$9 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_10$6 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_11$6 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_12$4 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_13$3 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_14$3 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_15$2 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_16$2 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_17$2 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_18$2 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_19$2 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_20$2 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_21$2 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_22$2 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_23$2 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_24$2 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_25$2 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_26$2 = ["href"];
const _hoisted_27$2 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_28$2 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_29$2 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_30$1 = ["href"];
const _hoisted_31$1 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_32$1 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_33 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_34 = ["href"];
const _hoisted_35 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_36 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_37 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_38 = ["href"];
const _hoisted_39 = { class: "microchain-detail-label text-grey-8 flex items-center" };
const _hoisted_40 = { class: "word-break-all row microchain-detail-value flex items-center justify-center row" };
const _hoisted_41 = { class: "word-break-all microchain-detail-value-text text-right" };
const _hoisted_42 = ["href"];
const _sfc_main$t = defineComponent({
  __name: "TokenDetailInnerView",
  props: {
    token: {}
  },
  setup(__props) {
    const props = __props;
    const token2 = toRef(props, "token");
    const selectedOwner = ref(void 0);
    const ownerBalances = ref([]);
    const chainBalances = ref([]);
    const tokenBalance = ref(0);
    const tokenLogo = ref("");
    watch(selectedOwner, async () => {
      if (selectedOwner.value) {
        ownerBalances.value = await MicrochainOwnerFungibleTokenBalance.balances(selectedOwner.value?.owner, token2.value.id);
        chainBalances.value = await MicrochainFungibleTokenBalance.balances(selectedOwner.value?.owner, token2.value.id);
      }
    });
    watch(tokenBalance, async () => {
      if (selectedOwner.value) {
        ownerBalances.value = await MicrochainOwnerFungibleTokenBalance.balances(selectedOwner.value?.owner, token2.value.id);
        chainBalances.value = await MicrochainFungibleTokenBalance.balances(selectedOwner.value?.owner, token2.value.id);
      }
    });
    onMounted(async () => {
      if (selectedOwner.value) {
        ownerBalances.value = await MicrochainOwnerFungibleTokenBalance.balances(selectedOwner.value.owner, token2.value.id);
        chainBalances.value = await MicrochainFungibleTokenBalance.balances(selectedOwner.value.owner, token2.value.id);
      }
      tokenLogo.value = await Token.logo(token2.value.id);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", null, [
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_TOKEN_INFORMATION")), 3),
          createBaseVNode("div", _hoisted_1$l, [
            createVNode(QImg, {
              src: tokenLogo.value,
              width: "128px",
              fit: "contain",
              class: "page-item-x-margin-left"
            }, null, 8, ["src"]),
            createBaseVNode("div", _hoisted_2$k, [
              createBaseVNode("div", {
                innerHTML: token2.value.description?.length > 0 ? token2.value.description : "The creator <strong>DID NOT</strong> leave any description to the token! Please make sure you know the <strong>RISK</strong> to interact with the token!"
              }, null, 8, _hoisted_3$g),
              createBaseVNode("div", _hoisted_4$c, [
                token2.value.github?.length ? (openBlock(), createBlock(QImg, {
                  key: 0,
                  src: unref(githubLogo),
                  width: "20px",
                  height: "20px",
                  class: "cursor-pointer clickable selector-margin-x-right"
                }, null, 8, ["src"])) : createCommentVNode("", true),
                token2.value.discord?.length ? (openBlock(), createBlock(QImg, {
                  key: 1,
                  src: unref(discordLogo),
                  width: "20px",
                  height: "20px",
                  class: "cursor-pointer clickable selector-margin-x-right"
                }, null, 8, ["src"])) : createCommentVNode("", true),
                token2.value.twitter?.length ? (openBlock(), createBlock(QImg, {
                  key: 2,
                  src: unref(twitterLogo),
                  width: "20px",
                  height: "20px",
                  class: "cursor-pointer clickable selector-margin-x-right"
                }, null, 8, ["src"])) : createCommentVNode("", true),
                token2.value.telegram?.length ? (openBlock(), createBlock(QImg, {
                  key: 3,
                  src: unref(telegramLogo),
                  width: "20px",
                  height: "20px",
                  class: "cursor-pointer clickable selector-margin-x-right"
                }, null, 8, ["src"])) : createCommentVNode("", true),
                token2.value.website?.length ? (openBlock(), createBlock(QImg, {
                  key: 4,
                  src: unref(githubLogo),
                  width: "20px",
                  height: "20px",
                  class: "cursor-pointer clickable"
                }, null, 8, ["src"])) : createCommentVNode("", true)
              ])
            ])
          ]),
          !token2.value.native ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_TOKEN_PRICE")), 3)) : createCommentVNode("", true),
          ownerBalances.value.length || chainBalances.value.length ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_BALANCES")), 3)) : createCommentVNode("", true),
          ownerBalances.value.length || chainBalances.value.length ? (openBlock(), createElementBlock("div", _hoisted_5$b, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(ownerBalances.value, (balance) => {
              return openBlock(), createBlock(_sfc_main$u, {
                key: balance.id,
                token: token2.value,
                "show-indicator": false,
                "owner-balance": balance,
                "x-padding": unref(localStore).setting.extensionMode ? "8px" : "0"
              }, null, 8, ["token", "owner-balance", "x-padding"]);
            }), 128)),
            (openBlock(true), createElementBlock(Fragment, null, renderList(chainBalances.value, (balance) => {
              return openBlock(), createBlock(_sfc_main$u, {
                key: balance.id,
                token: token2.value,
                "show-indicator": false,
                "chain-balance": balance,
                "x-padding": unref(localStore).setting.extensionMode ? "8px" : "0"
              }, null, 8, ["token", "chain-balance", "x-padding"]);
            }), 128))
          ])) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(["vertical-sections-margin text-bold label-text-large text-grey-9 decorate-underline", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, toDisplayString(_ctx.$t("MSG_TOKEN_DETAILS")), 3),
          !token2.value.native ? (openBlock(), createElementBlock("div", {
            key: 3,
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_6$9, toDisplayString(_ctx.$t("MSG_APPLICATION_ID")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_7$9, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_8$9, toDisplayString(token2.value.applicationId), 1),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.applicationId, evt), ["stop"]))
              })
            ])
          ], 2)) : createCommentVNode("", true),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_9$9, toDisplayString(_ctx.$t("MSG_TOKEN_NAME")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_10$6, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_11$6, toDisplayString(token2.value.name), 1)
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_12$4, toDisplayString(_ctx.$t("MSG_TOKEN_TYPE")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_13$3, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_14$3, toDisplayString(token2.value.tokenType), 1)
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_15$2, toDisplayString(_ctx.$t("MSG_TOKEN_SYMBOL")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_16$2, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_17$2, toDisplayString(token2.value.ticker), 1)
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_18$2, toDisplayString(_ctx.$t("MSG_TOKEN_LOGO")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_19$2, [
              createVNode(QSpace),
              createVNode(QImg, {
                src: tokenLogo.value,
                width: "32px",
                height: "32px",
                fit: "contain"
              }, null, 8, ["src"])
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_20$2, toDisplayString(_ctx.$t("MSG_TOTAL_SUPPLY")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_21$2, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_22$2, toDisplayString(token2.value.totalSupply), 1)
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_23$2, toDisplayString(_ctx.$t("MSG_GITHUB")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_24$2, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_25$2, [
                createBaseVNode("a", {
                  href: token2.value.github
                }, toDisplayString(token2.value.github), 9, _hoisted_26$2)
              ]),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[1] || (_cache[1] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.github, evt), ["stop"]))
              })
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_27$2, toDisplayString(_ctx.$t("MSG_OFFICIAL_WEBSITE")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_28$2, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_29$2, [
                createBaseVNode("a", {
                  href: token2.value.website
                }, toDisplayString(token2.value.website), 9, _hoisted_30$1)
              ]),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[2] || (_cache[2] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.website, evt), ["stop"]))
              })
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_31$1, toDisplayString(_ctx.$t("MSG_TELEGRAM")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_32$1, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_33, [
                createBaseVNode("a", {
                  href: token2.value.telegram
                }, toDisplayString(token2.value.telegram), 9, _hoisted_34)
              ]),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[3] || (_cache[3] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.telegram, evt), ["stop"]))
              })
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_35, toDisplayString(_ctx.$t("MSG_TWITTER")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_36, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_37, [
                createBaseVNode("a", {
                  href: token2.value.twitter
                }, toDisplayString(token2.value.twitter), 9, _hoisted_38)
              ]),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[4] || (_cache[4] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.twitter, evt), ["stop"]))
              })
            ])
          ], 2),
          createBaseVNode("div", {
            class: normalizeClass(["row decorate-underline-dashed vertical-menus-margin cursor-pointer microchain-detail-line", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createBaseVNode("div", _hoisted_39, toDisplayString(_ctx.$t("MSG_DISCORD")), 1),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_40, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_41, [
                createBaseVNode("a", {
                  href: token2.value.discord
                }, toDisplayString(token2.value.discord), 9, _hoisted_42)
              ]),
              createVNode(QIcon, {
                name: "bi-copy",
                size: "12px",
                class: "microchain-detail-copy-icon page-item-x-margin-left",
                onClick: _cache[5] || (_cache[5] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.discord, evt), ["stop"]))
              })
            ])
          ], 2)
        ]),
        createVNode(_sfc_main$Z, {
          "token-balance": tokenBalance.value,
          "onUpdate:tokenBalance": _cache[6] || (_cache[6] = ($event) => tokenBalance.value = $event),
          "token-id": token2.value.id
        }, null, 8, ["token-balance", "token-id"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[7] || (_cache[7] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"])
      ], 64);
    };
  }
});
const _hoisted_1$k = { class: "row" };
const _hoisted_2$j = { class: "text-center text-grey-6 selector-title page-item-x-margin-left setting-action" };
const _hoisted_3$f = {
  key: 0,
  class: "row vertical-sections-margin"
};
const _hoisted_4$b = { class: "row bg-red-1 tip cursor-pointer label-radius" };
const _hoisted_5$a = { class: "page-item-x-margin-left" };
const _hoisted_6$8 = { class: "home-token-balance text-center microchain-token-balance" };
const _hoisted_7$8 = { class: "row home-token-action text-center page-y-padding" };
const _hoisted_8$8 = { class: "page-item-y-margin-top" };
const _hoisted_9$8 = { class: "page-item-y-margin-top" };
const _hoisted_10$5 = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_11$5 = { class: "page-item-y-margin-top" };
const _hoisted_12$3 = {
  class: "home-token-action-btn cursor-pointer",
  disabled: ""
};
const _hoisted_13$2 = { class: "page-item-y-margin-top" };
const _hoisted_14$2 = { class: "extra-margin-bottom" };
const _sfc_main$s = defineComponent({
  __name: "TokenDetailView",
  props: {
    token: {}
  },
  emits: ["back", "close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const token2 = toRef(props, "token");
    const accountTokenBalance = ref(0);
    const accountUsdBalance = ref(0);
    const selectedOwner = ref(void 0);
    const emit = __emit;
    const onBackClick = () => {
      emit("back");
    };
    const onCloseClick = () => {
      emit("close");
    };
    const router = useRouter();
    const onTransferClick = () => {
      void router.push({
        path: localStore.setting.formalizePath("/transfer"),
        query: {
          applicationId: token2.value.applicationId
        }
      });
    };
    const onSwapClick = () => {
      window.open("https://testnet-conway.lineraswap.fun");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", null, [
          createBaseVNode("div", _hoisted_1$k, [
            createVNode(QIcon, {
              name: "bi-arrow-left-short",
              size: "24px",
              class: "cursor-pointer text-grey-6",
              onClick: onBackClick
            }),
            createBaseVNode("p", _hoisted_2$j, toDisplayString(token2.value.name || "Token information"), 1),
            createVNode(QSpace),
            createVNode(QIcon, {
              name: "bi-x",
              size: "24px",
              class: "cursor-pointer",
              onClick: onCloseClick
            })
          ]),
          !token2.value.native ? (openBlock(), createElementBlock("div", _hoisted_3$f, [
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_4$b, [
              createBaseVNode("div", null, " 0x" + toDisplayString(unref(shortid).shortId(token2.value?.applicationId, 16)), 1),
              createBaseVNode("div", _hoisted_5$a, [
                createVNode(QIcon, {
                  name: "bi-copy",
                  size: "16px",
                  style: { marginTop: "-3px" },
                  onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(token2.value.applicationId, evt), ["stop"]))
                })
              ])
            ]),
            createVNode(QSpace)
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_6$8, [
            createTextVNode(toDisplayString(accountTokenBalance.value.toFixed(4)) + " " + toDisplayString(token2.value.ticker) + " ", 1),
            createBaseVNode("div", _hoisted_7$8, [
              createVNode(QSpace),
              createBaseVNode("div", {
                class: "home-token-action-btn cursor-pointer",
                onClick: onTransferClick
              }, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-arrow-up-right",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_8$8, toDisplayString(_ctx.$t("MSG_TRANSFER")), 1)
              ]),
              createBaseVNode("div", {
                class: "home-token-action-btn cursor-pointer",
                onClick: onSwapClick
              }, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-arrow-repeat",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_9$8, toDisplayString(_ctx.$t("MSG_SWAP")), 1)
              ]),
              createBaseVNode("div", _hoisted_10$5, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-arrow-left-right",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_11$5, toDisplayString(_ctx.$t("MSG_BRIDGE")), 1)
              ]),
              createBaseVNode("div", _hoisted_12$3, [
                createVNode(QAvatar, {
                  color: "red-2",
                  size: "36px"
                }, {
                  default: withCtx(() => [
                    createVNode(QIcon, {
                      name: "bi-clock",
                      size: "24px"
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("div", _hoisted_13$2, toDisplayString(_ctx.$t("MSG_STAKE")), 1)
              ]),
              createVNode(QSpace)
            ])
          ]),
          createBaseVNode("div", _hoisted_14$2, [
            createVNode(_sfc_main$t, { token: token2.value }, null, 8, ["token"])
          ])
        ]),
        createVNode(_sfc_main$Z, {
          "token-id": token2.value?.id,
          "token-balance": accountTokenBalance.value,
          "onUpdate:tokenBalance": _cache[1] || (_cache[1] = ($event) => accountTokenBalance.value = $event),
          "usd-balance": accountUsdBalance.value,
          "onUpdate:usdBalance": _cache[2] || (_cache[2] = ($event) => accountUsdBalance.value = $event)
        }, null, 8, ["token-id", "token-balance", "usd-balance"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[3] || (_cache[3] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"])
      ], 64);
    };
  }
});
const _hoisted_1$j = { class: "row" };
const _hoisted_2$i = { class: "text-center text-grey-6 selector-title page-item-x-margin-left setting-action" };
const _hoisted_3$e = { class: "row items-x-margin" };
const _hoisted_4$a = { class: "text-grey-9" };
const _hoisted_5$9 = { class: "text-green-8" };
const _hoisted_6$7 = { class: "row vertical-items-margin items-x-margin" };
const _hoisted_7$7 = { class: "text-grey-9" };
const _hoisted_8$7 = { class: "text-grey-6" };
const _hoisted_9$7 = { class: "page-item-x-margin-left cursor-pointer" };
const _hoisted_10$4 = { class: "vertical-menus-margin decorate-underline text-bold items-x-margin" };
const _hoisted_11$4 = { class: "vertical-menus-margin transfer-tip items-x-margin cursor-pointer" };
const _hoisted_12$2 = { class: "setting-item word-break-all" };
const _hoisted_13$1 = {
  class: "row vertical-items-margin",
  style: { marginTop: "-24px" }
};
const _hoisted_14$1 = {
  key: 0,
  class: "vertical-menus-margin transfer-tip items-x-margin cursor-pointer"
};
const _hoisted_15$1 = { class: "setting-item word-break-all" };
const _hoisted_16$1 = {
  class: "row vertical-items-margin",
  style: { marginTop: "-24px" }
};
const _hoisted_17$1 = { class: "vertical-menus-margin decorate-underline text-bold items-x-margin" };
const _hoisted_18$1 = { class: "vertical-menus-margin transfer-tip items-x-margin cursor-pointer" };
const _hoisted_19$1 = { class: "setting-item word-break-all" };
const _hoisted_20$1 = {
  class: "row vertical-items-margin",
  style: { marginTop: "-24px" }
};
const _hoisted_21$1 = {
  key: 1,
  class: "vertical-items-margin transfer-tip items-x-margin cursor-pointer"
};
const _hoisted_22$1 = { class: "setting-item word-break-all" };
const _hoisted_23$1 = {
  class: "row vertical-items-margin",
  style: { marginTop: "-24px" }
};
const _hoisted_24$1 = { class: "vertical-menus-margin decorate-underline text-bold items-x-margin" };
const _hoisted_25$1 = { class: "row vertical-menus-margin decorate-underline-dashed items-x-margin" };
const _hoisted_26$1 = { class: "row vertical-items-margin decorate-underline-dashed items-x-margin" };
const _hoisted_27$1 = { class: "row vertical-items-margin decorate-underline-dashed items-x-margin" };
const _hoisted_28$1 = { class: "row vertical-items-margin decorate-underline-dashed items-x-margin" };
const _hoisted_29$1 = { class: "row vertical-items-margin decorate-underline-dashed word-break-all items-x-margin" };
const _hoisted_30 = { style: { width: "128px" } };
const _hoisted_31 = {
  class: "text-right",
  style: { width: "calc(100% - 128px)" }
};
const _hoisted_32 = { class: "row extra-margin-bottom vertical-items-margin decorate-underline-dashed items-x-margin" };
const _sfc_main$r = defineComponent({
  __name: "ActivityDetailView",
  props: {
    activity: {}
  },
  emits: ["back", "close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const activity = toRef(props, "activity");
    const selectedOwner = ref(void 0);
    const microchainOwners = ref([]);
    const sourceOwner = ref(void 0);
    const sourceMicrochain = ref(void 0);
    const targetOwner = ref(void 0);
    const targetMicrochain = ref(void 0);
    const token2 = ref(void 0);
    const action = computed(() => {
      if (activity.value.sourceAddress === activity.value.targetAddress) {
        return "Move";
      }
      if (activity.value.microchain === activity.value.sourceChain) {
        return "Send";
      }
      if (activity.value.microchain === activity.value.targetChain) {
        return "Receive";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0 && microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "Move";
      }
      if (selectedOwner.value?.owner === activity.value.sourceAddress) {
        return "Send";
      }
      if (selectedOwner.value?.owner === activity.value.targetAddress) {
        return "Receive";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.sourceChain) >= 0) {
        return "Send";
      }
      if (microchainOwners.value.findIndex((el) => el.microchain === activity.value.targetChain) >= 0) {
        return "Receive";
      }
      return "Unknown";
    });
    const emit = __emit;
    const onBackClick = () => {
      emit("back");
    };
    const onCloseClick = () => {
      emit("close");
    };
    const blockHeight = computed(() => {
      try {
        return parse(JSON.stringify(activity.value.blockHeight)).value;
      } catch {
        return activity.value.blockHeight;
      }
    });
    const timestamp = computed(() => {
      try {
        return date.formatDate(Number(parse(JSON.stringify(activity.value.timestamp)).value) / 1e3, "YYYY/MM/DD HH:mm:ss");
      } catch {
        return date.formatDate(activity.value.timestamp / 1e3, "YYYY/MM/DD HH:mm:ss");
      }
    });
    onMounted(async () => {
      if (activity.value.sourceAddress?.length) {
        const address = activity.value.sourceAddress.includes(":") ? activity.value.sourceAddress.split(":")[1] : activity.value.sourceAddress;
        sourceOwner.value = await Owner.owner(address);
      }
      sourceMicrochain.value = await Microchain$1.microchain(activity.value.sourceChain);
      if (activity.value.targetAddress?.length) {
        const address = activity.value.targetAddress.includes(":") ? activity.value.targetAddress.split(":")[1] : activity.value.targetAddress;
        targetOwner.value = await Owner.owner(address);
      }
      targetMicrochain.value = await Microchain$1.microchain(activity.value.targetChain);
      token2.value = await Token.tokenWithId(activity.value.tokenId || 1);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", null, [
          createBaseVNode("div", _hoisted_1$j, [
            createVNode(QIcon, {
              name: "bi-arrow-left-short",
              size: "24px",
              class: "cursor-pointer text-grey-6",
              onClick: onBackClick
            }),
            createBaseVNode("p", _hoisted_2$i, toDisplayString(action.value), 1),
            createVNode(QSpace),
            createVNode(QIcon, {
              name: "bi-x",
              size: "24px",
              class: "cursor-pointer",
              onClick: onCloseClick
            })
          ]),
          createBaseVNode("div", _hoisted_3$e, [
            createBaseVNode("div", _hoisted_4$a, [
              createBaseVNode("strong", null, toDisplayString(_ctx.$t("MSG_STATUS")), 1)
            ]),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_5$9, [
              createBaseVNode("strong", null, toDisplayString(_ctx.$t("MSG_CONFIRMED")), 1)
            ])
          ]),
          createBaseVNode("div", _hoisted_6$7, [
            createBaseVNode("div", _hoisted_7$7, [
              createBaseVNode("strong", null, toDisplayString(_ctx.$t("MSG_TRANSACTION_ID")), 1)
            ]),
            createVNode(QSpace),
            createBaseVNode("div", _hoisted_8$7, toDisplayString(unref(shortid).shortId(activity.value.certificateHash, 8)), 1),
            createBaseVNode("div", _hoisted_9$7, [
              createVNode(QIcon, {
                name: "bi-copy",
                size: "16px",
                style: { marginTop: "-3px" },
                onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(activity.value.certificateHash, evt), ["stop"]))
              })
            ])
          ]),
          createVNode(QSeparator, { class: "vertical-menus-margin" }),
          createBaseVNode("div", _hoisted_10$4, toDisplayString(_ctx.$t("MSG_FROM")), 1),
          createBaseVNode("div", _hoisted_11$4, [
            createBaseVNode("div", _hoisted_12$2, toDisplayString(activity.value.sourceChain), 1),
            createBaseVNode("div", _hoisted_13$1, [
              createVNode(QSpace),
              createVNode(QImg, {
                src: unref(microchainLogo),
                width: "16px",
                height: "16px"
              }, null, 8, ["src"]),
              createVNode(QAvatar, {
                size: "16px",
                class: "page-item-x-margin-left"
              }, {
                default: withCtx(() => [
                  sourceMicrochain.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: unref(dbModel).microchainAvatar(sourceMicrochain.value),
                    width: "16px",
                    height: "16px"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ])
          ]),
          activity.value.sourceAddress?.length ? (openBlock(), createElementBlock("div", _hoisted_14$1, [
            createBaseVNode("div", _hoisted_15$1, toDisplayString(activity.value.sourceAddress), 1),
            createBaseVNode("div", _hoisted_16$1, [
              createVNode(QSpace),
              createVNode(QAvatar, { size: "16px" }, {
                default: withCtx(() => [
                  sourceOwner.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: unref(dbModel).ownerAvatar(sourceOwner.value),
                    width: "16px",
                    height: "16px"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ])
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_17$1, toDisplayString(_ctx.$t("MSG_TO")), 1),
          createBaseVNode("div", _hoisted_18$1, [
            createBaseVNode("div", _hoisted_19$1, toDisplayString(activity.value.targetChain), 1),
            createBaseVNode("div", _hoisted_20$1, [
              createVNode(QSpace),
              createVNode(QImg, {
                src: unref(microchainLogo),
                width: "16px",
                height: "16px"
              }, null, 8, ["src"]),
              createVNode(QAvatar, {
                size: "16px",
                class: "page-item-x-margin-left"
              }, {
                default: withCtx(() => [
                  targetMicrochain.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: unref(dbModel).microchainAvatar(targetMicrochain.value),
                    width: "16px",
                    height: "16px"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ])
          ]),
          activity.value.targetAddress?.length ? (openBlock(), createElementBlock("div", _hoisted_21$1, [
            createBaseVNode("div", _hoisted_22$1, toDisplayString(activity.value.targetAddress), 1),
            createBaseVNode("div", _hoisted_23$1, [
              createVNode(QSpace),
              createVNode(QAvatar, { size: "16px" }, {
                default: withCtx(() => [
                  targetOwner.value ? (openBlock(), createBlock(QImg, {
                    key: 0,
                    src: unref(dbModel).ownerAvatar(targetOwner.value),
                    width: "16px",
                    height: "16px"
                  }, null, 8, ["src"])) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ])
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_24$1, toDisplayString(_ctx.$t("MSG_TRANSACTION")), 1),
          createBaseVNode("div", _hoisted_25$1, [
            createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_ACTION")), 1),
            createVNode(QSpace),
            createBaseVNode("div", null, toDisplayString(action.value), 1)
          ]),
          createBaseVNode("div", _hoisted_26$1, [
            createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_AMOUNT")), 1),
            createVNode(QSpace),
            createBaseVNode("div", null, [
              createBaseVNode("strong", null, toDisplayString(activity.value.amount) + " " + toDisplayString(token2.value?.ticker), 1)
            ])
          ]),
          createBaseVNode("div", _hoisted_27$1, [
            createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_BLOCK_HEIGHT")), 1),
            createVNode(QSpace),
            createBaseVNode("div", null, toDisplayString(blockHeight.value), 1)
          ]),
          createBaseVNode("div", _hoisted_28$1, [
            createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_GRANT")), 1),
            createVNode(QSpace),
            createBaseVNode("div", null, toDisplayString(activity.value.grant) + " " + toDisplayString(token2.value?.ticker), 1)
          ]),
          createBaseVNode("div", _hoisted_29$1, [
            createBaseVNode("div", _hoisted_30, toDisplayString(_ctx.$t("MSG_CERTIFICATE_HASH")), 1),
            createBaseVNode("div", _hoisted_31, toDisplayString(activity.value.certificateHash), 1)
          ]),
          createBaseVNode("div", _hoisted_32, [
            createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_DATE")), 1),
            createVNode(QSpace),
            createBaseVNode("div", null, toDisplayString(timestamp.value), 1)
          ])
        ]),
        createVNode(_sfc_main$Y, {
          ref: "dbOwnerBridge",
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[1] || (_cache[1] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        selectedOwner.value ? (openBlock(), createBlock(_sfc_main$12, {
          key: 0,
          owner: selectedOwner.value?.owner,
          "microchain-owners": microchainOwners.value,
          "onUpdate:microchainOwners": _cache[2] || (_cache[2] = ($event) => microchainOwners.value = $event)
        }, null, 8, ["owner", "microchain-owners"])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
const _hoisted_1$i = { class: "row" };
const _hoisted_2$h = { class: "text-center text-grey-6 selector-title page-item-x-margin-left setting-action" };
const _hoisted_3$d = { class: "row items-x-margin" };
const _hoisted_4$9 = { class: "text-grey-9" };
const _hoisted_5$8 = {
  key: 0,
  class: "row vertical-items-margin items-x-margin"
};
const _hoisted_6$6 = { class: "text-grey-9" };
const _hoisted_7$6 = { class: "text-grey-6" };
const _hoisted_8$6 = { class: "page-item-x-margin-left" };
const _hoisted_9$6 = { class: "vertical-menus-margin decorate-underline text-bold items-x-margin" };
const _hoisted_10$3 = { class: "vertical-menus-margin transfer-tip items-x-margin cursor-pointer" };
const _hoisted_11$3 = { class: "setting-item word-break-all" };
const _hoisted_12$1 = {
  class: "row vertical-items-margin",
  style: { marginTop: "-24px" }
};
const _hoisted_13 = { class: "vertical-menus-margin decorate-underline text-bold items-x-margin" };
const _hoisted_14 = { class: "row vertical-menus-margin decorate-underline-dashed items-x-margin" };
const _hoisted_15 = { class: "row vertical-items-margin decorate-underline-dashed items-x-margin" };
const _hoisted_16 = { class: "row vertical-items-margin decorate-underline-dashed word-break-all items-x-margin" };
const _hoisted_17 = { style: { width: "128px" } };
const _hoisted_18 = {
  class: "text-right",
  style: { width: "calc(100% - 148px)" }
};
const _hoisted_19 = { class: "row vertical-items-margin decorate-underline-dashed items-x-margin" };
const _hoisted_20 = {
  key: 1,
  class: "row vertical-items-margin decorate-underline-dashed items-x-margin"
};
const _hoisted_21 = {
  key: 2,
  class: "row vertical-items-margin decorate-underline-dashed items-x-margin"
};
const _hoisted_22 = {
  style: { width: "64px" },
  class: "word-break-all"
};
const _hoisted_23 = {
  class: "word-break-all row flex items-center page-item-x-margin-left",
  style: { width: "calc(100% - 70px)" }
};
const _hoisted_24 = { style: { width: "calc(100% - 18px)" } };
const _hoisted_25 = {
  key: 3,
  class: "row vertical-items-margin decorate-underline-dashed items-x-margin"
};
const _hoisted_26 = {
  key: 4,
  class: "row vertical-items-margin decorate-underline-dashed items-x-margin"
};
const _hoisted_27 = { class: "vertical-menus-margin decorate-underline text-bold items-x-margin" };
const _hoisted_28 = { class: "extra-margin-bottom vertical-items-margin decorate-underline-dashed items-x-margin word-break-all" };
const _hoisted_29 = ["innerHTML"];
const _sfc_main$q = defineComponent({
  __name: "ChainOperationDetailView",
  props: {
    operation: {}
  },
  emits: ["back", "close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const operation = toRef(props, "operation");
    const selectedOwner = ref(void 0);
    const microchainOwners = ref([]);
    const token2 = ref(void 0);
    const transferAmount = ref(0);
    const operationType = computed(() => {
      if (operation.value.operationType && operation.value.operationType !== OperationType.ANONYMOUS) {
        return operation.value.operationType[0].toUpperCase() + operation.value.operationType.slice(1);
      }
      const _operation = JSON.parse(operation.value.operation);
      if (_operation.System) {
        return "System:" + Object.keys(_operation.System)[0];
      }
      if (_operation.User) {
        const patterns = operation.value.graphqlQuery?.match(/\).*{\s+([a-zA-Z]+)[($]/);
        if (!patterns)
          return "User:Unknown";
        if (patterns?.length < 2)
          return "User:Unknown";
        return "User:" + patterns[1][0].toUpperCase() + patterns[1].slice(1);
      }
      return "Unknown";
    });
    const operationChain = ref(void 0);
    const operationState = computed(() => OperationState[operation.value.state]);
    const operationStr = computed(() => JSON.stringify(JSON.parse(operation.value.operation), null, 2));
    const emit = __emit;
    const onBackClick = () => {
      emit("back");
    };
    const onCloseClick = () => {
      emit("close");
    };
    onMounted(async () => {
      operationChain.value = await Microchain$1.microchain(operation.value.microchain);
      if (operation.value.operationType === OperationType.TRANSFER) {
        token2.value = await Token.native();
        const _operation = JSON.parse(operation.value.operation);
        transferAmount.value = Number(_operation.System?.Transfer?.amount);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$i, [
          createVNode(QIcon, {
            name: "bi-arrow-left-short",
            size: "24px",
            class: "cursor-pointer text-grey-6",
            onClick: onBackClick
          }),
          createBaseVNode("p", _hoisted_2$h, toDisplayString(operationType.value), 1),
          createVNode(QSpace),
          createVNode(QIcon, {
            name: "bi-x",
            size: "24px",
            class: "cursor-pointer",
            onClick: onCloseClick
          })
        ]),
        createBaseVNode("div", _hoisted_3$d, [
          createBaseVNode("div", _hoisted_4$9, [
            createBaseVNode("strong", null, toDisplayString(_ctx.$t("MSG_STATUS")), 1)
          ]),
          createVNode(QSpace),
          createBaseVNode("div", {
            class: normalizeClass(operation.value.state === unref(dbModel).OperationState.FAILED ? "text-red-6" : "text-green-8")
          }, [
            createBaseVNode("strong", null, toDisplayString(operationState.value), 1)
          ], 2)
        ]),
        operation.value.certificateHash?.length ? (openBlock(), createElementBlock("div", _hoisted_5$8, [
          createBaseVNode("div", _hoisted_6$6, [
            createBaseVNode("strong", null, toDisplayString(_ctx.$t("MSG_TRANSACTION_ID")), 1)
          ]),
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_7$6, toDisplayString(unref(shortid).shortId(operation.value.certificateHash || "", 8)), 1),
          createBaseVNode("div", _hoisted_8$6, [
            createVNode(QIcon, {
              name: "bi-copy",
              size: "16px",
              style: { marginTop: "-3px" },
              onClick: _cache[0] || (_cache[0] = withModifiers((evt) => unref(_copyToClipboard)(operation.value.certificateHash, evt), ["stop"]))
            })
          ])
        ])) : createCommentVNode("", true),
        createVNode(QSeparator, { class: "vertical-menus-margin" }),
        createBaseVNode("div", _hoisted_9$6, toDisplayString(_ctx.$t("MSG_MICROCHAIN")), 1),
        createBaseVNode("div", _hoisted_10$3, [
          createBaseVNode("div", _hoisted_11$3, toDisplayString(operation.value.microchain), 1),
          createBaseVNode("div", _hoisted_12$1, [
            createVNode(QSpace),
            createVNode(QImg, {
              src: unref(microchainLogo),
              width: "16px",
              height: "16px"
            }, null, 8, ["src"]),
            createVNode(QAvatar, {
              size: "16px",
              class: "page-item-x-margin-left"
            }, {
              default: withCtx(() => [
                operationChain.value ? (openBlock(), createBlock(QImg, {
                  key: 0,
                  src: unref(dbModel).microchainAvatar(operationChain.value),
                  width: "16px",
                  height: "16px"
                }, null, 8, ["src"])) : createCommentVNode("", true)
              ]),
              _: 1
            })
          ])
        ]),
        createBaseVNode("div", _hoisted_13, toDisplayString(_ctx.$t("MSG_TRANSACTION")), 1),
        createBaseVNode("div", _hoisted_14, [
          createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_ACTION")), 1),
          createVNode(QSpace),
          createBaseVNode("div", null, toDisplayString(operationType.value), 1)
        ]),
        createBaseVNode("div", _hoisted_15, [
          createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_AMOUNT")), 1),
          createVNode(QSpace),
          createBaseVNode("div", null, [
            createBaseVNode("strong", null, toDisplayString(transferAmount.value) + " " + toDisplayString(token2.value?.ticker), 1)
          ])
        ]),
        createBaseVNode("div", _hoisted_16, [
          createBaseVNode("div", _hoisted_17, toDisplayString(_ctx.$t("MSG_CERTIFICATE_HASH")), 1),
          createBaseVNode("div", _hoisted_18, toDisplayString(operation.value.certificateHash), 1)
        ]),
        createBaseVNode("div", _hoisted_19, [
          createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_CREATED_AT")), 1),
          createVNode(QSpace),
          createBaseVNode("div", null, toDisplayString(unref(date).formatDate(operation.value.createdAt, "YYYY/MM/DD HH:mm:ss")), 1)
        ]),
        operation.value.failedAt ? (openBlock(), createElementBlock("div", _hoisted_20, [
          createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_FAILED_AT")), 1),
          createVNode(QSpace),
          createBaseVNode("div", null, toDisplayString(unref(date).formatDate(operation.value.failedAt, "YYYY/MM/DD HH:mm:ss")), 1)
        ])) : createCommentVNode("", true),
        operation.value.failReason?.length ? (openBlock(), createElementBlock("div", _hoisted_21, [
          createBaseVNode("div", _hoisted_22, toDisplayString(_ctx.$t("MSG_REASON")), 1),
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_23, [
            createBaseVNode("div", _hoisted_24, toDisplayString(operation.value.failReason.substring(0, 240)) + "... ", 1),
            createVNode(QIcon, {
              name: "bi-copy",
              size: "12px",
              class: "page-item-x-margin-left cursor-pointer",
              onClick: _cache[1] || (_cache[1] = withModifiers((evt) => unref(_copyToClipboard)(operation.value.failReason, evt), ["stop"]))
            })
          ])
        ])) : createCommentVNode("", true),
        operation.value.applicationId ? (openBlock(), createElementBlock("div", _hoisted_25, [
          createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_APPLICATION_ID")), 1),
          createVNode(QSpace),
          createBaseVNode("div", null, toDisplayString(operation.value.applicationId), 1)
        ])) : createCommentVNode("", true),
        operation.value.applicationType ? (openBlock(), createElementBlock("div", _hoisted_26, [
          createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_APPLICATION_TYPE")), 1),
          createVNode(QSpace),
          createBaseVNode("div", null, toDisplayString(unref(dbModel).ApplicationType[operation.value.applicationType]), 1)
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_27, toDisplayString(_ctx.$t("MSG_CODE")), 1),
        createBaseVNode("div", _hoisted_28, [
          createBaseVNode("pre", {
            style: { width: "calc(100% - 12px)" },
            innerHTML: operationStr.value
          }, null, 8, _hoisted_29)
        ]),
        createVNode(_sfc_main$Y, {
          ref: "dbOwnerBridge",
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[2] || (_cache[2] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        selectedOwner.value ? (openBlock(), createBlock(_sfc_main$12, {
          key: 5,
          owner: selectedOwner.value?.owner,
          "microchain-owners": microchainOwners.value,
          "onUpdate:microchainOwners": _cache[3] || (_cache[3] = ($event) => microchainOwners.value = $event)
        }, null, 8, ["owner", "microchain-owners"])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$h = { key: 0 };
const _hoisted_2$g = { key: 1 };
const _hoisted_3$c = { key: 2 };
const _hoisted_4$8 = { key: 3 };
const _hoisted_5$7 = { key: 4 };
const _sfc_main$p = defineComponent({
  __name: "MainView",
  setup(__props) {
    const onMicrochainDetailBack = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onMicrochainDetailClosed = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onTokenDetailBack = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onTokenDetailClosed = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onActivityDetailBack = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onActivityDetailClosed = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onChainOperationDetailBack = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    const onChainOperationDetailClosed = () => {
      localStore.setting.HomeAction = localStore.settingDef.HomeAction.SHOW_MAIN;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["full-width page-y-padding", unref(localStore).setting.extensionMode ? "" : "page-x-padding"])
      }, [
        unref(localStore).setting.homeAction === unref(localStore).settingDef.HomeAction.SHOW_MAIN ? (openBlock(), createElementBlock("div", _hoisted_1$h, [
          createVNode(_sfc_main$z)
        ])) : createCommentVNode("", true),
        unref(localStore).setting.homeAction === unref(localStore).settingDef.HomeAction.SHOW_MICROCHAIN ? (openBlock(), createElementBlock("div", _hoisted_2$g, [
          createVNode(_sfc_main$v, {
            microchain: unref(localStore).setting.homeActionParams,
            onBack: onMicrochainDetailBack,
            onClose: onMicrochainDetailClosed
          }, null, 8, ["microchain"])
        ])) : createCommentVNode("", true),
        unref(localStore).setting.homeAction === unref(localStore).settingDef.HomeAction.SHOW_TOKEN ? (openBlock(), createElementBlock("div", _hoisted_3$c, [
          createVNode(_sfc_main$s, {
            token: unref(localStore).setting.homeActionParams,
            onBack: onTokenDetailBack,
            onClose: onTokenDetailClosed
          }, null, 8, ["token"])
        ])) : createCommentVNode("", true),
        unref(localStore).setting.homeAction === unref(localStore).settingDef.HomeAction.SHOW_ACTIVITY ? (openBlock(), createElementBlock("div", _hoisted_4$8, [
          createVNode(_sfc_main$r, {
            activity: unref(localStore).setting.homeActionParams,
            onBack: onActivityDetailBack,
            onClose: onActivityDetailClosed
          }, null, 8, ["activity"])
        ])) : createCommentVNode("", true),
        unref(localStore).setting.homeAction === unref(localStore).settingDef.HomeAction.SHOW_OPERATION ? (openBlock(), createElementBlock("div", _hoisted_5$7, [
          createVNode(_sfc_main$q, {
            operation: unref(localStore).setting.homeActionParams,
            onBack: onChainOperationDetailBack,
            onClose: onChainOperationDetailClosed
          }, null, 8, ["operation"])
        ])) : createCommentVNode("", true)
      ], 2);
    };
  }
});
var SidebarMenu_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$g = {
  key: 0,
  class: "setting-label text-grey-9 text-bold"
};
const _hoisted_2$f = { class: "row" };
const _sfc_main$o = defineComponent({
  __name: "SidebarMenu",
  emits: ["clicked"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const onTabClick = (menu) => {
      emit("clicked", menu);
    };
    const menus = computed(() => localStore.settingDef.SettingMenus.filter((el) => !el.hide));
    const menuIcon = (menu) => {
      switch (menu.menu) {
        case Menu.SWAP:
          return lineraSwapLogo;
        case Menu.BLOB_GATEWAY:
          return blobGatewayLogo;
        case Menu.AMS:
          return applicationManagementLogo;
        case Menu.GENESIS:
          return lineraLogo;
        default:
          return menu.icon;
      }
    };
    const isImg = (menu) => {
      return menu.menu === Menu.SWAP || menu.menu === Menu.BLOB_GATEWAY || menu.menu === Menu.AMS || menu.menu === Menu.GENESIS;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["sidebar extra-large-margin-bottom", unref(localStore).setting.extensionMode ? "full-width" : ""])
      }, [
        !unref(localStore).setting.extensionMode ? (openBlock(), createElementBlock("div", _hoisted_1$g, toDisplayString(_ctx.$t("MSG_SETTINGS")), 1)) : createCommentVNode("", true),
        createVNode(QTabs, {
          vertical: "",
          "no-caps": "",
          "inline-label": "",
          modelValue: unref(localStore).setting.SelectedSettingMenu,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(localStore).setting.SelectedSettingMenu = $event),
          "indicator-color": "red-6"
        }, {
          default: withCtx(() => [
            (openBlock(true), createElementBlock(Fragment, null, renderList(menus.value, (menu, i) => {
              return openBlock(), createElementBlock("div", {
                key: menu.menu
              }, [
                withDirectives((openBlock(), createBlock(QTab, {
                  name: menu.menu,
                  class: normalizeClass([unref(localStore).setting.selectedSettingMenu === menu.menu ? "bg-red-1" : ""]),
                  disable: menu.disable,
                  onClick: ($event) => onTabClick(menu)
                }, {
                  default: withCtx(() => [
                    createVNode(QItemSection, { avatar: "" }, {
                      default: withCtx(() => [
                        isImg(menu) ? (openBlock(), createBlock(QImg, {
                          key: 0,
                          src: menuIcon(menu),
                          width: "24px",
                          height: "24px"
                        }, null, 8, ["src"])) : (openBlock(), createBlock(QIcon, {
                          key: 1,
                          name: menu.icon,
                          color: menu.iconColor || ""
                        }, null, 8, ["name", "color"]))
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(QItemSection, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(menu.label), 1)
                      ]),
                      _: 2
                    }, 1024),
                    unref(localStore).setting.extensionMode ? (openBlock(), createBlock(QItemSection, { key: 0 }, {
                      default: withCtx(() => [
                        createBaseVNode("div", _hoisted_2$f, [
                          createVNode(QSpace),
                          createVNode(QIcon, { name: "bi-chevron-right" })
                        ])
                      ]),
                      _: 1
                    })) : createCommentVNode("", true)
                  ]),
                  _: 2
                }, 1032, ["name", "class", "disable", "onClick"])), [
                  [Ripple]
                ]),
                menu.separator && i < menus.value.length - 1 ? (openBlock(), createBlock(QSeparator, { key: 0 })) : createCommentVNode("", true)
              ]);
            }), 128))
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 2);
    };
  }
});
var SidebarMenu = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-60e8a68b"]]);
const _hoisted_1$f = { class: "text-bold" };
const _hoisted_2$e = { class: "page-item-y-margin-top" };
const _hoisted_3$b = { class: "text-bold vertical-menus-margin" };
const _hoisted_4$7 = { class: "page-item-y-margin-top" };
const _hoisted_5$6 = { class: "text-bold vertical-menus-margin" };
const _hoisted_6$5 = { class: "page-item-y-margin-top" };
const _hoisted_7$5 = { class: "text-bold vertical-menus-margin" };
const _hoisted_8$5 = { class: "page-item-y-margin-top" };
const _hoisted_9$5 = { class: "vertical-sections-margin" };
const _sfc_main$n = defineComponent({
  __name: "NetworkEditorView",
  props: {
    "modelValue": { default: {} },
    "modelModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["saved", "deleted"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const network = useModel(__props, "modelValue");
    const rpcUrl = computed({
      get: () => network.value?.rpcUrl || "",
      set: (val) => {
        const v = new URL(val);
        const protocol = v.protocol.replace(":", "");
        network.value = {
          ...network.value,
          icon: defaultNetwork.icon,
          rpcSchema: protocol,
          wsSchema: protocol === HTTPSchema.HTTP ? WSSchema.WS : WSSchema.WSS,
          host: v.hostname,
          port: parseInt(v.port),
          path: v.pathname
        };
      }
    });
    const wsUrl = computed({
      get: () => network.value?.rpcWsUrl || "",
      set: (val) => {
        const v = new URL(val);
        const protocol = v.protocol.replace(":", "");
        network.value = {
          ...network.value,
          icon: defaultNetwork.icon,
          wsSchema: protocol,
          rpcSchema: protocol === WSSchema.WS ? HTTPSchema.HTTP : HTTPSchema.HTTPS,
          host: v.hostname,
          port: parseInt(v.port),
          path: v.pathname
        };
      }
    });
    watch([network.value.name, network.value.faucetUrl, rpcUrl.value], () => {
      network.value = {
        ...network.value
      };
    });
    const emit = __emit;
    const networkBridge = ref();
    const onSaveClick = async () => {
      network.value.id === void 0 ? await Network.create({ ...network.value }) : await Network.update({ ...network.value });
      emit("saved", network.value);
    };
    const onDeleteClick = async () => {
      await Network.delete(network.value.id);
      emit("deleted", network.value);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["full-width", unref(localStore).setting.extensionMode ? "page-x-padding" : ""])
      }, [
        createBaseVNode("div", _hoisted_1$f, toDisplayString(_ctx.$t("MSG_NETWORK_NAME")), 1),
        createBaseVNode("div", _hoisted_2$e, [
          createVNode(QInput, {
            autogrow: "",
            dense: "",
            outlined: "",
            modelValue: network.value.name,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => network.value.name = $event),
            disable: network.value.preset || network.value.selected
          }, null, 8, ["modelValue", "disable"])
        ]),
        createBaseVNode("div", _hoisted_3$b, toDisplayString(_ctx.$t("MSG_FAUCET_URL")), 1),
        createBaseVNode("div", _hoisted_4$7, [
          createVNode(QInput, {
            autogrow: "",
            dense: "",
            outlined: "",
            modelValue: network.value.faucetUrl,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => network.value.faucetUrl = $event),
            disable: network.value.preset || network.value.selected
          }, null, 8, ["modelValue", "disable"])
        ]),
        createBaseVNode("div", _hoisted_5$6, toDisplayString(_ctx.$t("MSG_RPC_URL")), 1),
        createBaseVNode("div", _hoisted_6$5, [
          createVNode(QInput, {
            autogrow: "",
            dense: "",
            outlined: "",
            modelValue: rpcUrl.value,
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => rpcUrl.value = $event),
            disable: network.value.preset || network.value.selected
          }, null, 8, ["modelValue", "disable"])
        ]),
        createBaseVNode("div", _hoisted_7$5, toDisplayString(_ctx.$t("MSG_SUBSCRIPTION_URL")), 1),
        createBaseVNode("div", _hoisted_8$5, [
          createVNode(QInput, {
            autogrow: "",
            dense: "",
            outlined: "",
            modelValue: wsUrl.value,
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => wsUrl.value = $event),
            disable: network.value.preset || network.value.selected
          }, null, 8, ["modelValue", "disable"])
        ]),
        createBaseVNode("div", _hoisted_9$5, [
          !network.value.preset && !network.value.selected ? (openBlock(), createBlock(QBtn, {
            key: 0,
            flat: "",
            class: "btn full-width vertical-menus-margin",
            "no-caps": "",
            onClick: onSaveClick,
            disable: !network.value.faucetUrl || !network.value.rpcUrl || !network.value.name
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(_ctx.$t("MSG_SAVE")), 1)
            ]),
            _: 1
          }, 8, ["disable"])) : createCommentVNode("", true),
          !network.value.preset && network.value.id !== void 0 && !network.value.selected ? (openBlock(), createBlock(QBtn, {
            key: 1,
            flat: "",
            class: "btn btn-alt full-width vertical-items-margin",
            "no-caps": "",
            onClick: onDeleteClick
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(_ctx.$t("MSG_DELETE")), 1)
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        createVNode(_sfc_main$X, {
          ref_key: "networkBridge",
          ref: networkBridge
        }, null, 512)
      ], 2);
    };
  }
});
const _hoisted_1$e = { class: "full-width full-height" };
const _hoisted_2$d = { class: "row setting-header" };
const _hoisted_3$a = { class: "flex items-center justify-center" };
const _hoisted_4$6 = { class: "page-item-x-margin-left" };
const _hoisted_5$5 = { class: "row full-width extra-large-margin-bottom" };
const _hoisted_6$4 = {
  key: 0,
  class: "full-width page-y-padding"
};
const _hoisted_7$4 = {
  key: 1,
  class: "right-border network-list-left page-y-padding"
};
const _hoisted_8$4 = {
  key: 2,
  class: "network-list-right"
};
const _hoisted_9$4 = ["onClick"];
const _hoisted_10$2 = { class: "row setting-item" };
const _hoisted_11$2 = { class: "setting-item setting-icon" };
const _sfc_main$m = defineComponent({
  __name: "NetworkSettingWideView",
  setup(__props) {
    const networks = ref([]);
    const selectedNetwork = ref({});
    const displayNetwork = ref(selectedNetwork.value);
    watch(selectedNetwork, () => {
      displayNetwork.value = selectedNetwork.value;
    });
    const addingNetwork = ref(false);
    const addedNetwork = ref({});
    const onAddNetworkClick = () => {
      addingNetwork.value = !addingNetwork.value;
    };
    const onNetworkSaved = () => {
      addingNetwork.value = false;
    };
    const onNetworkDeleted = () => {
      addingNetwork.value = false;
    };
    const onNetworkSelected = (network) => {
      displayNetwork.value = network;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$e, [
        createBaseVNode("div", _hoisted_2$d, [
          createBaseVNode("div", _hoisted_3$a, [
            createVNode(QIcon, {
              name: "bi-plugin",
              size: "16px"
            })
          ]),
          createBaseVNode("div", _hoisted_4$6, toDisplayString(_ctx.$t("MSG_NETWORKS")), 1),
          createVNode(QSpace),
          createVNode(QBtn, {
            dense: "",
            flat: "",
            class: "btn",
            "no-caps": "",
            onClick: onAddNetworkClick
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(addingNetwork.value ? "Cancel" : "Add network"), 1)
            ]),
            _: 1
          })
        ]),
        createVNode(QSeparator, { class: "vertical-items-margin" }),
        createBaseVNode("div", _hoisted_5$5, [
          addingNetwork.value ? (openBlock(), createElementBlock("div", _hoisted_6$4, [
            createVNode(_sfc_main$n, {
              modelValue: addedNetwork.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => addedNetwork.value = $event),
              onSaved: onNetworkSaved,
              onDeleted: onNetworkDeleted
            }, null, 8, ["modelValue"])
          ])) : (openBlock(), createElementBlock("div", _hoisted_7$4, [
            createVNode(_sfc_main$n, {
              modelValue: displayNetwork.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => displayNetwork.value = $event),
              onSaved: onNetworkSaved,
              onDeleted: onNetworkDeleted
            }, null, 8, ["modelValue"])
          ])),
          !addingNetwork.value ? (openBlock(), createElementBlock("div", _hoisted_8$4, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(networks.value, (network) => {
              return openBlock(), createElementBlock("div", {
                key: network.id,
                class: "setting-item-container cursor-pointer",
                onClick: ($event) => onNetworkSelected(network)
              }, [
                createBaseVNode("div", _hoisted_10$2, [
                  createBaseVNode("div", _hoisted_11$2, [
                    network.selected ? (openBlock(), createBlock(QIcon, {
                      key: 0,
                      name: "bi-check",
                      size: "28px",
                      color: "green-4"
                    })) : createCommentVNode("", true)
                  ]),
                  createVNode(QAvatar, {
                    size: "28px",
                    color: "grey-4",
                    class: "page-item-x-margin-left"
                  }, {
                    default: withCtx(() => [
                      createVNode(QImg, {
                        src: network.icon,
                        width: "24px",
                        height: "24px"
                      }, null, 8, ["src"])
                    ]),
                    _: 2
                  }, 1024),
                  createBaseVNode("div", {
                    class: normalizeClass(["page-item-x-margin-left text-grey-9 word-break-all", network.id === displayNetwork.value?.id ? "text-bold" : ""]),
                    style: { maxWidth: "calc(100% - 28px - 28px - 28px - 18px)" }
                  }, toDisplayString(network.name), 3),
                  network.preset ? (openBlock(), createBlock(QIcon, {
                    key: 0,
                    name: "bi-key-fill",
                    size: "28px",
                    color: "grey-4",
                    class: "page-item-x-margin-left"
                  })) : createCommentVNode("", true)
                ])
              ], 8, _hoisted_9$4);
            }), 128))
          ])) : createCommentVNode("", true)
        ]),
        createVNode(_sfc_main$X, {
          ref: "networkBridge",
          networks: networks.value,
          "onUpdate:networks": _cache[2] || (_cache[2] = ($event) => networks.value = $event),
          "selected-network": selectedNetwork.value,
          "onUpdate:selectedNetwork": _cache[3] || (_cache[3] = ($event) => selectedNetwork.value = $event)
        }, null, 8, ["networks", "selected-network"])
      ]);
    };
  }
});
var AboutUsView_vue_vue_type_style_index_0_scope_true_lang = "";
const _hoisted_1$d = { class: "text-center" };
const _hoisted_2$c = { class: "vertical-items-margin slogan" };
const _hoisted_3$9 = { class: "vertical-sections-margin extra-margin-bottom" };
const _hoisted_4$5 = { class: "text-left row" };
const _hoisted_5$4 = { class: "extra-large-margin-bottom software-info" };
const _hoisted_6$3 = { class: "row line decorate-underline-dashed" };
const _hoisted_7$3 = { class: "label" };
const _hoisted_8$3 = { class: "row line" };
const _hoisted_9$3 = { class: "label" };
const _hoisted_10$1 = { class: "row line" };
const _hoisted_11$1 = { class: "label" };
const _sfc_main$l = defineComponent({
  __name: "AboutUsView",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$d, [
        createBaseVNode("div", _hoisted_2$c, toDisplayString(_ctx.$t("MSG_DEDICATED_LINERA_MICROCHAIN_WALLET")), 1),
        createBaseVNode("div", _hoisted_3$9, [
          createVNode(QImg, {
            src: unref(cheCkoLogo),
            width: "360px"
          }, null, 8, ["src"])
        ]),
        createBaseVNode("div", _hoisted_4$5, [
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_5$4, [
            createBaseVNode("div", _hoisted_6$3, [
              createBaseVNode("div", _hoisted_7$3, toDisplayString(_ctx.$t("MSG_VERSION")), 1),
              createVNode(QSpace),
              createBaseVNode("div", null, toDisplayString(_ctx.$t("MSG_VERSION_NUMBER")), 1)
            ]),
            createBaseVNode("div", _hoisted_8$3, [
              createBaseVNode("div", _hoisted_9$3, toDisplayString(_ctx.$t("MSG_BUILT_BY")), 1),
              createVNode(QSpace),
              _cache[0] || (_cache[0] = createBaseVNode("div", null, [
                createBaseVNode("a", { href: "https://respeer.ai" }, "respeer.ai")
              ], -1))
            ]),
            createBaseVNode("div", _hoisted_10$1, [
              createBaseVNode("div", _hoisted_11$1, toDisplayString(_ctx.$t("MSG_SUPPORT")), 1),
              createVNode(QSpace),
              _cache[1] || (_cache[1] = createBaseVNode("div", null, "checko@respeer.ai", -1))
            ])
          ]),
          createVNode(QSpace)
        ])
      ]);
    };
  }
});
const _hoisted_1$c = { class: "tip warn warn-bg text-left row" };
const _hoisted_2$b = { class: "tip-text page-item-x-margin-left" };
const _sfc_main$k = defineComponent({
  __name: "ClearStorageView",
  setup(__props) {
    const confirmSeconds = ref(10);
    const confirmedSeconds = ref(0);
    const onConfirmClick = async () => {
      confirmedSeconds.value++;
      if (confirmSeconds.value === confirmedSeconds.value) {
        await dbWallet.delete();
        await dbBase.delete();
        let pathname = localStore.setting.formalizePath("/");
        let hash = "";
        if (document.URL.startsWith("chrome-extension://")) {
          pathname = "/www/index.html";
          hash = "#/extension/onboarding";
        }
        if (hash.length > 0) {
          window.location.hash = hash;
        }
        window.location.pathname = pathname;
      }
    };
    const onConfirmCanceled = () => {
      confirmedSeconds.value = 0;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$c, [
          createVNode(QIcon, {
            name: "bi-exclamation-triangle-fill",
            color: "red-8",
            size: "24px"
          }),
          createBaseVNode("div", _hoisted_2$b, toDisplayString(_ctx.$t("MSG_UNDERSTAND_PRESS_WILL_CLEAR_ALL_DATA")), 1)
        ]),
        withDirectives((openBlock(), createBlock(QBtn, {
          loading: confirmedSeconds.value > 0 && confirmedSeconds.value < confirmSeconds.value,
          percentage: confirmedSeconds.value * 100 / confirmSeconds.value,
          flat: "",
          class: "btn btn-alt vertical-menus-margin full-width",
          label: "Long press to clear storage",
          "no-caps": "",
          onMouseup: onConfirmCanceled
        }, {
          loading: withCtx(() => [
            createVNode(QSpinnerGears, { class: "on-left" }),
            createTextVNode(" " + toDisplayString(_ctx.$t("MSG_CONFIRMING")), 1)
          ]),
          _: 1
        }, 8, ["loading", "percentage"])), [
          [
            TouchRepeat,
            onConfirmClick,
            void 0,
            { mouse: true }
          ]
        ])
      ]);
    };
  }
});
var StorageOperationView_vue_vue_type_style_index_0_scope_true_lang = "";
const _hoisted_1$b = {
  key: 0,
  class: "row full-width"
};
const _hoisted_2$a = { class: "vertical-items-margin tip warn-bg warn row" };
const _hoisted_3$8 = { class: "tip-text page-item-x-margin-left" };
const _sfc_main$j = defineComponent({
  __name: "StorageOperationView",
  setup(__props) {
    const confirmed = ref(false);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["row text-center vertical-sections-margin extra-large-margin-bottom", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
      }, [
        unref(localStore).setting.extensionMode ? (openBlock(), createElementBlock("div", _hoisted_1$b, [
          createVNode(QSpace),
          createVNode(QImg, {
            src: unref(storageIcon),
            width: "120px",
            class: "selector-margin-x-left",
            fit: "contain"
          }, null, 8, ["src"]),
          createVNode(QSpace)
        ])) : createCommentVNode("", true),
        !confirmed.value ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass([unref(localStore).setting.extensionMode ? "vertical-sections-margin" : "row"])
        }, [
          createBaseVNode("div", {
            style: normalizeStyle({ width: unref(localStore).setting.extensionMode ? "100%" : "calc(100% - 132px)" }),
            class: "text-left"
          }, [
            createBaseVNode("div", _hoisted_2$a, [
              createVNode(QIcon, {
                name: "bi-exclamation-triangle-fill",
                color: "red-8",
                size: "24px"
              }),
              createBaseVNode("div", _hoisted_3$8, toDisplayString(_ctx.$t("MSG_SUGGEST_DONT_TOUCH_THIS_MENU")), 1)
            ]),
            createVNode(QBtn, {
              flat: "",
              class: normalizeClass(["btn btn-alt vertical-menus-margin text-black", unref(localStore).setting.extensionMode ? "full-width" : ""]),
              "no-caps": "",
              onClick: _cache[0] || (_cache[0] = ($event) => confirmed.value = true)
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("MSG_I_UNDERSTAND")), 1)
              ]),
              _: 1
            }, 8, ["class"])
          ], 4),
          !unref(localStore).setting.extensionMode ? (openBlock(), createBlock(QImg, {
            key: 0,
            src: unref(storageIcon),
            width: "120px",
            class: "selector-margin-x-left",
            fit: "contain"
          }, null, 8, ["src"])) : createCommentVNode("", true)
        ], 2)) : (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass([unref(localStore).setting.extensionMode ? "vertical-sections-margin" : ""])
        }, [
          createVNode(_sfc_main$k)
        ], 2))
      ], 2);
    };
  }
});
const _hoisted_1$a = { class: "vertical-menus-margin text-grey-8 text-bold decorate-underline setting-item-inner-padding" };
const _hoisted_2$9 = { class: "vertical-items-margin" };
const _hoisted_3$7 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_4$4 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _sfc_main$i = defineComponent({
  __name: "AccountMicrochainsView",
  props: /* @__PURE__ */ mergeModels({
    owner: {}
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const owner = toRef(props, "owner");
    const selectedMicrochain = useModel(__props, "modelValue");
    const emit = __emit;
    const onMicrochainSelected = (microchain) => {
      selectedMicrochain.value = microchain;
      emit("selected", microchain);
    };
    const onAddMicrochainClick = () => {
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: normalizeClass(["row", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
        }, [
          createVNode(_sfc_main$V, {
            owner: owner.value,
            editable: true
          }, null, 8, ["owner"]),
          createVNode(QSpace),
          owner.value.selected ? (openBlock(), createBlock(QIcon, {
            key: 0,
            name: "bi-check-circle-fill",
            size: "16px",
            color: "green-4"
          })) : createCommentVNode("", true),
          createVNode(QIcon, {
            name: "bi-opencollective",
            size: "16px",
            color: "grey-7",
            class: "page-item-x-margin-left cursor-pointer"
          })
        ], 2),
        createBaseVNode("div", _hoisted_1$a, toDisplayString(_ctx.$t("MSG_MICROCHAINS")), 1),
        createBaseVNode("div", _hoisted_2$9, [
          createVNode(MicrochainsInnerView, {
            searchable: false,
            "show-indicator": false,
            onSelected: onMicrochainSelected,
            "x-padding": unref(localStore).setting.extensionMode ? "8px" : "0"
          }, null, 8, ["x-padding"]),
          createBaseVNode("div", {
            class: "row vertical-sections-margin selector-margin-left cursor-pointer setting-item-inner-padding",
            onClick: onAddMicrochainClick
          }, [
            createVNode(QIcon, {
              name: "bi-plus-lg",
              size: "20px",
              color: "blue-10"
            }),
            createBaseVNode("div", _hoisted_3$7, toDisplayString(_ctx.$t("MSG_CREATE_MICROCHAIN")), 1)
          ]),
          createBaseVNode("div", {
            class: "row vertical-items-margin selector-margin-left cursor-pointer setting-item-inner-padding",
            onClick: onAddMicrochainClick
          }, [
            createVNode(QIcon, {
              name: "bi-save",
              size: "20px",
              color: "blue-10"
            }),
            createBaseVNode("div", _hoisted_4$4, toDisplayString(_ctx.$t("MSG_EXPORT_ACCOUNT")), 1)
          ])
        ])
      ]);
    };
  }
});
const _hoisted_1$9 = { class: "selector-margin-x-left account-avatar" };
const _hoisted_2$8 = { class: "text-bold text-grey-9" };
const _hoisted_3$6 = { class: "text-grey-8 selector-item-currency-sub" };
const _sfc_main$h = defineComponent({
  __name: "MicrochainDetailView",
  props: {
    microchain: {}
  },
  setup(__props) {
    const props = __props;
    const microchain = toRef(props, "microchain");
    const chainTokenBalance = ref(0);
    const chainUsdBalance = ref(0);
    const accountTokenBalance = ref(0);
    const accountUsdBalance = ref(0);
    const activities = ref([]);
    const selectedOwner = ref(void 0);
    const nativeTokenId = ref(void 0);
    onMounted(async () => {
      nativeTokenId.value = (await Token.native())?.id;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", null, [
          createBaseVNode("div", {
            class: normalizeClass(["row vertical-sections-margin", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
          }, [
            createVNode(QAvatar, null, {
              default: withCtx(() => [
                createVNode(QImg, {
                  src: unref(dbModel).microchainAvatar(microchain.value)
                }, null, 8, ["src"])
              ]),
              _: 1
            }),
            createBaseVNode("div", _hoisted_1$9, [
              createBaseVNode("span", _hoisted_2$8, toDisplayString(microchain.value.name || "Microchain"), 1),
              createBaseVNode("div", _hoisted_3$6, " $ " + toDisplayString((chainUsdBalance.value + accountUsdBalance.value).toFixed(4)) + " " + toDisplayString(_ctx.$t("MSG_USD")), 1)
            ]),
            createVNode(QSpace),
            microchain.value.default ? (openBlock(), createBlock(QIcon, {
              key: 0,
              name: "bi-check-circle-fill",
              size: "16px",
              color: "green-4"
            })) : createCommentVNode("", true)
          ], 2),
          createVNode(_sfc_main$w, { microchain: microchain.value }, null, 8, ["microchain"])
        ]),
        createVNode(_sfc_main$14, {
          "token-id": nativeTokenId.value,
          "token-balance": chainTokenBalance.value,
          "onUpdate:tokenBalance": _cache[0] || (_cache[0] = ($event) => chainTokenBalance.value = $event),
          "usd-balance": chainUsdBalance.value,
          "onUpdate:usdBalance": _cache[1] || (_cache[1] = ($event) => chainUsdBalance.value = $event)
        }, null, 8, ["token-id", "token-balance", "usd-balance"]),
        createVNode(_sfc_main$15, {
          "token-id": nativeTokenId.value,
          "token-balance": accountTokenBalance.value,
          "onUpdate:tokenBalance": _cache[2] || (_cache[2] = ($event) => accountTokenBalance.value = $event),
          "usd-balance": accountUsdBalance.value,
          "onUpdate:usdBalance": _cache[3] || (_cache[3] = ($event) => accountUsdBalance.value = $event),
          owner: selectedOwner.value?.owner,
          "microchain-id": microchain.value.microchain
        }, null, 8, ["token-id", "token-balance", "usd-balance", "owner", "microchain-id"]),
        createVNode(_sfc_main$Y, {
          "selected-owner": selectedOwner.value,
          "onUpdate:selectedOwner": _cache[4] || (_cache[4] = ($event) => selectedOwner.value = $event)
        }, null, 8, ["selected-owner"]),
        createVNode(_sfc_main$D, {
          activities: activities.value,
          "onUpdate:activities": _cache[5] || (_cache[5] = ($event) => activities.value = $event),
          microchain: microchain.value.microchain
        }, null, 8, ["activities", "microchain"])
      ], 64);
    };
  }
});
const _hoisted_1$8 = { class: "extra-margin-bottom" };
const _hoisted_2$7 = { class: "flex items-center justify-center" };
const _hoisted_3$5 = { class: "head-separator flex items-center justify-center" };
const _hoisted_4$3 = {
  key: 0,
  class: "head-separator flex items-center justify-center"
};
const _hoisted_5$3 = {
  key: 2,
  class: "head-separator flex items-center justify-center"
};
const _hoisted_6$2 = {
  key: 3,
  class: "label-text-small cursor-pointer"
};
const _hoisted_7$2 = { class: "vertical-menus-margin" };
const _hoisted_8$2 = { key: 0 };
const _hoisted_9$2 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_10 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_11 = { key: 1 };
const _hoisted_12 = { key: 2 };
const _sfc_main$g = defineComponent({
  __name: "AccountsView",
  emits: ["back"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const step = ref(1);
    const selectedOwner = ref(void 0);
    const selectedMicrochain = ref(void 0);
    const onAccountClick = (owner) => {
      step.value++;
      selectedOwner.value = owner;
    };
    const onAccountsClick = () => {
      step.value = 1;
    };
    const onMicrochainsClick = () => {
      step.value = 2;
    };
    const onAddAccountClick = () => {
    };
    const emit = __emit;
    const back = () => {
      if (step.value === 1)
        return emit("back");
      step.value--;
    };
    __expose({
      back
    });
    const onMicrochainSelected = () => {
      step.value++;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$8, [
        createBaseVNode("div", {
          class: normalizeClass(["row", unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
        }, [
          createBaseVNode("div", _hoisted_2$7, [
            createVNode(QIcon, {
              name: "bi-view-list",
              size: "16px"
            })
          ]),
          createBaseVNode("div", _hoisted_3$5, [
            createVNode(QIcon, {
              name: "bi-chevron-right",
              size: "12px"
            })
          ]),
          createBaseVNode("div", {
            class: normalizeClass(["label-text-small cursor-pointer", step.value === 1 ? "" : "text-grey-8"]),
            onClick: onAccountsClick
          }, toDisplayString(_ctx.$t("MSG_ACCOUNTS")), 3),
          step.value >= 2 ? (openBlock(), createElementBlock("div", _hoisted_4$3, [
            createVNode(QIcon, {
              name: "bi-chevron-right",
              size: "12px"
            })
          ])) : createCommentVNode("", true),
          step.value >= 2 ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(["label-text-small cursor-pointer", step.value === 2 ? "" : "text-grey-8"]),
            onClick: onMicrochainsClick
          }, toDisplayString(_ctx.$t("MSG_MICROCHAINS")), 3)) : createCommentVNode("", true),
          step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_5$3, [
            createVNode(QIcon, {
              name: "bi-chevron-right",
              size: "12px"
            })
          ])) : createCommentVNode("", true),
          step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_6$2, " 0x" + toDisplayString(unref(shortid).shortId(selectedMicrochain.value.microchain, 4)), 1)) : createCommentVNode("", true)
        ], 2),
        createBaseVNode("div", _hoisted_7$2, [
          step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_8$2, [
            createVNode(_sfc_main$16, {
              modelValue: selectedOwner.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedOwner.value = $event),
              persistent: false,
              searchable: false,
              onSelected: onAccountClick
            }, null, 8, ["modelValue"]),
            createBaseVNode("div", {
              class: "row vertical-sections-margin selectable-margin-left cursor-pointer",
              onClick: onAddAccountClick
            }, [
              createVNode(QIcon, {
                name: "bi-plus-lg",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_9$2, toDisplayString(_ctx.$t("MSG_ADD_ACCOUNT")), 1)
            ]),
            createBaseVNode("div", {
              class: "row vertical-items-margin selectable-margin-left cursor-pointer",
              onClick: onAddAccountClick
            }, [
              createVNode(QIcon, {
                name: "bi-save",
                size: "20px",
                color: "blue-10"
              }),
              createBaseVNode("div", _hoisted_10, toDisplayString(_ctx.$t("MSG_EXPORT_ALL")), 1)
            ])
          ])) : createCommentVNode("", true),
          step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_11, [
            createVNode(_sfc_main$i, {
              modelValue: selectedMicrochain.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => selectedMicrochain.value = $event),
              owner: selectedOwner.value,
              onSelected: onMicrochainSelected
            }, null, 8, ["modelValue", "owner"])
          ])) : createCommentVNode("", true),
          step.value === 3 ? (openBlock(), createElementBlock("div", _hoisted_12, [
            createVNode(_sfc_main$h, { microchain: selectedMicrochain.value }, null, 8, ["microchain"])
          ])) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
const _sfc_main$f = {};
const _hoisted_1$7 = { class: "row flex items-center justify-center full-height" };
const _hoisted_2$6 = { class: "text-center text-grey-6" };
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$7, [
    createBaseVNode("p", _hoisted_2$6, toDisplayString(_ctx.$t("MSG_COMING_SOON")), 1)
  ]);
}
var AddressesBook = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["render", _sfc_render]]);
const _sfc_main$e = defineComponent({
  __name: "RequestAccountsView",
  setup(__props) {
    const onRun = () => {
      const web3 = new Web3(window.linera);
      web3.eth.requestAccounts().then((accounts) => {
        console.log(accounts);
      }).catch((error) => {
        console.log(error);
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(QBtn, {
          label: "Request accounts",
          "no-caps": "",
          class: "btn full-width",
          flat: "",
          onClick: onRun
        })
      ]);
    };
  }
});
const _sfc_main$d = defineComponent({
  __name: "GetProviderStateView",
  setup(__props) {
    const onRun = () => {
      window.linera?.request({
        method: "metamask_getProviderState"
      }).then((result) => {
        console.log(result);
      }).catch((e) => {
        console.log("metamask_getProviderState", e);
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(QBtn, {
          label: "Get provider state",
          "no-caps": "",
          class: "btn full-width",
          flat: "",
          onClick: onRun
        })
      ]);
    };
  }
});
const _sfc_main$c = defineComponent({
  __name: "EthSignView",
  setup(__props) {
    const onRun = async () => {
      const web3 = new Web3(window.linera);
      const accounts = await web3.eth.requestAccounts();
      if (!accounts.length)
        return console.log("Invalid account");
      const hexContent = Web3.utils.utf8ToHex("Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World! Hello World!");
      console.log("Sign", hexContent, accounts);
      web3.eth.sign(hexContent, "0x" + accounts[0].slice(0, 40)).then((result) => {
        console.log(result);
      }).catch((e) => {
        console.log("eth_sign", e);
      });
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(QBtn, {
          label: "Sign content",
          "no-caps": "",
          class: "btn full-width",
          flat: "",
          onClick: onRun
        })
      ]);
    };
  }
});
const _sfc_main$b = defineComponent({
  __name: "LineraMutationTransfer",
  props: {
    purpose: {}
  },
  setup(__props) {
    const props = __props;
    const purpose = toRef(props, "purpose");
    const onRun = async () => {
      try {
        const web3 = new Web3(window.linera);
        const accounts = await web3.eth.requestAccounts();
        if (accounts.length === 0)
          return;
        const state = await window.linera?.request({
          method: "metamask_getProviderState"
        });
        const owner = Account.accountOwner(await ownerFromPublicKey(accounts[0]));
        console.log(accounts, state, owner);
        const result = await window.linera.request({
          method: "linera_graphqlMutation",
          params: {
            query: {
              query: TRANSFER.loc?.source?.body,
              variables: {
                chainId: state.chainId.replace("0x", ""),
                owner: "0x00",
                recipient: {
                  chainId: state.chainId.replace("0x", ""),
                  owner
                },
                amount: "0.01"
              }
            },
            operationName: "transfer"
          }
        });
        console.log(result);
      } catch (e) {
        console.log("Fail run mutation", e);
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(QBtn, {
          label: "Linera transfer" + (purpose.value ? " " + purpose.value : ""),
          "no-caps": "",
          class: "btn full-width",
          flat: "",
          onClick: onRun
        }, null, 8, ["label"])
      ]);
    };
  }
});
const _sfc_main$a = defineComponent({
  __name: "LineraSubscription",
  setup(__props) {
    const subscriptionId = ref(void 0);
    const subscriptionHandler = (msg) => {
      console.log("Subscription", msg);
    };
    onMounted(() => {
      if (subscriptionId.value)
        return;
      window.linera?.request({
        method: "linera_subscribe"
      }).then((_subscriptionId) => {
        subscriptionId.value = _subscriptionId;
        window.linera.on("message", subscriptionHandler);
      }).catch((e) => {
        console.log("Fail subscribe", e);
      });
    });
    onUnmounted(() => {
      if (!subscriptionId.value)
        return;
      void window.linera?.request({
        method: "linera_unsubscribe",
        params: [subscriptionId.value]
      });
      subscriptionId.value = void 0;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$b, { purpose: "For Subscription" });
    };
  }
});
const _hoisted_1$6 = { class: "full-height setting-item-inner-padding" };
const _sfc_main$9 = defineComponent({
  __name: "EngineeringView",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$6, [
        createVNode(_sfc_main$e),
        createVNode(_sfc_main$d, { class: "vertical-items-margin" }),
        createVNode(_sfc_main$c, { class: "vertical-items-margin" }),
        createVNode(_sfc_main$b, { class: "vertical-items-margin" }),
        createVNode(_sfc_main$a, { class: "vertical-items-margin" })
      ]);
    };
  }
});
const _hoisted_1$5 = { class: "row setting-header" };
const _hoisted_2$5 = { class: "flex items-center justify-center" };
const _hoisted_3$4 = { class: "page-item-x-margin-left" };
const _hoisted_4$2 = {
  class: "vertical-menus-margin text-grey-8 text-bold decorate-underline row flex items-center",
  style: { paddingBottom: "4px" }
};
const _hoisted_5$2 = { class: "vertical-items-margin text-grey-6 word-break-all" };
const _hoisted_6$1 = {
  class: "vertical-menus-margin text-grey-8 text-bold decorate-underline row flex items-center",
  style: { paddingBottom: "4px" }
};
const _hoisted_7$1 = { class: "vertical-items-margin text-grey-6 word-break-all" };
const _hoisted_8$1 = {
  class: "vertical-menus-margin text-grey-8 text-bold decorate-underline row flex items-center",
  style: { paddingBottom: "4px" }
};
const _hoisted_9$1 = { class: "vertical-items-margin text-grey-6 word-break-all" };
const _sfc_main$8 = defineComponent({
  __name: "GenesisInfoView",
  setup(__props) {
    const networkInfo = computed(() => localStore.setting._networkInfo);
    onMounted(async () => {
      if (!networkInfo.value) {
        localStore.setting.NetworkInfo = await GenesisInfo.getNetworkInfo();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([unref(localStore).setting.extensionMode ? "setting-item-inner-padding" : ""])
      }, [
        createBaseVNode("div", _hoisted_1$5, [
          createBaseVNode("div", _hoisted_2$5, [
            createVNode(QIcon, {
              name: "bi-plugin",
              size: "16px"
            })
          ]),
          createBaseVNode("div", _hoisted_3$4, toDisplayString(_ctx.$t("MSG_GENESIS")), 1)
        ]),
        createBaseVNode("div", _hoisted_4$2, toDisplayString(_ctx.$t("MSG_ADMIN_CHAIN")), 1),
        createBaseVNode("p", _hoisted_5$2, toDisplayString(networkInfo.value?.genesisConfig?.admin_id), 1),
        createBaseVNode("div", _hoisted_6$1, toDisplayString(_ctx.$t("MSG_VERSION")), 1),
        createBaseVNode("div", _hoisted_7$1, toDisplayString(networkInfo.value?.version?.crate_version) + " - " + toDisplayString(networkInfo.value?.version?.git_commit), 1),
        createBaseVNode("div", _hoisted_8$1, toDisplayString(_ctx.$t("MSG_VALIDATORS")), 1),
        createBaseVNode("div", _hoisted_9$1, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(networkInfo.value?.currentValidators, (validator) => {
            return openBlock(), createElementBlock("div", {
              key: validator.publicKey,
              class: "decorate-underline-dashed vertical-items-margin"
            }, [
              createBaseVNode("div", null, toDisplayString(validator.publicKey), 1),
              createBaseVNode("div", null, toDisplayString(validator.networkAddress), 1),
              _cache[0] || (_cache[0] = createBaseVNode("div", { class: "vertical-items-margin" }, null, -1))
            ]);
          }), 128))
        ])
      ], 2);
    };
  }
});
const _sfc_main$7 = defineComponent({
  __name: "SettingInnerWideView",
  emits: ["back"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const accountsView = ref();
    const back = () => {
      if (localStore.settingDef.Menu.ACCOUNTS !== localStore.setting.selectedSettingMenu) {
        return emit("back");
      }
      accountsView.value?.back();
    };
    __expose({
      back
    });
    const emit = __emit;
    const onBack = () => {
      emit("back");
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QTabPanels, {
        modelValue: unref(localStore).setting.SelectedSettingMenu,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(localStore).setting.SelectedSettingMenu = $event),
        animated: ""
      }, {
        default: withCtx(() => [
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.NETWORKS
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$m)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.GENESIS
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$8)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ABOUT_US
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$l)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.STORAGE
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$j)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ACCOUNTS
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$g, {
                ref_key: "accountsView",
                ref: accountsView,
                onBack
              }, null, 512)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ADDRESSES_BOOK
          }, {
            default: withCtx(() => [
              createVNode(AddressesBook)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ENGINEERING
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$9)
            ]),
            _: 1
          }, 8, ["name"])
        ]),
        _: 1
      }, 8, ["modelValue"]);
    };
  }
});
const _hoisted_1$4 = { class: "row full-width full-height" };
const _hoisted_2$4 = { class: "row page-actions-padding" };
const _hoisted_3$3 = { class: "vertical-menus-margin" };
const _sfc_main$6 = defineComponent({
  __name: "SettingWideView",
  setup(__props) {
    const sidebarWidth = ref(0);
    const settingInnerView = ref();
    const onSidebarResize = (size) => {
      sidebarWidth.value = size.width;
    };
    const onBackClick = () => {
      settingInnerView.value?.back();
    };
    const onCloseClick = () => {
      localStore.setting.ShowSettingMenu = false;
    };
    const onInnerBack = () => {
      localStore.setting.ShowSettingMenu = false;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createBaseVNode("div", null, [
          createVNode(SidebarMenu),
          createVNode(QResizeObserver, { onResize: onSidebarResize })
        ]),
        createBaseVNode("div", {
          style: normalizeStyle({ width: `calc(100% - ${sidebarWidth.value}px - 32px)`, marginLeft: "16px" })
        }, [
          createBaseVNode("div", _hoisted_2$4, [
            createVNode(QIcon, {
              name: "bi-arrow-left-short",
              size: "24px",
              class: "cursor-pointer",
              onClick: onBackClick
            }),
            createVNode(QSpace),
            createVNode(QIcon, {
              name: "bi-x",
              size: "24px",
              class: "cursor-pointer",
              onClick: onCloseClick
            })
          ]),
          createBaseVNode("div", _hoisted_3$3, [
            createVNode(_sfc_main$7, {
              ref_key: "settingInnerView",
              ref: settingInnerView,
              onBack: onInnerBack
            }, null, 512)
          ])
        ], 4)
      ]);
    };
  }
});
const _hoisted_1$3 = { class: "full-width full-height" };
const _hoisted_2$3 = { key: 0 };
const _hoisted_3$2 = ["onClick"];
const _hoisted_4$1 = { class: "row setting-item setting-item-inner-padding" };
const _hoisted_5$1 = { class: "setting-item setting-icon" };
const _hoisted_6 = { class: "page-x-padding" };
const _hoisted_7 = {
  key: 1,
  class: "full-width extra-margin-bottom"
};
const _hoisted_8 = {
  key: 0,
  class: "full-width page-y-padding"
};
const _hoisted_9 = {
  key: 1,
  class: "full-width page-y-padding"
};
const _sfc_main$5 = defineComponent({
  __name: "NetworkSettingNarrowView",
  emits: ["back"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const networks = ref([]);
    const selectedNetwork = ref({});
    const displayNetwork = ref(selectedNetwork.value);
    const step = ref(1);
    const emit = __emit;
    watch(selectedNetwork, () => {
      displayNetwork.value = selectedNetwork.value;
    });
    const addingNetwork = ref(false);
    const addedNetwork = ref({});
    const onAddNetworkClick = () => {
      addingNetwork.value = true;
      step.value++;
    };
    const onNetworkSaved = () => {
      addingNetwork.value = false;
    };
    const onNetworkDeleted = () => {
      addingNetwork.value = false;
    };
    const onNetworkSelected = (network) => {
      displayNetwork.value = network;
      step.value++;
    };
    const back = () => {
      if (step.value === 1) {
        return emit("back");
      }
      step.value--;
    };
    __expose({
      back
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_2$3, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(networks.value, (network) => {
            return openBlock(), createElementBlock("div", {
              key: network.id,
              class: "setting-item-container cursor-pointer setting-item-no-x-padding",
              onClick: ($event) => onNetworkSelected(network)
            }, [
              createBaseVNode("div", _hoisted_4$1, [
                createBaseVNode("div", _hoisted_5$1, [
                  network.selected ? (openBlock(), createBlock(QIcon, {
                    key: 0,
                    name: "bi-check",
                    size: "28px",
                    color: "green-4"
                  })) : createCommentVNode("", true)
                ]),
                createVNode(QAvatar, {
                  size: "28px",
                  color: "grey-4",
                  class: "page-item-x-margin-left"
                }, {
                  default: withCtx(() => [
                    createVNode(QImg, {
                      src: network.icon,
                      width: "24px",
                      height: "24px"
                    }, null, 8, ["src"])
                  ]),
                  _: 2
                }, 1024),
                createBaseVNode("div", {
                  class: normalizeClass(["page-item-x-margin-left text-grey-9", network.id === displayNetwork.value?.id ? "text-bold" : ""])
                }, toDisplayString(network.name), 3),
                network.preset ? (openBlock(), createBlock(QIcon, {
                  key: 0,
                  name: "bi-key-fill",
                  size: "28px",
                  color: "grey-4",
                  class: "page-item-x-margin-left"
                })) : createCommentVNode("", true)
              ])
            ], 8, _hoisted_3$2);
          }), 128)),
          createBaseVNode("div", _hoisted_6, [
            createVNode(QBtn, {
              flat: "",
              class: "btn full-width vertical-sections-margin",
              "no-caps": "",
              onClick: onAddNetworkClick
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("MSG_ADD_NETWORK")), 1)
              ]),
              _: 1
            })
          ])
        ])) : createCommentVNode("", true),
        step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_7, [
          addingNetwork.value ? (openBlock(), createElementBlock("div", _hoisted_8, [
            createVNode(_sfc_main$n, {
              modelValue: addedNetwork.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => addedNetwork.value = $event),
              onSaved: onNetworkSaved,
              onDeleted: onNetworkDeleted
            }, null, 8, ["modelValue"])
          ])) : (openBlock(), createElementBlock("div", _hoisted_9, [
            createVNode(_sfc_main$n, {
              modelValue: displayNetwork.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => displayNetwork.value = $event),
              onSaved: onNetworkSaved,
              onDeleted: onNetworkDeleted
            }, null, 8, ["modelValue"])
          ]))
        ])) : createCommentVNode("", true),
        createVNode(_sfc_main$X, {
          ref: "networkBridge",
          networks: networks.value,
          "onUpdate:networks": _cache[2] || (_cache[2] = ($event) => networks.value = $event),
          "selected-network": selectedNetwork.value,
          "onUpdate:selectedNetwork": _cache[3] || (_cache[3] = ($event) => selectedNetwork.value = $event)
        }, null, 8, ["networks", "selected-network"])
      ]);
    };
  }
});
const _sfc_main$4 = defineComponent({
  __name: "SettingInnerNarrowView",
  emits: ["back"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const accountsView = ref();
    const networkSettingView = ref();
    const back = () => {
      switch (localStore.setting.selectedSettingMenu) {
        case localStore.settingDef.Menu.ACCOUNTS:
          return accountsView.value?.back();
        case localStore.settingDef.Menu.NETWORKS:
          return networkSettingView.value?.back();
        default:
          return emit("back");
      }
    };
    __expose({
      back
    });
    const emit = __emit;
    const onBack = () => {
      emit("back");
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QTabPanels, {
        modelValue: unref(localStore).setting.SelectedSettingMenu,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => unref(localStore).setting.SelectedSettingMenu = $event),
        animated: ""
      }, {
        default: withCtx(() => [
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.NETWORKS
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$5, {
                ref_key: "networkSettingView",
                ref: networkSettingView,
                onBack
              }, null, 512)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.GENESIS
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$8)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ABOUT_US
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$l)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.STORAGE
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$j)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ACCOUNTS
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$g, {
                ref_key: "accountsView",
                ref: accountsView,
                onBack
              }, null, 512)
            ]),
            _: 1
          }, 8, ["name"]),
          createVNode(QTabPanel, {
            name: unref(localStore).settingDef.Menu.ADDRESSES_BOOK
          }, {
            default: withCtx(() => [
              createVNode(AddressesBook)
            ]),
            _: 1
          }, 8, ["name"])
        ]),
        _: 1
      }, 8, ["modelValue"]);
    };
  }
});
const _hoisted_1$2 = { class: "full-width full-height" };
const _hoisted_2$2 = { class: "row page-actions-padding flex items-center justify-center" };
const _hoisted_3$1 = { class: "setting-label setting-label-dense text-grey-9 text-bold" };
const _hoisted_4 = {
  key: 0,
  class: "vertical-menus-margin"
};
const _hoisted_5 = {
  key: 1,
  class: "full-width vertical-menus-margin"
};
const _sfc_main$3 = defineComponent({
  __name: "SettingNarrowView",
  setup(__props) {
    const step = ref(1);
    const title = ref("Settings");
    const settingInnerView = ref();
    const onBackClick = () => {
      if (step.value === 1) {
        localStore.setting.ShowSettingMenu = false;
        return;
      }
      settingInnerView.value?.back();
    };
    const onCloseClick = () => {
      localStore.setting.ShowSettingMenu = false;
    };
    const onInnerBack = () => {
      step.value--;
      if (step.value === 1) {
        title.value = "Settings";
      }
    };
    const onMenuClicked = (menu) => {
      title.value = menu.label;
      step.value++;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", _hoisted_2$2, [
          createVNode(QIcon, {
            name: "bi-arrow-left-short",
            size: "24px",
            class: "cursor-pointer page-item-x-margin-left",
            onClick: onBackClick
          }),
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_3$1, toDisplayString(title.value), 1),
          createVNode(QSpace),
          createVNode(QIcon, {
            name: "bi-x",
            size: "24px",
            class: "cursor-pointer",
            onClick: onCloseClick
          }),
          _cache[0] || (_cache[0] = createBaseVNode("div", { class: "page-item-x-margin-left" }, null, -1))
        ]),
        step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_4, [
          createVNode(SidebarMenu, { onClicked: onMenuClicked })
        ])) : createCommentVNode("", true),
        step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_5, [
          createVNode(_sfc_main$4, {
            ref_key: "settingInnerView",
            ref: settingInnerView,
            onBack: onInnerBack
          }, null, 512)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$1 = { class: "full-width full-height" };
const _hoisted_2$1 = { key: 0 };
const _hoisted_3 = { key: 1 };
const _sfc_main$2 = defineComponent({
  __name: "SettingView",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        unref(localStore).setting.extensionMode ? (openBlock(), createElementBlock("div", _hoisted_2$1, [
          createVNode(_sfc_main$3)
        ])) : (openBlock(), createElementBlock("div", _hoisted_3, [
          createVNode(_sfc_main$6)
        ]))
      ]);
    };
  }
});
const _hoisted_1 = { class: "full-width" };
const _hoisted_2 = {
  key: 1,
  class: "full-width full-height"
};
const _sfc_main$1 = defineComponent({
  __name: "HomeView",
  setup(__props) {
    const showSettingMenu = computed(() => localStore.setting.showSettingMenu);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$O),
        !showSettingMenu.value ? (openBlock(), createBlock(_sfc_main$p, { key: 0 })) : (openBlock(), createElementBlock("div", _hoisted_2, [
          createVNode(_sfc_main$2)
        ]))
      ]);
    };
  }
});
const _sfc_main = defineComponent({
  __name: "HomePage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1);
    };
  }
});
export { _sfc_main as default };

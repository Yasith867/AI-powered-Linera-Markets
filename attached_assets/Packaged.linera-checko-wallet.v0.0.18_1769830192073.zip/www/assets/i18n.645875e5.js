import { b as boot } from "./index.facf9114.js";
import { m as messages } from "./index.1227b8e8.js";
import { c as createI18n } from "./vue-i18n.runtime.8c1649dd.js";
var i18n = boot(({ app }) => {
  const i18n2 = createI18n({
    locale: "en-US",
    legacy: false,
    messages
  });
  app.use(i18n2);
});
export { i18n as default };

import { N as Notify, a5 as defineStore, a6 as useSettingStore, a7 as settingDef, t as createComponent, h } from "./index.facf9114.js";
var NotifyType = /* @__PURE__ */ ((NotifyType2) => {
  NotifyType2["Error"] = "error";
  NotifyType2["Info"] = "info";
  NotifyType2["Warning"] = "warning";
  NotifyType2["Waiting"] = "waiting";
  NotifyType2["Success"] = "success";
  return NotifyType2;
})(NotifyType || {});
const mergeMessage = (notification2) => {
  if (notification2.Message) {
    if (notification2.Description) {
      return notification2.Message + "(" + notification2.Description + ")";
    }
    return notification2.Message;
  }
  return notification2.Description;
};
const success = (notification2) => {
  Notify.create({
    type: "positive",
    message: notification2.Title,
    caption: mergeMessage(notification2)
  });
};
const fail = (notification2) => {
  Notify.create({
    type: "negative",
    message: notification2.Title,
    caption: mergeMessage(notification2)
  });
};
const warning = (notification2) => {
  Notify.create({
    type: "warning",
    message: notification2.Title,
    caption: mergeMessage(notification2)
  });
};
const info = (notification2) => {
  Notify.create({
    type: "positive",
    message: notification2.Title,
    caption: mergeMessage(notification2)
  });
};
const notify$1 = (notification2) => {
  if (!notification2.Popup) {
    return;
  }
  switch (notification2.Type) {
    case NotifyType.Success:
      success(notification2);
      break;
    case NotifyType.Error:
      fail(notification2);
      break;
    case NotifyType.Info:
      info(notification2);
      break;
    case NotifyType.Warning:
      warning(notification2);
      break;
    case NotifyType.Waiting:
      return Notify.create({
        type: "ongoing",
        message: notification2.Message
      });
  }
};
const useNotificationStore = defineStore("notifications", {
  state: () => ({
    Notifications: []
  }),
  getters: {},
  actions: {
    pushNotification(notification2) {
      this.Notifications.push(notification2);
    },
    popNotification() {
      if (this.Notifications.length > 0) {
        const notification2 = this.Notifications[0];
        this.Notifications = this.Notifications.splice(0, 1);
        return notification2;
      }
      return void 0;
    }
  }
});
var notify = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  useNotificationStore,
  notify: notify$1,
  NotifyType
}, Symbol.toStringTag, { value: "Module" }));
var RpcMethod = /* @__PURE__ */ ((RpcMethod2) => {
  RpcMethod2["ADD_ETHEREUM_CHAIN"] = "wallet_addEthereumChain";
  RpcMethod2["ETH_ACCOUNTS"] = "eth_accounts";
  RpcMethod2["ETH_DECRYPT"] = "eth_decrypt";
  RpcMethod2["ETH_CHAIN_ID"] = "eth_chainId";
  RpcMethod2["ETH_GET_ENCRYPTION_PUBLIC_KEY"] = "eth_getEncryptionPublicKey";
  RpcMethod2["ETH_GET_BLOCK_BY_NUMBER"] = "eth_getBlockByNumber";
  RpcMethod2["ETH_REQUEST_ACCOUNTS"] = "eth_requestAccounts";
  RpcMethod2["ETH_SIGN"] = "eth_sign";
  RpcMethod2["ETH_SIGN_TRANSACTION"] = "eth_signTransaction";
  RpcMethod2["ETH_SIGN_TYPED_DATA"] = "eth_signTypedData";
  RpcMethod2["ETH_SIGN_TYPED_DATA_V1"] = "eth_signTypedData_v1";
  RpcMethod2["ETH_SIGN_TYPED_DATA_V3"] = "eth_signTypedData_v3";
  RpcMethod2["ETH_SIGN_TYPED_DATA_V4"] = "eth_signTypedData_v4";
  RpcMethod2["GET_PROVIDER_STATE"] = "metamask_getProviderState";
  RpcMethod2["LOG_WEB3_SHIM_USAGE"] = "metamask_logWeb3ShimUsage";
  RpcMethod2["PERSONAL_SIGN"] = "personal_sign";
  RpcMethod2["SEND_METADATA"] = "metamask_sendDomainMetadata";
  RpcMethod2["SWITCH_ETHEREUM_CHAIN"] = "wallet_switchEthereumChain";
  RpcMethod2["TRANSACTION"] = "transaction";
  RpcMethod2["WALLET_REQUEST_PERMISSIONS"] = "wallet_requestPermissions";
  RpcMethod2["WATCH_ASSET"] = "wallet_watchAsset";
  RpcMethod2["CHECKO_PING"] = "checko_ping";
  RpcMethod2["LINERA_SUBSCRIBE"] = "linera_subscribe";
  RpcMethod2["LINERA_UNSUBSCRIBE"] = "linera_unsubscribe";
  RpcMethod2["LINERA_GRAPHQL_MUTATION"] = "linera_graphqlMutation";
  RpcMethod2["LINERA_GRAPHQL_QUERY"] = "linera_graphqlQuery";
  RpcMethod2["ETH_GET_BALANCE"] = "eth_getBalance";
  return RpcMethod2;
})(RpcMethod || {});
Object.values(RpcMethod);
var PopupRequestType = /* @__PURE__ */ ((PopupRequestType2) => {
  PopupRequestType2["CONFIRMATION"] = "confirmation";
  PopupRequestType2["EXECUTION"] = "execution";
  return PopupRequestType2;
})(PopupRequestType || {});
const lineraGraphqlQueryApplicationId = (request) => {
  return request?.request?.params?.applicationId;
};
const lineraGraphqlQueryPublicKey = (request) => {
  return request?.request?.params?.publicKey;
};
const lineraGraphqlMutationQueryWithQuery = (query) => {
  const patterns = query?.match(/[)\s].*{\s+([a-zA-Z]+)[($\s]/);
  if (!patterns)
    return void 0;
  if (patterns?.length < 2)
    return void 0;
  return patterns[1][0].toUpperCase() + patterns[1].slice(1);
};
const lineraGraphqlMutationOperation = (request) => {
  const query = request?.request?.params?.query?.query?.replace("\n", "");
  return lineraGraphqlMutationQueryWithQuery(query);
};
const lineraGraphqlQuery = (request) => {
  return request?.request?.params?.query;
};
const usePopupStore = defineStore("popups", {
  state: () => ({
    popups: /* @__PURE__ */ new Map(),
    connections: /* @__PURE__ */ new Map(),
    popupType: PopupRequestType.CONFIRMATION,
    popupOrigin: "",
    popupRequest: RpcMethod.ETH_REQUEST_ACCOUNTS,
    popupRequestId: 0,
    popupPrivData: void 0,
    popupUpdated: false
  }),
  getters: {
    requestIds() {
      return Array.from(this.popups.keys());
    },
    connection() {
      return (origin) => {
        return this.connections.get(origin);
      };
    },
    currentConnection() {
      return this.connection(this.popupOrigin);
    },
    _popupType() {
      return this.popupType;
    },
    _popupRequest() {
      return this.popupRequest;
    },
    _popupPayload() {
      return this.popups.get(this.popupRequestId);
    },
    _popupRespond() {
      const popup2 = this.popups.get(this.popupRequestId);
      return popup2?.respond;
    },
    _popupPrivData() {
      return this.popupPrivData;
    },
    _popupUpdated() {
      return this.popupUpdated;
    }
  },
  actions: {
    insertRequest(payload) {
      this.popupType = payload.data.type;
      this.popupRequest = payload.data.request.request.method;
      this.popupRequestId = Number(payload.data.request.request.id);
      this.popups.set(Number(payload.data.request.request.id), payload);
      this.popupUpdated = false;
    },
    updateRequest(payload) {
      if (this.popupRequestId !== Number(payload.data.request.request.id)) {
        return false;
      }
      this.popupPrivData = payload.data.privData;
      this.popups.set(Number(payload.data.request.request.id), payload);
      this.popupUpdated = true;
      return true;
    },
    removeRequest(requestId) {
      this.popups.delete(requestId);
    },
    addConnection(connection) {
      this.popupOrigin = connection.origin;
      this.connections.set(connection.origin, connection);
    }
  }
});
const useOperationStore = defineStore("operations", {
  state: () => ({
    operations: []
  }),
  getters: {},
  actions: {}
});
const notification = useNotificationStore();
const setting = useSettingStore();
const popup = usePopupStore();
const operation = useOperationStore();
const localStore = {
  notification,
  notify,
  setting,
  settingDef,
  popup,
  operation
};
var QSpace = createComponent({
  name: "QSpace",
  setup() {
    const space = h("div", { class: "q-space" });
    return () => space;
  }
});
export { PopupRequestType as P, QSpace as Q, RpcMethod as R, lineraGraphqlMutationQueryWithQuery as a, lineraGraphqlQueryPublicKey as b, lineraGraphqlQueryApplicationId as c, lineraGraphqlMutationOperation as d, lineraGraphqlQuery as e, localStore as l };

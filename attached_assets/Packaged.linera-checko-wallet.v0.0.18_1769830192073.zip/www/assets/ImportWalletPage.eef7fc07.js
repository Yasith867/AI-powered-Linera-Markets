import { Q as QSpace, l as localStore } from "./QSpace.27146b0a.js";
import { Q as QStepper, _ as _sfc_main$5, a as QStep } from "./GenerateKey.376e5b53.js";
import { d as defineComponent, aq as useModel, H as openBlock, I as createElementBlock, K as createBaseVNode, L as toDisplayString, k as createVNode, r as ref, Q as QIcon, F as Fragment, M as renderList, S as normalizeClass, as as toRef, a as computed, J as withCtx, aw as QBtn, u as unref, W as useRouter, P as createBlock } from "./index.facf9114.js";
import { a as _sfc_main$4, _ as _sfc_main$6 } from "./NewPassword.aa418b24.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import "./db.46ddc67f.js";
import "./application.ca271889.js";
import { O as Owner } from "./owner.bc60a389.js";
import { P as Password } from "./password.cda421c2.js";
import "./index.d2b21240.js";
import { u as useI18n } from "./vue-i18n.runtime.8c1649dd.js";
import "./use-panel.a32f17c8.js";
import "./selection.ef9ae985.js";
import "./use-timeout.0aac84f1.js";
import "./use-dark.ea7d71c2.js";
import "./position-engine.5060c7a9.js";
import "./microchain.44c150a3.js";
import "./verify.2de89a24.js";
import "./_commonjsHelpers.294d03c4.js";
import "./private.use-form.4c048d1b.js";
const _hoisted_1$3 = { class: "full-width text-center flex items-center justify-center onboarding-content" };
const _hoisted_2$2 = { class: "onboarding-page-title" };
const _hoisted_3$2 = ["innerHTML"];
const _sfc_main$3 = defineComponent({
  __name: "ResetPassword",
  props: {
    "password": { default: "" },
    "passwordModifiers": {},
    "error": { type: Boolean, ...{ default: false } },
    "errorModifiers": {}
  },
  emits: ["update:password", "update:error"],
  setup(__props) {
    const password = useModel(__props, "password");
    const error = useModel(__props, "error");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        createBaseVNode("h5", _hoisted_2$2, toDisplayString(_ctx.$t("MSG_RESET_PASSWORD")), 1),
        createBaseVNode("p", null, toDisplayString(_ctx.$t("MSG_CHECKO_NEVER_STORE_YOUR_PASSWORD_OUTSIDE_WALLET")), 1),
        createBaseVNode("p", null, toDisplayString(_ctx.$t("MSG_MAKE_SURE_STORED_ALL_BEFORE_CONTINUE")), 1),
        createVNode(_sfc_main$4, {
          password: password.value,
          "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
          error: error.value,
          "onUpdate:error": _cache[1] || (_cache[1] = ($event) => error.value = $event)
        }, null, 8, ["password", "error"]),
        createBaseVNode("p", {
          class: "text-center vertical-sections-margin text-grey-6",
          innerHTML: _ctx.$t("MSG_BY_CONTINUE_YOU_UNDERSTAND_CHECKO_CANNOT_RECOVER_PASSWORD")
        }, null, 8, _hoisted_3$2)
      ]);
    };
  }
});
const _hoisted_1$2 = { class: "fill-parent text-center onboarding-content" };
const _hoisted_2$1 = ["innerHTML"];
const _hoisted_3$1 = ["innerHTML"];
const _hoisted_4$1 = { class: "text-left full-width tip info info-bg text-grey-8 row vertical-sections-margin" };
const _hoisted_5$1 = {
  class: "page-item-x-margin-left",
  style: { width: "calc(100% - 26px)" }
};
const _hoisted_6 = { class: "row vertical-sections-margin" };
const _sfc_main$2 = defineComponent({
  __name: "ImportMnemonicView",
  props: {
    "modelValue": {
      default: [
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
      ]
    },
    "modelModifiers": {}
  },
  emits: ["update:modelValue"],
  setup(__props) {
    const mnemonic = useModel(__props, "modelValue");
    const focusIndex = ref(0);
    const onFocus = (index) => {
      focusIndex.value = index;
    };
    const onPaste = (index, evt) => {
      evt.preventDefault();
      const _mnemonic = mnemonic.value;
      const copied = evt.clipboardData.getData("text").split(/(\s+)/).filter((v) => v.trim().length > 0);
      if (copied.length === 1) {
        _mnemonic[index] = copied[0];
      } else {
        copied.forEach((v, i) => {
          if (i < _mnemonic.length)
            _mnemonic[i] = v;
        });
      }
      mnemonic.value = [..._mnemonic];
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("h5", {
          class: "onboarding-page-title",
          innerHTML: _ctx.$t("MSG_ACCESS_YOUR_WALLET_WITH_SECRET_RECOVERY_PHRASE")
        }, null, 8, _hoisted_2$1),
        createBaseVNode("div", {
          innerHTML: _ctx.$t("MSG_CHECKO_CANNOT_RECOVERY_YOUR_WALLET")
        }, null, 8, _hoisted_3$1),
        createBaseVNode("div", _hoisted_4$1, [
          createVNode(QIcon, {
            name: "bi-info-circle-fill",
            color: "green-4",
            size: "20px"
          }),
          createBaseVNode("div", _hoisted_5$1, toDisplayString(_ctx.$t("MSG_PASTE_RECOVERY_PHRASE_INTO_ANY_FIELD")), 1)
        ]),
        createBaseVNode("div", _hoisted_6, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(mnemonic.value, (word, i) => {
            return openBlock(), createElementBlock("div", {
              key: i,
              class: normalizeClass(["mnemonic-grid", i % 5 === 0 ? "mnemonic-grid-start" : "", i < 5 ? "mnemonic-grid-top" : ""])
            }, [
              createVNode(QInput, {
                borderless: "",
                dense: "",
                "hide-bottom-space": "",
                modelValue: mnemonic.value[i],
                "onUpdate:modelValue": ($event) => mnemonic.value[i] = $event,
                autofocus: i === focusIndex.value,
                onPaste: (evt) => onPaste(i, evt),
                onFocus: () => onFocus(i)
              }, null, 8, ["modelValue", "onUpdate:modelValue", "autofocus", "onPaste", "onFocus"])
            ], 2);
          }), 128))
        ])
      ]);
    };
  }
});
const _hoisted_1$1 = { class: "bg-white" };
const _hoisted_2 = { class: "row" };
const _hoisted_3 = { class: "row" };
const _hoisted_4 = { class: "full-width row" };
const _hoisted_5 = { class: "onboarding-btns extra-large-margin-bottom page-x-padding" };
const _sfc_main$1 = defineComponent({
  __name: "ImportWallet",
  props: {
    reset: { type: Boolean, default: false }
  },
  setup(__props) {
    const { t } = useI18n({ useScope: "global" });
    const props = __props;
    const reset = toRef(props, "reset");
    const step = ref(1);
    const password = ref("");
    const passwordError = ref(false);
    const mnemonic = ref([
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      "",
      ""
    ]);
    const router = useRouter();
    const generateKey = ref();
    const canGotoNext = () => {
      switch (step.value) {
        case 1:
          return !passwordError.value && password.value.length;
        case 2:
          return mnemonic.value.findIndex((v) => v.length === 0) < 0;
        default:
          return true;
      }
    };
    const btnText = computed(() => {
      switch (step.value) {
        case 1:
          return t("MSG_SAVE_PASSWORD");
        case 2:
          return t("MSG_IMPORT_ACCOUNT");
      }
      return t("MSG_NEXT");
    });
    const savePassword = () => {
      Password.save(password.value).then(() => {
      }).catch((error) => {
        localStore.notification.pushNotification({
          Title: "Save password",
          Message: `Save password failed: ${error}`,
          Popup: true,
          Type: localStore.notify.NotifyType.Error
        });
      });
    };
    const validateAccount = () => {
      generateKey.value?.createAccountWithMnemonic(mnemonic.value, password.value).then(async (privateKeyHex) => {
        await Owner.create(privateKeyHex, void 0, password.value);
        void router.push({ path: localStore.setting.formalizePath("/home") });
      }).catch((error) => {
        localStore.notification.pushNotification({
          Title: "Import account",
          Message: `Import account failed: ${error}`,
          Popup: true,
          Type: localStore.notify.NotifyType.Error
        });
      });
    };
    const onNextStepClick = () => {
      switch (step.value) {
        case 1:
          step.value++;
          break;
        case 2:
          savePassword();
          validateAccount();
          break;
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", {
          class: normalizeClass(["text-center onboarding-container", unref(localStore).setting.extensionMode ? "" : "onboarding-stepper-padding"])
        }, [
          createBaseVNode("div", _hoisted_1$1, [
            createVNode(QStepper, {
              flat: "",
              modelValue: step.value,
              "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => step.value = $event),
              "active-color": "brown-8",
              "inactive-color": "brown-4",
              "done-color": "green-6",
              animated: "",
              "alternative-labels": "",
              "header-class": "hide"
            }, {
              default: withCtx(() => [
                createVNode(QStep, {
                  name: 1,
                  title: _ctx.$t("MSG_CREATE_PASSWORD"),
                  done: step.value > 1
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_2, [
                      createVNode(QSpace),
                      reset.value ? (openBlock(), createBlock(_sfc_main$3, {
                        key: 0,
                        password: password.value,
                        "onUpdate:password": _cache[0] || (_cache[0] = ($event) => password.value = $event),
                        error: passwordError.value,
                        "onUpdate:error": _cache[1] || (_cache[1] = ($event) => passwordError.value = $event)
                      }, null, 8, ["password", "error"])) : (openBlock(), createBlock(_sfc_main$6, {
                        key: 1,
                        password: password.value,
                        "onUpdate:password": _cache[2] || (_cache[2] = ($event) => password.value = $event),
                        error: passwordError.value,
                        "onUpdate:error": _cache[3] || (_cache[3] = ($event) => passwordError.value = $event)
                      }, null, 8, ["password", "error"])),
                      createVNode(QSpace)
                    ])
                  ]),
                  _: 1
                }, 8, ["title", "done"]),
                createVNode(QStep, {
                  name: 2,
                  title: _ctx.$t("MSG_IMPORT_ACCOUNT"),
                  done: step.value > 2
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_3, [
                      createVNode(QSpace),
                      createVNode(_sfc_main$2, {
                        modelValue: mnemonic.value,
                        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => mnemonic.value = $event)
                      }, null, 8, ["modelValue"]),
                      createVNode(QSpace)
                    ])
                  ]),
                  _: 1
                }, 8, ["title", "done"])
              ]),
              _: 1
            }, 8, ["modelValue"]),
            createBaseVNode("div", _hoisted_4, [
              createVNode(QSpace),
              createBaseVNode("div", _hoisted_5, [
                createVNode(QBtn, {
                  flat: "",
                  class: "btn full-width",
                  label: btnText.value,
                  disable: !canGotoNext(),
                  onClick: onNextStepClick,
                  "no-caps": ""
                }, null, 8, ["label", "disable"])
              ]),
              createVNode(QSpace)
            ])
          ])
        ], 2),
        createVNode(_sfc_main$5, {
          ref_key: "generateKey",
          ref: generateKey
        }, null, 512)
      ], 64);
    };
  }
});
const _hoisted_1 = { class: "full-width" };
const _sfc_main = defineComponent({
  __name: "ImportWalletPage",
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$1)
      ]);
    };
  }
});
export { _sfc_main as default };

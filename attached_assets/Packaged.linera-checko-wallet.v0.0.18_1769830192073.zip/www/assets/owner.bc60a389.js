var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { a as dbWallet, d as dbBase } from "./db.46ddc67f.js";
import { d as decryptPassword, E as Ed25519, L as DEFAULT_ACCOUNT_NAME, P as buildOwner } from "./application.ca271889.js";
import { b as MicrochainOwner, M as Microchain } from "./microchain.44c150a3.js";
class MicrochainFungibleTokenBalance {
}
__publicField(MicrochainFungibleTokenBalance, "create", async (microchain, tokenId, balance) => {
  await dbWallet.microchainFungibleTokenBalances.add({
    microchain,
    tokenId,
    balance
  });
});
__publicField(MicrochainFungibleTokenBalance, "update", async (balance) => {
  await dbWallet.microchainFungibleTokenBalances.update(balance.id, balance);
});
__publicField(MicrochainFungibleTokenBalance, "balance", async (microchain, tokenId) => {
  return (await dbWallet.microchainFungibleTokenBalances.toArray()).find(
    (el) => el.microchain === microchain && el.tokenId === tokenId
  );
});
__publicField(MicrochainFungibleTokenBalance, "balances", async (owner, tokenId) => {
  const microchains = (await MicrochainOwner.ownerMicrochainOwners(owner)).map((el) => el.microchain);
  return (await dbWallet.microchainFungibleTokenBalances.toArray()).filter(
    (el) => microchains.includes(el.microchain) && el.tokenId === tokenId && el.balance > 0
  );
});
class MicrochainOwnerFungibleTokenBalance {
}
__publicField(MicrochainOwnerFungibleTokenBalance, "balance", async (microchain, owner, token) => {
  return (await dbWallet.microchainOwnerFungibleTokenBalances.toArray()).find(
    (el) => el.microchain === microchain && el.owner === owner && el.tokenId === token
  );
});
__publicField(MicrochainOwnerFungibleTokenBalance, "balances", async (owner, token) => {
  return (await dbWallet.microchainOwnerFungibleTokenBalances.toArray()).filter(
    (el) => el.owner === owner && el.tokenId === token && el.balance > 0
  );
});
__publicField(MicrochainOwnerFungibleTokenBalance, "create", async (microchain, owner, token, balance) => {
  return await dbWallet.microchainOwnerFungibleTokenBalances.add({
    microchain,
    owner,
    tokenId: token,
    balance
  });
});
__publicField(MicrochainOwnerFungibleTokenBalance, "update", async (balance) => {
  return await dbWallet.microchainOwnerFungibleTokenBalances.update(
    balance.id,
    balance
  );
});
const _Owner = class {
};
let Owner = _Owner;
__publicField(Owner, "resetSelected", async () => {
  const owners = (await dbWallet.owners.toArray()).filter((el) => el.selected);
  for (const owner of owners) {
    await dbWallet.owners.update(owner.id, { selected: false });
  }
});
__publicField(Owner, "create", async (privateKeyHex, name, _password) => {
  if (name && await _Owner.exists(name))
    return Promise.reject("Already exist");
  if (!_password) {
    const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
    if (!fingerPrint)
      return Promise.reject("Invalid fingerprint");
    const passwd = (await dbBase.passwords.toArray()).find(
      (el) => el.active
    );
    if (passwd)
      _password = decryptPassword(passwd, fingerPrint.fingerPrint);
  }
  if (!privateKeyHex.length || !_password?.length) {
    throw Error("Invalid owner materials");
  }
  const publicKeyHex = Ed25519.publicHex(privateKeyHex);
  if (!name?.length) {
    name = DEFAULT_ACCOUNT_NAME + " " + (await dbWallet.owners.count()).toString();
  }
  if (await dbWallet.owners.where("address").equals(publicKeyHex).first() !== void 0)
    return;
  const owner = await buildOwner(privateKeyHex, _password, name);
  await _Owner.resetSelected();
  await dbWallet.owners.add(owner);
});
__publicField(Owner, "update", async (owner) => {
  if (await _Owner.exists(owner.name) && !await _Owner.exists(owner.name, owner.id))
    return Promise.reject("Already exists");
  if (owner.selected)
    await _Owner.resetSelected();
  await dbWallet.owners.update(owner.id, owner);
});
__publicField(Owner, "delete", async (id) => {
  await dbWallet.owners.delete(id);
});
__publicField(Owner, "ownerBalance", async (owner, tokenId, microchain) => {
  const token = await dbBase.tokens.get(tokenId);
  if (!token)
    return Promise.reject("Invalid token");
  const microchains = (await Microchain.microchains(0, 1e3, true, void 0, owner.owner)).filter(
    (_microchain) => !microchain || _microchain.microchain === microchain
  );
  let balance = 0;
  for (const microchain2 of microchains) {
    balance += (await MicrochainFungibleTokenBalance.balance(
      microchain2.microchain,
      tokenId
    ))?.balance || 0;
    balance += (await MicrochainOwnerFungibleTokenBalance.balance(
      microchain2.microchain,
      owner.owner,
      tokenId
    ))?.balance || 0;
  }
  return {
    tokenBalance: balance,
    usdBalance: balance * (token?.usdCurrency || 0)
  };
});
__publicField(Owner, "getOwnerWithPublicKey", async (publicKey) => {
  return (await dbWallet.owners.toArray()).find(
    (el) => el.address === publicKey
  );
});
__publicField(Owner, "owner", async (owner) => {
  return (await dbWallet.owners.toArray()).find((el) => el.owner === owner);
});
__publicField(Owner, "ownerWithPublicKeyPrefix", async (prefix) => {
  return (await dbWallet.owners.toArray()).find(
    (el) => el.address.includes(prefix.slice(prefix.startsWith("0x") ? 2 : 0))
  );
});
__publicField(Owner, "publicKey2Owner", async (publicKey) => {
  return (await dbWallet.owners.toArray()).find(
    (el) => el.address === publicKey
  )?.owner;
});
__publicField(Owner, "selected", async () => {
  return (await dbWallet.owners.toArray()).find((el) => el.selected);
});
__publicField(Owner, "exists", async (name, id) => {
  return await dbWallet.owners.where("name").equals(name).and((owner) => id === void 0 || owner.id === id).count() > 0;
});
__publicField(Owner, "addresses", async () => {
  return (await dbWallet.owners.toArray()).map((el) => el.address);
});
export { MicrochainOwnerFungibleTokenBalance as M, Owner as O, MicrochainFungibleTokenBalance as a };

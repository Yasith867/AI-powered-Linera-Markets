var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { d as dbBase } from "./db.46ddc67f.js";
class LoginTimestamp {
}
__publicField(LoginTimestamp, "save", async () => {
  return new Promise((resolve, reject) => {
    dbBase.lastLogin.count().then(async (cnt) => {
      if (cnt === 0) {
        await dbBase.lastLogin.add({ timestamp: Date.now() });
      } else {
        const ts = (await dbBase.lastLogin.toArray()).find(() => true);
        await dbBase.lastLogin.update(ts?.id, { timestamp: Date.now() });
      }
      resolve(void 0);
    }).catch((error) => {
      reject(error);
    });
  });
});
__publicField(LoginTimestamp, "loginTimeout", async () => {
  const timestamp = (await dbBase.lastLogin.toArray()).find(
    () => true
  )?.timestamp;
  return timestamp === void 0 || timestamp < Date.now() - 4 * 60 * 60 * 1e3;
});
export { LoginTimestamp as L };

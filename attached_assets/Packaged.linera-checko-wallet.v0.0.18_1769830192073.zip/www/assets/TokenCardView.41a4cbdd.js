var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
import { x as BALANCE, y as BALANCES, C as CREATOR_CHAIN_ID, T as TokenType, A as APPLICATION_URLS, z as BALANCE_OF, D as graphql_deserialize_meme_operation, F as TRANSFER_MEME, s as OperationType, G as ApplicationType, J as MEME } from "./application.ca271889.js";
import { p as provideApolloClient, a as useQuery } from "./index.d2b21240.js";
import { c as getClientOptionsWithEndpointType, E as EndpointType, A as ApolloClient, r as rootData, g as getClientOptionsWithBaseUrl, h as data, s as stringify, v as v4, B as BlockWorker, d as BlockEventType } from "./block.fef35c05.js";
import { a as dbWallet, d as dbBase, l as liveQuery } from "./db.46ddc67f.js";
import { T as Token, C as ChainOperation, a as QItem } from "./TokenBridge.0a26909e.js";
import { M as Microchain } from "./microchain.44c150a3.js";
import { l as localStore, Q as QSpace } from "./QSpace.27146b0a.js";
import { _ as _sfc_main$a, a as QStep, Q as QStepper } from "./GenerateKey.376e5b53.js";
import { d as defineComponent, ar as mergeModels, as as toRef, aq as useModel, H as openBlock, I as createElementBlock, K as createBaseVNode, L as toDisplayString, k as createVNode, Q as QIcon, r as ref, o as onMounted, J as withCtx, aw as QBtn, R as createTextVNode, a as computed, V as createCommentVNode, P as createBlock, _ as _export_sfc, w as watch, m as onBeforeUnmount, S as normalizeClass, u as unref, aF as QAvatar } from "./index.facf9114.js";
import { Q as QCard } from "./QCard.c3b804ca.js";
import { g as _sfc_main$8, _ as _sfc_main$b, Q as QBadge, l as lineraLogo } from "./MicrochainsInnerView.9e5fbcce.js";
import { Q as QInput } from "./QInput.c11607b6.js";
import { O as Owner } from "./owner.bc60a389.js";
import { _ as _sfc_main$9 } from "./PasswordBridge.41db8c1b.js";
import { Q as QImg } from "./QImg.606c211a.js";
import { u as useObservable } from "./index.f58c37d0.js";
class OwnerBalance {
}
__publicField(OwnerBalance, "getTokenBalance", async (owner, tokenId) => {
  owner = owner || (await dbWallet.owners.toArray()).find((el) => el.selected);
  if (!owner)
    return;
  const microchainOwners = (await dbWallet.microchainOwners.toArray()).filter(
    (el) => el.owner === owner?.owner
  );
  const microchains = microchainOwners.reduce(
    (microchainIds, a) => {
      microchainIds.push(a.microchain);
      return microchainIds;
    },
    []
  );
  const microchainFungibleTokenBalances = (await dbWallet.microchainFungibleTokenBalances.where("microchain").anyOf(microchains).toArray()).filter((el) => {
    return tokenId !== void 0 ? tokenId === el.tokenId : true;
  });
  const microchainOwnerFungibleTokenBalances = (await dbWallet.microchainOwnerFungibleTokenBalances.where("owner").equals(owner?.owner).toArray()).filter((el) => {
    return tokenId !== void 0 ? tokenId === el.tokenId : true;
  });
  const tokenIds = microchainFungibleTokenBalances.reduce(
    (ids, a) => {
      ids.push(a.tokenId);
      return ids;
    },
    []
  );
  tokenIds.concat(
    ...microchainOwnerFungibleTokenBalances.reduce(
      (ids, a) => {
        ids.push(a.tokenId);
        return ids;
      },
      []
    )
  );
  if (tokenId === void 0)
    return 0;
  return microchainOwnerFungibleTokenBalances.reduce(
    (sum, a) => sum + Number(a.balance || 0),
    0
  ) + microchainFungibleTokenBalances.reduce(
    (sum, a) => sum + Number(a.balance || 0),
    0
  );
});
__publicField(OwnerBalance, "getUsdBalance", async (owner, tokenId) => {
  owner = owner || (await dbWallet.owners.toArray()).find((el) => el.selected);
  if (!owner)
    return;
  let usdBalance = 0;
  const microchainOwners = (await dbWallet.microchainOwners.toArray()).filter(
    (el) => el.owner === owner?.owner
  );
  const microchains = microchainOwners.reduce(
    (microchainIds, a) => {
      microchainIds.push(a.microchain);
      return microchainIds;
    },
    []
  );
  const microchainFungibleTokenBalances = (await dbWallet.microchainFungibleTokenBalances.where("microchain").anyOf(microchains).toArray()).filter((el) => {
    return tokenId !== void 0 ? tokenId === el.tokenId : true;
  });
  const microchainOwnerFungibleTokenBalances = (await dbWallet.microchainOwnerFungibleTokenBalances.where("owner").equals(owner?.owner).toArray()).filter((el) => {
    return tokenId !== void 0 ? tokenId === el.tokenId : true;
  });
  const tokenIds = microchainFungibleTokenBalances.reduce(
    (ids, a) => {
      ids.push(a.tokenId);
      return ids;
    },
    []
  );
  tokenIds.concat(
    ...microchainOwnerFungibleTokenBalances.reduce(
      (ids, a) => {
        ids.push(a.tokenId);
        return ids;
      },
      []
    )
  );
  const tokens = await dbBase.tokens.where("id").anyOf(tokenIds).toArray();
  usdBalance = microchainOwnerFungibleTokenBalances.reduce(
    (sum, a) => sum + Number(a.balance || 0) * (tokens.find((el) => el.id === a.tokenId)?.usdCurrency || 0),
    0
  ) + microchainFungibleTokenBalances.reduce(
    (sum, a) => sum + Number(a.balance || 0) * (tokens.find((el) => el.id === a.tokenId)?.usdCurrency || 0),
    0
  );
  return usdBalance;
});
const _Account = class {
};
let Account = _Account;
__publicField(Account, "CHAIN", "0x00");
__publicField(Account, "balance", async (chainId, owner) => {
  const options = await getClientOptionsWithEndpointType(EndpointType.Rpc);
  if (!options)
    return 0;
  const apolloClient = new ApolloClient(options);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      BALANCE,
      {
        chainId,
        owner
      },
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      resolve(Number(rootData(res).balance));
    });
    onError((error) => {
      reject(new Error(`Get account balance: ${error}`));
    });
  });
});
__publicField(Account, "ownerBalance", (balances, chainId, owner) => {
  return balances[chainId].ownerBalances[_Account.accountOwner(owner)] || 0;
});
__publicField(Account, "accountOwner", (owner) => {
  return owner.startsWith("0x") ? owner : "0x" + owner;
});
__publicField(Account, "balances", async (chainOwners) => {
  const options = await getClientOptionsWithEndpointType(EndpointType.Rpc);
  if (!options)
    return void 0;
  const apolloClient = new ApolloClient(options);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      BALANCES,
      {
        chainOwners
      },
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      resolve(
        rootData(res).balances
      );
    });
    onError((error) => {
      reject(new Error(`Get chain account balances: ${error}`));
    });
  });
});
__publicField(Account, "accountDescription", (account) => {
  return `${account.chainId}:${_Account.accountOwner(account.owner)}`;
});
class ApplicationCreatorChain {
}
__publicField(ApplicationCreatorChain, "id", async (chainId, applicationId) => {
  const options = await getClientOptionsWithEndpointType(
    EndpointType.Rpc,
    chainId,
    applicationId
  );
  if (!options)
    return void 0;
  const apolloClient = new ApolloClient(options);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      CREATOR_CHAIN_ID,
      {},
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      resolve(
        rootData(res).creatorChainId
      );
    });
    onError((error) => {
      reject(new Error(`Get applications: ${error}`));
    });
  });
});
class MemeApplicationOperation {
}
__publicField(MemeApplicationOperation, "persistApplication", async (applicationId) => {
  if (await Token.exists(applicationId))
    return;
  const microchain = await Microchain.anyMicrochain();
  if (!microchain)
    return;
  const creatorChainId = await ApplicationCreatorChain.id(
    microchain.microchain,
    applicationId
  );
  if (!creatorChainId)
    return;
  const options = getClientOptionsWithBaseUrl(
    APPLICATION_URLS.PROXY_BASE,
    void 0,
    creatorChainId,
    applicationId
  );
  const apolloClient = new ApolloClient(options);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      MEME,
      {},
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      const token = data(res, "meme");
      void Token.create({
        name: token.name,
        description: token.metadata.description,
        totalSupply: Number(token.totalSupply),
        ticker: token.ticker,
        tokenType: TokenType.Fungible,
        logoStoreType: token.metadata.logoStoreType,
        logo: token.metadata.logo,
        applicationId,
        creatorChainId,
        native: false,
        usdCurrency: 0,
        discord: token.metadata.discord,
        telegram: token.metadata.telegram,
        twitter: token.metadata.twitter,
        website: token.metadata.website,
        github: token.metadata.github,
        liveStream: token.metadata.liveStream
      });
      resolve(void 0);
    });
    onError((e) => {
      console.log(`Query token metadata: ${e}`);
      reject(e);
    });
  });
});
__publicField(MemeApplicationOperation, "balanceOf", async (applicationId, chainId, owner) => {
  const chainAccountOwner = {
    chainId,
    owner: Account.accountOwner(owner)
  };
  const token = await Token.token(applicationId);
  if (!token)
    return 0;
  const options = getClientOptionsWithBaseUrl(
    APPLICATION_URLS.PROXY_BASE,
    void 0,
    token.creatorChainId,
    applicationId
  );
  if (!options)
    return 0;
  const apolloClient = new ApolloClient(options);
  const { onResult, onError } = provideApolloClient(apolloClient)(
    () => useQuery(
      BALANCE_OF,
      {
        owner: Account.accountDescription(chainAccountOwner)
      },
      {
        fetchPolicy: "network-only"
      }
    )
  );
  return new Promise((resolve, reject) => {
    onResult((res) => {
      const balance = Number(data(res, "balanceOf"));
      resolve(balance);
    });
    onError((error) => {
      reject(`Query balanceOf: ${error}`);
    });
  });
});
__publicField(MemeApplicationOperation, "transfer", async (chainId, applicationId, to, amount) => {
  try {
    const variables = {
      to,
      amount: amount.toString()
    };
    const _queryBytes = await graphql_deserialize_meme_operation(
      TRANSFER_MEME.loc?.source?.body,
      stringify(variables)
    );
    const queryBytes = JSON.parse(_queryBytes);
    const operationId = v4();
    const operation = {
      operationType: OperationType.TRANSFER,
      applicationType: ApplicationType.MEME,
      operationId,
      microchain: chainId,
      operation: JSON.stringify({
        User: {
          applicationId,
          bytes: queryBytes
        }
      }),
      graphqlQuery: TRANSFER_MEME.loc?.source?.body,
      graphqlVariables: JSON.stringify(variables)
    };
    await ChainOperation.create({ ...operation });
    return operationId;
  } catch (e) {
    return Promise.reject(e);
  }
});
const _hoisted_1$6 = { class: "text-center text-bold text-grey-9 selector-title" };
const _sfc_main$7 = defineComponent({
  __name: "AccountsView",
  props: /* @__PURE__ */ mergeModels({
    persistent: { type: Boolean, default: true }
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const persistent = toRef(props, "persistent");
    const owner = useModel(__props, "modelValue");
    const emit = __emit;
    const onOwnerSelected = (_owner) => {
      owner.value = _owner;
      emit("selected", _owner);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("p", _hoisted_1$6, toDisplayString(_ctx.$t("MSG_SELECT_AN_ACCOUNT")), 1),
        createVNode(_sfc_main$8, {
          persistent: persistent.value,
          searchable: true,
          onSelected: onOwnerSelected,
          modelValue: owner.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => owner.value = $event)
        }, null, 8, ["persistent", "modelValue"])
      ]);
    };
  }
});
const _hoisted_1$5 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_2$4 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _hoisted_3$3 = { class: "text-left text-blue-8 text-bold page-item-x-margin-left" };
const _sfc_main$6 = defineComponent({
  __name: "ImportPrivateKeyMenuView",
  emits: ["create", "import", "addLedger"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const onAddAccountClick = () => {
      emit("create");
    };
    const onImportAccountClick = () => {
      emit("import");
    };
    const onAddLedgerClick = () => {
      emit("addLedger");
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          class: "row vertical-menus-margin page-item-x-margin-left cursor-pointer",
          onClick: onAddAccountClick
        }, [
          createVNode(QIcon, {
            name: "bi-plus-lg",
            size: "20px",
            color: "blue-10"
          }),
          createBaseVNode("div", _hoisted_1$5, toDisplayString(_ctx.$t("MSG_CREATE_NEW_ACCOUNT")), 1)
        ]),
        createBaseVNode("div", {
          class: "row vertical-sections-margin page-item-x-margin-left cursor-pointer",
          onClick: onImportAccountClick
        }, [
          createVNode(QIcon, {
            name: "bi-box-arrow-in-down",
            size: "20px",
            color: "blue-10"
          }),
          createBaseVNode("div", _hoisted_2$4, toDisplayString(_ctx.$t("MSG_IMPORT_PRIVATE_KEY")), 1)
        ]),
        createBaseVNode("div", {
          class: "row vertical-sections-margin page-item-x-margin-left cursor-pointer",
          onClick: onAddLedgerClick
        }, [
          createVNode(QIcon, {
            name: "bi-motherboard",
            size: "20px",
            color: "blue-10"
          }),
          createBaseVNode("div", _hoisted_3$3, toDisplayString(_ctx.$t("MSG_ADD_LEDGER")), 1)
        ])
      ]);
    };
  }
});
const _hoisted_1$4 = ["innerHTML"];
const _hoisted_2$3 = { class: "vertical-sections-margin text-grey-8 text-bold" };
const _hoisted_3$2 = { class: "vertical-items-margin" };
const _hoisted_4$2 = { class: "vertical-items-margin text-grey-8 text-bold" };
const _hoisted_5$2 = { class: "vertical-items-margin extra-margin-bottom" };
const _sfc_main$5 = defineComponent({
  __name: "ImportPrivateKeyInnerView",
  emits: ["imported", "canceled"],
  setup(__props, { emit: __emit }) {
    const privateKeyHex = ref("");
    const accountName = ref("");
    const showPlainText = ref(false);
    const password = ref(void 0);
    const generateKey = ref();
    const emit = __emit;
    const onImportClick = async () => {
      try {
        await Owner.create(privateKeyHex.value, accountName.value, password.value);
      } catch (error) {
        localStore.notification.pushNotification({
          Title: "Import account",
          Message: `Failed import account: ${error}.`,
          Popup: true,
          Type: localStore.notify.NotifyType.Error
        });
      }
      emit("imported");
    };
    const onCancelClick = () => {
      emit("canceled");
    };
    onMounted(async () => {
      accountName.value = await generateKey.value?.defaultAccountName();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", {
          innerHTML: _ctx.$t("MSG_IMPORTED_ACCOUNT_WONT_BOUND_TO_MNEMONIC")
        }, null, 8, _hoisted_1$4),
        createBaseVNode("div", _hoisted_2$3, toDisplayString(_ctx.$t("MSG_ACCOUNT_NAME")), 1),
        createBaseVNode("div", _hoisted_3$2, [
          createVNode(QInput, {
            outlined: "",
            dense: "",
            modelValue: accountName.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => accountName.value = $event)
          }, null, 8, ["modelValue"])
        ]),
        createBaseVNode("div", _hoisted_4$2, toDisplayString(_ctx.$t("MSG_PRIVATE_KEY")), 1),
        createBaseVNode("div", _hoisted_5$2, [
          createVNode(QInput, {
            outlined: "",
            dense: "",
            modelValue: privateKeyHex.value,
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => privateKeyHex.value = $event),
            type: showPlainText.value ? "text" : "password"
          }, {
            append: withCtx(() => [
              createVNode(QIcon, {
                name: showPlainText.value ? "bi-eye-fill" : "bi-eye-slash-fill",
                class: "cursor-pointer",
                onClick: _cache[1] || (_cache[1] = ($event) => showPlainText.value = !showPlainText.value)
              }, null, 8, ["name"])
            ]),
            _: 1
          }, 8, ["modelValue", "type"])
        ]),
        createVNode(QBtn, {
          flat: "",
          class: "btn full-width vertical-items-margin",
          onClick: onImportClick,
          "no-caps": "",
          disable: privateKeyHex.value.length === 0
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_IMPORT")), 1)
          ]),
          _: 1
        }, 8, ["disable"]),
        createVNode(QBtn, {
          flat: "",
          class: "btn btn-alt full-width vertical-items-margin",
          onClick: onCancelClick,
          "no-caps": ""
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_CANCEL")), 1)
          ]),
          _: 1
        }),
        createVNode(_sfc_main$9, {
          ref: "passwordBridge",
          password: password.value,
          "onUpdate:password": _cache[3] || (_cache[3] = ($event) => password.value = $event)
        }, null, 8, ["password"]),
        createVNode(_sfc_main$a, {
          ref_key: "generateKey",
          ref: generateKey
        }, null, 512)
      ]);
    };
  }
});
const _hoisted_1$3 = { class: "text-grey-9" };
const _hoisted_2$2 = { class: "vertical-items-margin" };
const _sfc_main$4 = defineComponent({
  __name: "GenerateKeyView",
  emits: ["created", "canceled"],
  setup(__props, { emit: __emit }) {
    const accountName = ref("");
    const emit = __emit;
    const generateKey = ref();
    const onCreateClick = async () => {
      const privateKeyHex = generateKey.value?.generateKey();
      await Owner.create(privateKeyHex, accountName.value);
      emit("created");
    };
    const onCancelClick = () => {
      emit("canceled");
    };
    onMounted(async () => {
      accountName.value = await generateKey.value?.defaultAccountName();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("span", _hoisted_1$3, toDisplayString(_ctx.$t("MSG_ACCOUNT_NAME")), 1),
        createBaseVNode("div", _hoisted_2$2, [
          createVNode(QInput, {
            dense: "",
            outlined: "",
            modelValue: accountName.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => accountName.value = $event)
          }, null, 8, ["modelValue"])
        ]),
        createVNode(QBtn, {
          flat: "",
          class: "btn full-width vertical-sections-margin",
          onClick: onCreateClick,
          "no-caps": "",
          disable: accountName.value.length === 0
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_CREATE")), 1)
          ]),
          _: 1
        }, 8, ["disable"]),
        createVNode(QBtn, {
          flat: "",
          class: "btn btn-alt full-width vertical-items-margin",
          onClick: onCancelClick,
          "no-caps": ""
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.$t("MSG_CANCEL")), 1)
          ]),
          _: 1
        }),
        createVNode(_sfc_main$a, {
          ref_key: "generateKey",
          ref: generateKey
        }, null, 512)
      ]);
    };
  }
});
const _hoisted_1$2 = { class: "page-x-padding" };
const _hoisted_2$1 = { class: "row" };
const _hoisted_3$1 = { class: "text-center text-bold text-grey-9 selector-title" };
const _hoisted_4$1 = { key: 0 };
const _hoisted_5$1 = { key: 1 };
const _hoisted_6$1 = { key: 0 };
const _hoisted_7$1 = { key: 1 };
const _sfc_main$3 = defineComponent({
  __name: "ImportPrivateKeyView",
  emits: ["canceled", "imported", "created"],
  setup(__props, { emit: __emit }) {
    const step = ref(1);
    const action = ref(1);
    const title = computed(() => {
      switch (step.value) {
        case 2:
          switch (action.value) {
            case 0:
              return "Create account";
            case 1:
              return "Import account";
            case 2:
              return "Add ledger";
          }
        case 1:
        default:
          return "Add account";
      }
    });
    const emit = __emit;
    const onCloseClick = () => {
      emit("canceled");
    };
    const onBackClick = () => {
      if (step.value === 1)
        return emit("canceled");
      step.value--;
    };
    const onCreateAccount = () => {
      action.value = 0;
      step.value++;
    };
    const onImportAccount = () => {
      action.value = 1;
      step.value++;
    };
    const onAddLedger = () => {
      action.value = 2;
      step.value++;
    };
    const onAccountImported = () => {
      emit("imported");
    };
    const onImportAccountCanceled = () => {
      step.value--;
    };
    const onAccountCreated = () => {
      emit("created");
    };
    const onCreateAccountCanceled = () => {
      step.value--;
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", _hoisted_2$1, [
          createVNode(QIcon, {
            name: "bi-arrow-left-short",
            size: "24px",
            class: "cursor-pointer",
            onClick: onBackClick
          }),
          createVNode(QSpace),
          createBaseVNode("p", _hoisted_3$1, toDisplayString(title.value), 1),
          createVNode(QSpace),
          createVNode(QIcon, {
            name: "bi-x",
            size: "24px",
            class: "cursor-pointer",
            onClick: onCloseClick
          })
        ]),
        step.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_4$1, [
          createVNode(_sfc_main$6, {
            onCreate: onCreateAccount,
            onImport: onImportAccount,
            onAddLedger
          })
        ])) : createCommentVNode("", true),
        step.value === 2 ? (openBlock(), createElementBlock("div", _hoisted_5$1, [
          action.value === 0 ? (openBlock(), createElementBlock("div", _hoisted_6$1, [
            createVNode(_sfc_main$4, {
              onCreated: onAccountCreated,
              onCanceled: onCreateAccountCanceled
            })
          ])) : createCommentVNode("", true),
          action.value === 1 ? (openBlock(), createElementBlock("div", _hoisted_7$1, [
            createVNode(_sfc_main$5, {
              onImported: onAccountImported,
              onCanceled: onImportAccountCanceled
            })
          ])) : createCommentVNode("", true)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
var OwnerSelector_vue_vue_type_style_index_0_scoped_true_lang = "";
const _hoisted_1$1 = {
  key: 0,
  class: "selector-action"
};
const _sfc_main$2 = defineComponent({
  __name: "OwnerSelector",
  props: /* @__PURE__ */ mergeModels({
    creatable: { type: Boolean, default: true },
    persistent: { type: Boolean, default: true }
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["selected"], ["update:modelValue"]),
  setup(__props, { emit: __emit }) {
    const props = __props;
    const creatable = toRef(props, "creatable");
    const persistent = toRef(props, "persistent");
    const step = ref(1);
    const owner = useModel(__props, "modelValue");
    const emit = __emit;
    const onOwnerSelected = (_owner) => {
      owner.value = _owner;
      emit("selected", _owner);
    };
    const onImportCanceled = () => {
      step.value = 1;
    };
    const onAccountCreated = () => {
      emit("selected");
    };
    const onAccountImported = () => {
      emit("selected");
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QCard, { class: "selector-card" }, {
        default: withCtx(() => [
          createVNode(QStepper, {
            flat: "",
            modelValue: step.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => step.value = $event),
            "active-color": "brown-8",
            "inactive-color": "brown-4",
            "done-color": "green-6",
            animated: "",
            "alternative-labels": "",
            "header-class": "hide"
          }, {
            default: withCtx(() => [
              createVNode(QStep, {
                name: 1,
                title: "1",
                done: step.value > 1
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$7, {
                    modelValue: owner.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => owner.value = $event),
                    onSelected: onOwnerSelected,
                    persistent: persistent.value
                  }, null, 8, ["modelValue", "persistent"])
                ]),
                _: 1
              }, 8, ["done"]),
              createVNode(QStep, {
                name: 2,
                title: "2",
                done: step.value > 2
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$3, {
                    onCanceled: onImportCanceled,
                    onCreated: onAccountCreated,
                    onImported: onAccountImported
                  })
                ]),
                _: 1
              }, 8, ["done"])
            ]),
            _: 1
          }, 8, ["modelValue"]),
          step.value === 1 && creatable.value ? (openBlock(), createElementBlock("div", _hoisted_1$1, [
            createVNode(QBtn, {
              flat: "",
              class: "btn btn-alt full-width",
              label: _ctx.$t("MSG_CREATE_OR_IMPORT_ACCOUNT"),
              "no-caps": "",
              onClick: _cache[2] || (_cache[2] = ($event) => step.value++)
            }, null, 8, ["label"])
          ])) : createCommentVNode("", true)
        ]),
        _: 1
      });
    };
  }
});
var OwnerSelector = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-3424a258"]]);
const _sfc_main$1 = defineComponent({
  __name: "OwnerBalanceBridge",
  props: /* @__PURE__ */ mergeModels({
    tokenId: {}
  }, {
    "tokenBalance": {},
    "tokenBalanceModifiers": {},
    "usdBalance": {},
    "usdBalanceModifiers": {}
  }),
  emits: ["update:tokenBalance", "update:usdBalance"],
  setup(__props) {
    const selectedOwner = ref(void 0);
    const props = __props;
    const tokenId = toRef(props, "tokenId");
    const tokenBalance = useModel(__props, "tokenBalance");
    const usdBalance = useModel(__props, "usdBalance");
    const _tokenBalance = useObservable(
      liveQuery(async () => {
        const owner = (await dbWallet.owners.toArray()).find((el) => el.selected);
        if (!owner)
          return 0;
        return await OwnerBalance.getTokenBalance(owner, tokenId.value);
      })
    );
    onMounted(async () => {
      const owner = (await dbWallet.owners.toArray()).find((el) => el.selected);
      if (!owner)
        return;
      tokenBalance.value = await OwnerBalance.getTokenBalance(owner, tokenId.value);
      usdBalance.value = await OwnerBalance.getUsdBalance(owner, tokenId.value);
    });
    watch(selectedOwner, async () => {
      const owner = (await dbWallet.owners.toArray()).find((el) => el.selected);
      if (!owner)
        return;
      tokenBalance.value = await OwnerBalance.getTokenBalance(owner, tokenId.value);
      usdBalance.value = await OwnerBalance.getUsdBalance(owner, tokenId.value);
    });
    watch(_tokenBalance, async () => {
      tokenBalance.value = _tokenBalance.value;
      const owner = (await dbWallet.owners.toArray()).find((el) => el.selected);
      if (!owner)
        return;
      usdBalance.value = await OwnerBalance.getUsdBalance(owner, tokenId.value);
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$b, {
        ref: "dbOwnerBridge",
        "selected-owner": selectedOwner.value,
        "onUpdate:selectedOwner": _cache[0] || (_cache[0] = ($event) => selectedOwner.value = $event)
      }, null, 8, ["selected-owner"]);
    };
  }
});
const _hoisted_1 = { class: "selector-margin-x-left" };
const _hoisted_2 = { class: "text-bold text-grey-9 row text-left" };
const _hoisted_3 = { class: "selector-margin-x-left" };
const _hoisted_4 = { class: "text-bold text-grey-9 text-right" };
const _hoisted_5 = { class: "selector-item-currency-sub" };
const _hoisted_6 = { class: "text-right" };
const _hoisted_7 = { class: "text-grey-6 selector-item-currency-sub" };
const _hoisted_8 = {
  key: 1,
  class: "selector-indicator selector-margin-x-left"
};
const _sfc_main = defineComponent({
  __name: "TokenCardView",
  props: {
    token: {},
    showIndicator: { type: Boolean, default: true },
    active: { type: Boolean, default: false },
    activeNative: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const token = toRef(props, "token");
    const showIndicator = toRef(props, "showIndicator");
    const active = toRef(props, "active");
    const activeNative = toRef(props, "activeNative");
    const tokenBalance = ref(0);
    const usdBalance = ref(0);
    const tokenLogo = ref("");
    const selectedOwner = ref(void 0);
    const onBlockProcessed = async (payload) => {
      const { microchain } = payload;
      if (microchain !== token.value.creatorChainId)
        return;
      await getBalance();
    };
    const getBalance = async () => {
      if (!selectedOwner.value)
        return;
      const balance = await Owner.ownerBalance(selectedOwner.value, token.value.id);
      tokenBalance.value = balance?.tokenBalance;
      usdBalance.value = balance?.usdBalance;
    };
    watch(selectedOwner, async () => {
      await getBalance();
    });
    onMounted(async () => {
      await getBalance();
      tokenLogo.value = await Token.logo(token.value.id);
      BlockWorker.on(BlockEventType.BLOCK_PROCESSED, onBlockProcessed);
    });
    onBeforeUnmount(() => {
      BlockWorker.off(BlockEventType.BLOCK_PROCESSED, onBlockProcessed);
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(QItem, {
        class: "row full-width tab-panel-item",
        clickable: ""
      }, {
        default: withCtx(() => [
          showIndicator.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(["selector-indicator", active.value || activeNative.value && token.value.native ? "selector-indicator-selected" : ""])
          }, null, 2)) : createCommentVNode("", true),
          createVNode(QAvatar, {
            class: normalizeClass([showIndicator.value ? "selector-margin-x-left" : ""])
          }, {
            default: withCtx(() => [
              createVNode(QImg, { src: tokenLogo.value }, null, 8, ["src"]),
              !token.value.native ? (openBlock(), createBlock(QBadge, {
                key: 0,
                color: "transparent",
                rounded: "",
                transparent: "",
                floating: ""
              }, {
                default: withCtx(() => [
                  createVNode(QImg, {
                    src: unref(lineraLogo),
                    width: "14px",
                    height: "14px"
                  }, null, 8, ["src"])
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ]),
            _: 1
          }, 8, ["class"]),
          createBaseVNode("div", _hoisted_1, [
            createBaseVNode("div", _hoisted_2, toDisplayString(token.value.ticker), 1)
          ]),
          createVNode(QSpace),
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("div", _hoisted_4, [
              createTextVNode(toDisplayString(parseFloat(tokenBalance.value.toFixed(4))) + " ", 1),
              createBaseVNode("span", _hoisted_5, toDisplayString(token.value.ticker), 1)
            ]),
            createBaseVNode("div", _hoisted_6, [
              createTextVNode(" $ " + toDisplayString(parseFloat(usdBalance.value.toFixed(4))) + " ", 1),
              createBaseVNode("span", _hoisted_7, toDisplayString(_ctx.$t("MSG_USD")), 1)
            ])
          ]),
          showIndicator.value ? (openBlock(), createElementBlock("div", _hoisted_8)) : createCommentVNode("", true),
          createVNode(_sfc_main$1, {
            "token-balance": tokenBalance.value,
            "onUpdate:tokenBalance": _cache[0] || (_cache[0] = ($event) => tokenBalance.value = $event),
            "usd-balance": usdBalance.value,
            "onUpdate:usdBalance": _cache[1] || (_cache[1] = ($event) => usdBalance.value = $event),
            "token-id": token.value.id
          }, null, 8, ["token-balance", "usd-balance", "token-id"]),
          createVNode(_sfc_main$b, {
            ref: "dbOwnerBridge",
            "selected-owner": selectedOwner.value,
            "onUpdate:selectedOwner": _cache[2] || (_cache[2] = ($event) => selectedOwner.value = $event)
          }, null, 8, ["selected-owner"])
        ]),
        _: 1
      });
    };
  }
});
export { Account as A, MemeApplicationOperation as M, OwnerSelector as O, _sfc_main$1 as _, _sfc_main as a };

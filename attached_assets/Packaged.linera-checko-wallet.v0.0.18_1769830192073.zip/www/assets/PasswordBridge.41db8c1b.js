import { d as decryptPassword } from "./application.ca271889.js";
import { l as liveQuery, d as dbBase } from "./db.46ddc67f.js";
import { u as useObservable } from "./index.f58c37d0.js";
import { d as defineComponent, aq as useModel, w as watch } from "./index.facf9114.js";
const _sfc_main = defineComponent({
  __name: "PasswordBridge",
  props: {
    "password": {},
    "passwordModifiers": {}
  },
  emits: ["update:password"],
  setup(__props) {
    const password = useModel(__props, "password");
    const _password = useObservable(
      liveQuery(async () => {
        const passwd = (await dbBase.passwords.toArray()).find((el) => el.active);
        if (!passwd)
          return void 0;
        const fingerPrint = (await dbBase.deviceFingerPrint.toArray())[0];
        if (!fingerPrint)
          return void 0;
        return decryptPassword(passwd, fingerPrint.fingerPrint);
      })
    );
    watch(_password, () => {
      password.value = _password.value;
    });
    return () => {
    };
  }
});
export { _sfc_main as _ };
